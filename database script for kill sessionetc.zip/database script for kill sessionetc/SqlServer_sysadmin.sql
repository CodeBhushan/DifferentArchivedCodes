/*************************************************************************************/
/*  Connect to the "ICP" database as the "sa" user, or any user with the "sysadmin"  */
/*  role, and execute the CM54_SQLServer_SA.sql script.  Ensure that you have        */
/*  run the "CM54_SQLServer.sql" script  before running this script.                 */
/*************************************************************************************/
/* @Freya:user @ingenixsys */
/* Do not modify this line or the line above */

use ICP
GO
        
GRANT EXECUTE ON [dbo].[USP_CLAIM_EDIT_SUMMARY_REPORT] TO [ingenix_proc_exec];
GO

GRANT EXECUTE ON [dbo].[USP_FLAG_EDIT_SUMMARY_REPORT] TO [ingenix_proc_exec];
GO

GRANT EXECUTE ON [dbo].[USP_FLAG_STATUS_SUM_REPORT] TO [ingenix_proc_exec];
GO

GRANT EXECUTE ON [dbo].[USP_SUMMARY_REPORT_NAME] TO [ingenix_proc_exec];
GO

GRANT EXECUTE ON [dbo].[USP_SREPORT_NAME_DYNAMIC] TO [ingenix_proc_exec];
GO

GRANT EXECUTE ON [dbo].[MONITOR_SCHEDULED_PURGE] TO INGENIX_PROC_EXEC
GO

GRANT EXECUTE ON [dbo].[CLAIM_PURGE] TO INGENIX_PROC_EXEC
GO

GRANT EXECUTE ON [dbo].[USP_CLAIM_PURGE] TO INGENIX_PROC_EXEC
GO

DECLARE @return_value int
EXEC @return_value = [dbo].[USP_SUMMARY_REPORT_NAME]
GO

GRANT EXECUTE ON [dbo].[GetNextVal_S_SMARTATTACH_REF_ID] TO INGENIX_PROC_EXEC
GO


GRANT EXECUTE ON [dbo].[usp_get_SPID] TO [ingenix_proc_exec];
GO

GRANT EXECUTE ON [dbo].[usp_kill_session] TO [ingenix_proc_exec];
GO


USE [master] 
GO
GRANT ALTER ANY CONNECTION TO icp_p;
GO



USE [ICP] 
GO

/* @Freya:user @product */
/*  Last Line, do not remove or modify this ore the previous line */