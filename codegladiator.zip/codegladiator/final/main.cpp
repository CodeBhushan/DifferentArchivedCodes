#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<iostream>
#include<vector>
#include <limits.h>
#include <algorithm>

using namespace std;
struct Pair {
    int x;
    int y;
};
struct Pair *arr;

Pair findRightpoint(Pair pair, Pair *pPair, int pointlen);

bool isDigit(char c) {
    if ((c >= '0') && (c <= '9')) return true;
    return false;
}


int split(char *str, struct Pair *points) {
    int pointindex = 0;
    int ans = 0;
    int index = 0; //arr = new struct pairr[input3];
    int length = strlen(str);
    int startdigitindex = 2;
    int enddigitindex = 2;

    bool x = true;
    int x1, y1;

    for (int i = 1; i < length - 1; i++) {
        if (isDigit(str[i])) {
            startdigitindex = i;
            while (isDigit(str[++i]));
            enddigitindex = i - 1;

            char *substring1 = new char[enddigitindex - startdigitindex + 1];
            for (int k = 0; k < enddigitindex - startdigitindex + 1; k++) {
                substring1[k] = str[k + startdigitindex];
            }

            int number = atoi(substring1);
            if (x) {
                // if(number<1 || number >row)return -1;
                x1 = number;
                x = !x;
            } else {
                //if(number<1||number>col)return -1;
                y1 = number;
                x = !x;
                ans++;
                // if(ans>input3)return -1;
                //grid[x1-1][y1-1]=true;
                Pair p;
                p.x = x1;
                p.y = y1;
                points[pointindex++] = p;
                //arr[index].x=x1-1; arr[index].y=y1-1;index++;
            }
        }
    }

    //if(ans!=input3)return -1;
    return ans;
}

bool contain(Pair *walls, int len, int point, bool * walldamaged) {

    for (int i = 0; i < len; i++) {
        if(!walldamaged[i])
        if (walls[i].x == point || walls[i].y == point)
            return true;
    }
    return false;
}

bool ishoriz(Pair p, Pair *points, int pointlen) {
    if (points[p.x - 1].x == points[p.y - 1].x) {
        return false;
    }
    if (points[p.y - 1].y == points[p.x - 1].y) {
        return true;
    }
}

Pair findRightpoint(Pair pair, Pair *points, int pointlen) {
    if (points[pair.x - 1].x > points[pair.y - 1].x) {
        return points[pair.x - 1];
    }
    else {
        return points[pair.y - 1];
    }
}

Pair findToppoint(Pair pair, Pair *points, int pointlen) {
    if (points[pair.x - 1].y > points[pair.y - 1].y) {
        return points[pair.x - 1];
    }
    else {
        return points[pair.y - 1];
    }
}

bool samepoint(Pair a, Pair b){
    if(a.x==b.x && a.y==b.y)return true;
    else return false;
}
bool *  ishoriontalwalls;
bool clockwalls(Pair refpoint,int refwallindex,int otherwallindex, Pair * points, Pair * walls){
if(ishoriontalwalls[refwallindex]){
    Pair p = findRightpoint(walls[refwallindex],points,-1);
    if(samepoint(p,refpoint)){
        p=findToppoint(walls[otherwallindex],points,-1);
        if(samepoint(p,refpoint))return true; else return false;
    }else{
        p=findToppoint(walls[otherwallindex],points,-1);
        if(samepoint(p,refpoint))return true; else return false;
    }

}else{

    Pair p = findToppoint(walls[refwallindex],points,-1);
    if(samepoint(p,refpoint)){
        p=findRightpoint(walls[otherwallindex],points,-1);
        if(samepoint(p,refpoint))return true; else return false;
    }else{
        p=findRightpoint(walls[otherwallindex],points,-1);
        if(samepoint(p,refpoint))return true; else return false;
    }

}

}
bool anticlockwalls(Pair refpoint, int refwallindex,int otherwallindex, Pair * points, Pair * walls){
return !clockwalls(refpoint, refwallindex,otherwallindex,points,walls);
}

bool moveanticlock(vector<Pair> *outerwalls, Pair *walls, int walllen, int pointlen, Pair *points, bool *isHorizon,
                   Pair refpoint, int refwallindex, Pair startpoint, bool * walldamaged) {
    walldamaged[refwallindex]=true;

    if(samepoint(startpoint,refpoint))        return true;

    outerwalls->push_back(refpoint);
int whichpointofwall =0; Pair nextrefpoint =refpoint ; Pair nextrefpointhoizon = refpoint ; Pair nextrefpointver= refpoint;int nextrefwallindexhoriz,nextrefwallindexver; int nextrefwallindextoppriority;Pair nextrefpointtopprio= refpoint;

    for (int i =0 ;i<walllen; i++){
        if(i!= refwallindex && !walldamaged[i]){
            if(samepoint(points[walls[i].x-1],refpoint)){
                nextrefpoint = points[walls[i].y-1];
                if(isHorizon[refwallindex]){

                    if(!isHorizon[i]){
                        if(!anticlockwalls(refpoint,refwallindex,i,points,walls)){
                             {
                                /*moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpoint, i,
                                              startpoint, walldamaged);
                                return;*/
                                 nextrefpointtopprio = nextrefpoint;
                                 nextrefwallindextoppriority=i;
                            }
                        }else{
                            nextrefpointver= nextrefpoint;
                            nextrefwallindexver=i;
                        }

                    }else{
                        nextrefpointhoizon= nextrefpoint;
                        nextrefwallindexhoriz=i;
                    }
                }else{

                    if(isHorizon[i]){
                        if(!anticlockwalls(refpoint,refwallindex,i,points,walls)){
                            /*moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpoint, i,startpoint,walldamaged);
                            return;*/
                            nextrefpointtopprio = nextrefpoint;
                            nextrefwallindextoppriority=i;
                        }else{
                            nextrefpointhoizon= nextrefpoint;
                            nextrefwallindexhoriz=i;
                        }

                    }else{
                        nextrefpointver= nextrefpoint;
                        nextrefwallindexver=i;
                    }

                }


            }else if(samepoint(points[walls[i].y-1],refpoint)){
                nextrefpoint = points[walls[i].x-1];
                if(isHorizon[refwallindex]){

                    if(!isHorizon[i]){
                        if(!anticlockwalls(refpoint,refwallindex,i,points,walls)){
                            /*moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpoint, i,startpoint,walldamaged);
                            return;*/
                            nextrefpointtopprio = nextrefpoint;
                            nextrefwallindextoppriority=i;
                        }else{
                            nextrefpointver= nextrefpoint;nextrefwallindexver=i;
                        }

                    }else{
                        nextrefpointhoizon= nextrefpoint;nextrefwallindexhoriz=i;
                    }
                }else{

                    if(isHorizon[i]){
                        if(!anticlockwalls(refpoint,refwallindex,i,points,walls)){
                           /* moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpoint, i,startpoint,walldamaged);
                            return;*/
                            nextrefpointtopprio = nextrefpoint;
                            nextrefwallindextoppriority=i;
                        }else{
                            nextrefpointhoizon= nextrefpoint;nextrefwallindexhoriz=i;
                        }

                    }else{
                        nextrefpointver= nextrefpoint;nextrefwallindexver=i;
                    }

                }


            }
        }
    }
    if(!samepoint(nextrefpointtopprio,refpoint)){
       bool tmp = moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpointtopprio, nextrefwallindextoppriority,startpoint,walldamaged);
        if(tmp) return true;
    }
    if(samepoint(nextrefpointhoizon,refpoint) && samepoint(nextrefpointver,refpoint)){
        walldamaged[refwallindex]=false;
        return false;;
    }else if(samepoint(nextrefpointhoizon,refpoint)){

        //if(moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpointver, nextrefwallindexver,startpoint,walldamaged);)
        return moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpointver, nextrefwallindexver,startpoint,walldamaged);

    }else if(samepoint(nextrefpointver,refpoint)){
        return moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpointhoizon, nextrefwallindexhoriz,startpoint,walldamaged);
       // return;
    }else{
        {
             bool tmp = moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpointhoizon, nextrefwallindexhoriz,startpoint,walldamaged);
            if(tmp)return tmp;
        }

        {
            bool tmp = moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpointver, nextrefwallindexver,startpoint,walldamaged);
            if(!tmp){
                walldamaged[refwallindex]=false;
            }
            return tmp;
        }

    }

    walldamaged[refwallindex]=false;
    return false;


}

bool moveclock(vector<Pair> *outerwalls, Pair *walls, int walllen, int pointlen, Pair *points, bool *isHorizon,
                   Pair refpoint, int refwallindex, Pair startpoint, bool * walldamaged) {
    walldamaged[refwallindex]=true;

    if(samepoint(startpoint,refpoint))        return true;

    outerwalls->push_back(refpoint);
    int whichpointofwall =0; Pair nextrefpoint =refpoint; Pair nextrefpointhoizon = refpoint ; Pair nextrefpointver= refpoint;int nextrefwallindexhoriz,nextrefwallindexver; int nextrefwallindextopprio;Pair nextrefpointtopprio= refpoint;
    for (int i =0 ;i<walllen; i++){
        if(i!= refwallindex && !walldamaged[i]){
            if(samepoint(points[walls[i].x-1],refpoint)){
                nextrefpoint = points[walls[i].y-1];
                if(isHorizon[refwallindex]){

                    if(!isHorizon[i]){
                        if(!clockwalls(refpoint,refwallindex,i,points,walls)){
                            /*moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpoint, i,startpoint,walldamaged);
                            return;*/
                            nextrefwallindextopprio=i;
                             nextrefpointtopprio= nextrefpoint;
                        }else{
                            nextrefpointver= nextrefpoint;
                            nextrefwallindexver=i;
                        }

                    }else{
                        nextrefpointhoizon= nextrefpoint;
                        nextrefwallindexhoriz=i;
                    }
                }else{

                    if(isHorizon[i]){
                        if(!clockwalls(refpoint,refwallindex,i,points,walls)){
                           /* moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpoint, i,startpoint,walldamaged);
                            return;*/
                            nextrefwallindextopprio=i;
                            nextrefpointtopprio= nextrefpoint;
                        }else{
                            nextrefpointhoizon= nextrefpoint;
                            nextrefwallindexhoriz=i;
                        }

                    }else{
                        nextrefpointver= nextrefpoint;
                        nextrefwallindexver=i;
                    }

                }


            }else if(samepoint(points[walls[i].y-1],refpoint)){
                nextrefpoint = points[walls[i].x-1];
                if(isHorizon[refwallindex]){

                    if(!isHorizon[i]){
                        if(!clockwalls(refpoint,refwallindex,i,points,walls)){
                           /* moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpoint, i,startpoint,walldamaged);
                            return;*/nextrefwallindextopprio=i;
                            nextrefpointtopprio= nextrefpoint;
                        }else{
                            nextrefpointver= nextrefpoint;nextrefwallindexver=i;
                        }

                    }else{
                        nextrefpointhoizon= nextrefpoint;nextrefwallindexhoriz=i;
                    }
                }else{

                    if(isHorizon[i]){
                        if(!clockwalls(refpoint,refwallindex,i,points,walls)){
                           /* moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpoint, i,startpoint,walldamaged);
                            return;*/
                            nextrefwallindextopprio=i;
                            nextrefpointtopprio= nextrefpoint;
                        }else{
                            nextrefpointhoizon= nextrefpoint;nextrefwallindexhoriz=i;
                        }

                    }else{
                        nextrefpointver= nextrefpoint;nextrefwallindexver=i;
                    }

                }


            }
        }
    }
    if(!samepoint(refpoint,nextrefpoint)){
        bool temp = moveclock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpoint, nextrefwallindextopprio,startpoint,walldamaged);
        if(temp) return temp;
    }

    if(samepoint(nextrefpointhoizon,refpoint) && samepoint(nextrefpointver,refpoint)){
        walldamaged[refwallindex]=false;
        return false;
    }else if(samepoint(nextrefpointhoizon,refpoint)){
        return moveclock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpointver, nextrefwallindexver,startpoint,walldamaged);

    }else if(samepoint(nextrefpointver,refpoint)){
        return moveclock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpointhoizon, nextrefwallindexhoriz,startpoint,walldamaged);

    }else{

           bool tmp = moveclock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpointhoizon, nextrefwallindexhoriz,startpoint,walldamaged);
            if (tmp) return  tmp;
       tmp= moveclock(outerwalls, walls, walllen, pointlen, points, isHorizon, nextrefpointver, nextrefwallindexver,startpoint,walldamaged);
            if(!tmp){
                walldamaged[refwallindex]=false;
            }
return tmp;
    }
    walldamaged[refwallindex]=false;
    return  false;


}

bool outer(vector<Pair> *outerwalls, Pair *walls, int walllen, int pointlen, Pair *points, bool *isHorizon, bool * walldamaged) {
    int wallindex = -1;
    int pointindex = -1;
    int minx = INT_MAX;
    int miny = INT_MAX;
    for (int i = 0; i < pointlen; i++) {
        if (points[i].x < minx && points[i].y < miny && contain(walls, walllen, i + 1, walldamaged)) {
            minx = points[i].x;
            miny = points[i].y;
            pointindex = i;
        }
    }
    //if (pointindex == -1)return;
    cout << pointindex << "pointind" << endl;
    for (int i = 0; i < walllen; i++) {
        if (walls[i].x == pointindex + 1 || walls[i].y == pointindex + 1) {
            wallindex = i;
            cout << wallindex << "wallindex" << endl;
            break;
        }
    }

    Pair startPoint = points[pointindex];

    for (int i = 0; i < walllen; i++) {
        bool isHorizontal = ishoriz(walls[wallindex], points, pointlen);
        if (isHorizontal) {//move anticlock

            Pair p = findRightpoint(walls[wallindex], points, pointlen);
            outerwalls->push_back(startPoint);
            return moveanticlock(outerwalls, walls, walllen, pointlen, points, isHorizon, p, wallindex, startPoint, walldamaged);



        } else {
            Pair p = findToppoint(walls[wallindex], points, pointlen);
            outerwalls->push_back(startPoint);
            return moveclock(outerwalls, walls, walllen, pointlen, points, isHorizon, p, wallindex, startPoint, walldamaged);



        }


    }


}


char *GetStrongWall(int input1, char *input2, int input3, char *input4) {
    struct Pair *points = new Pair[input1];
    split(input2, points);
    /*for(int i =0; i<input1;i++){
        cout<<points[i].x<<points[i].y<<endl;
    }*/

    struct Pair *walls = new Pair[input3];
    split(input4, walls);

    bool *isHorizon = new bool[input3];
    bool *walldamaged = new bool[input3];
    for (int i = 0; i < input3; i++) {
        isHorizon[i] = ishoriz(walls[i], points, input1);
    }
    ishoriontalwalls = isHorizon;
    for(int i =0; i<input3; i++){
        walldamaged[i]= false;
    }

    vector<Pair> *outerWalls = new vector<Pair>();
    int lasttimeouterwalls=-1;
    outer(outerWalls, walls, input3, input1, points, isHorizon, walldamaged);
    bool ans= true;
    while (true)
    if(ans == false || outerWalls->size()==lasttimeouterwalls){
        int count =0;
        for(int i =0; i<input3; i++){
            if(!walldamaged[i])count++;
        }
        if(count==0){
            char* NA=new char[1];NA[0]='0';//NA[1]='A';
            return NA;
        }//todo
        else{
            string s="";
            vector<int> * v = new vector<int>();
            for(int i =0; i<input3; i++){
                if(!walldamaged[i])
                    v->push_back(i+1);
            }

            sort(v->begin(),v->end());
            for(int i =0; i<count/*outerWalls->size()*/;i++){
                s+= itoa((*v)[i],new char[1000000],10);
                if(i!=count-1)
                s+=",";
            }
            char *cstr = new char[s.length() + 1];
            strcpy(cstr, s.c_str());
            return cstr;
        }

    }else{
        lasttimeouterwalls= outerWalls->size();
        outerWalls->clear();
       ans = outer(outerWalls, walls, input3, input1, points, isHorizon, walldamaged);
    }






}

int main() {
    string str = "(1,1),(8,1),(4,2),(7,2),(2,3),(4,3),(6,3),(2,5),(4,5),(6,5),(4,6),(7,6),(1,8),(4,8),(8,8)";
    char *cstr = new char[str.length() + 1];
    strcpy(cstr, str.c_str());
    str = "(1,2),(2,15),(15,14),(14,13),(13,1),(14,11),(11,12),(12,4),(4,3),(3,6),(6,5),(5,8),(8,9),(9,11),(9,10),(10,7),(7,6)";
    char *cstr1 = new char[str.length() + 1];
    strcpy(cstr1, str.c_str());


    cout << (GetStrongWall(15, cstr, 17, cstr1));
    return 0;
}

















void reverse(char str[], int length)
{
    int start = 0;
    int end = length -1;
    while (start < end)
    {
        swap(*(str+start), *(str+end));
        start++;
        end--;
    }
}

// Implementation of itoa()
char* itoa(int num, char* str, int base)
{
    int i = 0;
    bool isNegative = false;

    /* Handle 0 explicitely, otherwise empty string is printed for 0 */
    if (num == 0)
    {
        str[i++] = '0';
        str[i] = '\0';
        return str;
    }

    // In standard itoa(), negative numbers are handled only with
    // base 10. Otherwise numbers are considered unsigned.
    if (num < 0 && base == 10)
    {
        isNegative = true;
        num = -num;
    }

    // Process individual digits
    while (num != 0)
    {
        int rem = num % base;
        str[i++] = (rem > 9)? (rem-10) + 'a' : rem + '0';
        num = num/base;
    }

    // If number is negative, append '-'
    if (isNegative)
        str[i++] = '-';

    str[i] = '\0'; // Append string terminator

    // Reverse the string
    reverse(str, i);

    return str;
}
