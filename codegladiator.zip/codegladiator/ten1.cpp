#include<stdio.h>
#include<string.h>


void swap(int &i, int &j){
	int temp= i;
	i=j;
	j =temp;
}

struct minHeap{
	unsigned heapSize;
		int * nodes;
};




void rearrangeMinHeap(struct minHeap* heap, int index){
	int smallestIndex = index;
	int rightIndex = 2 * index + 2;
    int leftIndex = 2 * index + 1;
    
  if (rightIndex < heap->heapSize &&      heap->nodes[rightIndex] < heap->nodes[smallestIndex]){
      smallestIndex = rightIndex;
      }
    if (leftIndex < heap->heapSize &&        heap->nodes[leftIndex] < heap->nodes[smallestIndex]){
      smallestIndex = leftIndex;
      }
 
   
 
    if (smallestIndex != index)
    {
        swap(heap->nodes[smallestIndex], heap->nodes[index]);
        rearrangeMinHeap(heap, smallestIndex);
    }
}

int extractMinimumNo(struct minHeap* heap){
	int ans = heap->nodes[0];

	heap->nodes[0]=heap->nodes[heap->heapSize-1];
	heap->heapSize=heap->heapSize-1;
	rearrangeMinHeap(heap,0);
	return ans;
	
}

void insert(struct minHeap * heap, int value){
	int i = heap->heapSize;
	heap->heapSize= heap->heapSize+1;
	while(i && (value< heap->nodes[(i-1)/2])){
		heap->nodes[i]=heap->nodes[(i-1)/2];
		i= (i-1)/2;
	}
	heap->nodes[i]=value;
	
}

int * getJoinedPipes(int input1[],int input2){
	
	

	int * ans = new int[input2-1];int k =0;	
	
	struct minHeap* heap  = new minHeap;
	
	heap->nodes= new int[input2];



	heap->nodes=input1;
	heap->heapSize= input2;
	
	int n = heap->heapSize-1;
	
	for(int i =(n-1)/2;i>=0;i--){
	rearrangeMinHeap(heap,i);	
	}
	
	while(true){
		if(heap->heapSize==1)break;
		int min= extractMinimumNo(heap);
		int min2=extractMinimumNo(heap);
		ans[k++]=min+min2;
		insert(heap,ans[k-1]);
	}
	
	return ans;
	
}

int main() {
int arr[]={4,3,2,6};
int * ans = fun(arr,4);
for(int i =0;i<3;i++){
	cout<<ans[i]<<endl;
}
	// your code goes here
	return 0;
}

//////////



 • Reply•Share › 
Avatar
Asif Garhi • 2 months ago
I am not sure if we want to heapify twice to find minimum and next minimum. We can just find the minimum in each loop and keep adding it as shown below:
public void heapify(int[] arr, int idx, int maxIdx) {
if(idx == maxIdx || maxIdx < 1) return;
int minValueIdx = minIdx(arr, idx, maxIdx); // Gets the index of the minimum of the 3 or 2 or 1 node
if(idx != minValueIdx) {
swap(arr,idx,minValueIdx);
idx = minValueIdx;
heapify(arr, idx, maxIdx);
}
}

private int minIdx(int[] arr, int idx, int maxIdx) {
int leftChildIdx = 2 * idx + 1;
int rightChildIdx = leftChildIdx + 1;
if(leftChildIdx > maxIdx) return idx;
if(rightChildIdx > maxIdx) return arr[leftChildIdx] < arr[idx] ? leftChildIdx : idx;
else {
int smallerIdx = arr[leftChildIdx] < arr[idx] ? leftChildIdx : idx;
return arr[smallerIdx] < arr[rightChildIdx] ? smallerIdx : rightChildIdx;
}
}

@Override
public void sort(int[] arr) {
int totalCost = 0;
int lengthIdx = arr.length - 1;
for(int i = lengthIdx/2; i >= 0; i--) {
heapify(arr, i, lengthIdx);
}
boolean isFirst = true;
while(lengthIdx >=0) {
if(isFirst) {
swap(arr,0,lengthIdx);
isFirst = false;
} else {
int first = arr[0];
arr[0] = arr[lengthIdx];
arr[lengthIdx] = first + arr[lengthIdx + 1];
totalCost += arr[lengthIdx];
}
--lengthIdx;
heapify(arr, 0, lengthIdx);
}
}