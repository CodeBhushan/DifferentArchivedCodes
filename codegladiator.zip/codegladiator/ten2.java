
import java.io.*;
public class CandidateCode
{

    

     public static boolean col(int i, int j, int k, int l, int m , int n){

        int val = (l - j) * (m - k) -
                (k - i) * (n - l);

        if(val==0)return true; else return false;
    }
    public static int dis(int i, int j, int k, int l){
        return (j-l)*(j-l)+(i-k)*(i-k);
    }

 

    public static int maxTreeDestroyed(int input1,int input2,int input3,String input4)
    {
        if(input3<3 && input3>input1*input2)return -1;
        int ans =2;
        boolean grid[][]= new boolean[input1][input2];
        for(int i =0;i<input1;i++)
            for(int j =0;j<input2;j++){
                grid[i][j]=false;
            }

        String tmp [] = input4.split("\\),\\(");
        System.out.println(tmp.length);
        for(int i =0; i<tmp.length;i++){
            int k, l;
            String temp []= tmp[i].split(",");
            if(i==0){
                k=Integer.parseInt(temp[0].substring(2));;
                l=Integer.parseInt(temp[1]);;;
            }else if (i==tmp.length-1){
               // System.out.println(temp[1]);
                k=Integer.parseInt(temp[0]);;
                l=Integer.parseInt(temp[1].substring(0,temp[1].length()-2));;;
            }

            else
            {
                k = Integer.parseInt(temp[0]);
                l = Integer.parseInt(temp[1]);
            }
          //  System.out.println(k);            System.out.println(l);
            grid[k-1][l-1]=true;

        }

        for(int i =0;i<input1;i++)
            for(int j =0;j<input2;j++)if(grid[i][j])
            {
                for(int k =i;k<input1;k++)
                    for(int l=j;l<input2;l++)if(grid[k][l] && !(i==k && j==l))
                    {

                        int dis = dis(i,j,k,l);int ans_=2;
                        int lastx= k; int lasty=l;
                        for(int m =k;m<input1;m++)
                            for(int n=l;n<input2;n++)if(grid[m][n] && !(k==m && l==n))
                            {


                                if(col(i,j,k,l,m,n)){
                                    int distmp= dis(lastx,lasty,m,n);
                                    if(distmp==dis){
                                        ans_++;
                                        lastx=m;lasty=n;
                                    }
                                }
                            }
                        if(ans_>ans)ans=ans_;


                    }


                for(int k =i;k<input1;k++)
                    for(int l=j;l>=0;l--)if(grid[k][l] && !(i==k && j==l))
                    {
                        int dis = dis(i,j,k,l);int ans_=2;
                        int lastx= k; int lasty=l;
                        for(int m =k;m<input1;m++)
                            for(int n=l;n>=0;n--)if(grid[m][n] && !(k==m && l==n))
                            {


                                if(col(i,j,k,l,m,n)){
                                    int distmp= dis(lastx,lasty,m,n);
                                    if(distmp==dis){
                                        ans_++;
                                        lastx=m;lasty=n;
                                    }
                                }
                            }
                        if(ans_>ans)ans=ans_;

                    }
            }






        return ans;

    }

 public static void main(String[] args){
     System.out.print(  maxTreeDestroyed(61,71,14,"((2,1),(6,6),(4,2),(2,5),(2,6),(2,7),(3,4),(6,1),(6,2),(2,3),(6,3),(6,4),(6,5),(6,7))"));
    }
}

//is tmp.length==plantDestroyed?
//is index of plant destroyed in range of row, and col?
//perhaps if ans ==1,2 return -1 -> read question and solution in question carefuly
//all colinear equidistant path can't be monkey's path always.. as through that path, monkey might not be able to jump out of gardeen
