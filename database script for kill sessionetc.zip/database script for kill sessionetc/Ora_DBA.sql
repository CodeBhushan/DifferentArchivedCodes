/******************************************************************************/
/*  Connect as the system user or another user with the DBA role, to execute  */
/*  this script.  Ensure that you have run the standard, non-admin            */
/*  <product>54_Oracle.sql" script before running this script.                */
/******************************************************************************/
/* @Freya:user @ingenixsys */
/* Do not modify this line or the line above */





/* @Freya:user sys*/
/*  Last Line, do not remove or modify this ore the previous line */

--Start of procedure usp_kill_session
CREATE OR REPLACE
PROCEDURE usp_kill_session
  (    p_uniqueClientId IN VARCHAR2 )
  IS
  
  cursor_name pls_integer DEFAULT dbms_sql.open_cursor;
  ignore pls_integer;
  BEGIN
  FOR rec IN
  (SELECT TO_CHAR(sid) AS SID1,
    TO_CHAR(serial#)   AS SERIAL1
  FROM v$session
  WHERE client_info = p_uniqueClientId
  )
  LOOP
    --DBMS_OUTPUT.put_line ((rec.sid1) + (rec.serial1 ));
    SELECT COUNT(*)
    INTO ignore
    FROM V$session
    WHERE username = USER
    AND sid        = rec.sid1
    AND serial#    =rec.serial1;
    IF ( ignore    = 1 ) THEN
      dbms_sql.parse(cursor_name, 'alter system kill session ''' ||rec.sid1||','||rec.serial1||'''', dbms_sql.native);
      ignore := dbms_sql.execute(cursor_name);
    ELSE
      raise_application_error( -20001, 'You do not own session ''' || rec.sid1 || ',' || rec.serial1 || '''' );
    END IF;
  END LOOP;
END;
/
--End of procedure usp_kill_session

grant execute on usp_kill_session to icp_p;


  /* @Freya:user @product */
/*  Last Line, do not remove or modify this ore the previous line */






