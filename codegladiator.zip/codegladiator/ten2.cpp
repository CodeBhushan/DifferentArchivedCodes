#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<cstring>



using namespace std;



struct pair{
int x; int y;
};
int pickedpointx,pickedpointy;

bool compare (pair i,pair j) { 
int val = (i.y - pickedpointy) * (j.x - i.x) -
    (i.x - pickedpointx) * (j.y - i.y);

   if(val>0)return true;
   if (val<0)return false;
   if(val==0){
    if(dis(pickedpointx,pickedpointy,i.x,i.y)<dis(pickedpointx,pickedpointy,j.x,j.y)) return true;else return false;
   }

}

pair * arr;
bool isDigit (char c) {
    if ((c>='0') && (c<='9')) return true;
    return false;
}

int split(char * str, bool** grid, int row, int col, int input3){
    int ans =0;int index=0; arr = new pair[input3];
    int length = strlen(str);
    int startdigitindex=2;
    int enddigitindex=2;
    int lastdigitIndex=2;
    bool x=true;int x1,y1;
    int lastCharIndex=1;
    for(int i =2;i<length-2;i++){
        if(isDigit(str[i])){
            startdigitindex=i;
            while(isDigit(str[++i]));
            enddigitindex=i-1;
       
            char* substring1 = new char[enddigitindex-startdigitindex+1];
            for(int k =0;k<enddigitindex-startdigitindex+1;k++){
   
                substring1[k]=str[k+startdigitindex];
                
            }

            int number = atoi(substring1);
            if(x){
               if(number<1 || number >row)return -1;
                x1=number;
                x=!x;
                }else{
               if(number<1||number>col)return -1;
                y1=number;
                x=!x;
cout<<x1<<y1<<endl;

ans++;
if(ans>input3)return -1;
                grid[x1-1][y1-1]=true;
arr[index].x=x1-1; arr[index].y=y1-1;index++;
            }
            
        }
        
        
    }
    
    return ans;
}

bool col(int i, int j, int k, int l, int m , int n){
    
    int val = (l - j) * (m - k) -
    (k - i) * (n - l);
    
    if(val==0)return true; else return false;
}
int dis(int i, int j, int k, int l){
    return (j-l)*(j-l)+(i-k)*(i-k);
}
int * sort(bool** grid, int i  , int j, int total, int & size){
pair * temp = new pair[total];
 size=0;
for(int k =0; k<total+1;k++){
    if(!(arr[k].x==i && arr[k].y==j) && arr[k].x>=i && arr[k].y>=j){
        temp[size].x=arr[k].x;
        temp[size].y=arr[k].y;
        size++;
    }
}

pickedpointx =i;pickedpointy=j;
sort(temp, temp+size,compare);

return temp;

}

int * sort1(bool** grid, int i  , int j, int total, int & size){
pair * temp = new pair[total];
 size=0;
for(int k =0; k<total+1;k++){
    if(!(arr[k].x==i && arr[k].y==j) && arr[k].x>=i && arr[k].y<=j){
        temp[size].x=arr[k].x;
        temp[size].y=arr[k].y;
        size++;
    }
}

pickedpointx =i;pickedpointy=j;
sort(temp, temp+size,compare);

return temp;

}
   bool valid1(int input1, int input2, int i, int j, int lastx, int lasty, int ans_)
    {
        int x =lastx+(lastx-i)/(ans_-1) ;
        int y = lasty+(lasty-j)/(ans_-1) ;
        if(x>=0 && x<input1 && y>=0 && y<input2)return false;else return true;
    }

    bool valid(int input1,int input2, int i, int j, int k, int l)
    {
        int x =2*i-k;
        int y = 2*j-l;
        if(x>=0 && x<input1 && y>=0 && y<input2)return false;else return true;
    }
int findmaxequidistantpoints(int size,int i,int j,pair * sorted,int startCollinearIndex, int endCollinearIndex,int k1, int l1,int lastx, int lasty,int input1,int input2){
int ans =2;
for(int a=0;a<size;a++){
int dis = dis(i,j,sorted[a].x,sorted[a].y);int ans_=2;
                        int lastx1= sorted[a].x; int lasty1=sorted[a].y;
    for(int b=0;b<size;b++){
                        int distmp= dis(lastx1,lasty1,sorted[b].x,sorted[b].y);
                        if(distmp==dis){
                            ans_++;
                            lastx1=sorted[b].x;lasty1=sorted[b].y;
                        }
    }
    if(ans<ans_ && valid(input1,input2,i,j,sorted[a].x,sorted[a].y) && valid1(input1,input2,i,j,lastx1,lasty1,ans_)){
        ans=ans_;
        k1=sorted[a].x;l1=sorted[a].y;lastx=lastx1;lasty=lasty1;
    }
}

return ans;
}

int maxTreeDestroyed(int input1, int input2, int input3, char * input4){
    if(input3<3 || input3>input1*input2)
    return -1;
    bool ** grid  = new bool*[input1];
    for  ( int i =0;i<input1;i++){
        grid[i]= new bool[input2];
        
    }
    for(int i =0;i<input1;i++)
    for(int j =0;j<input2;j++){
        grid[i][j]=false;
    }
    
    int reply= split(input4,grid,input1,input2,input3);
    
    if(reply==-1 || reply> input3) return -1;
    
    int ans=2;
    //
  for(int i =0;i<input1;i++)
            for(int j =0;j<input2;j++)if(grid[i][j]){
                int size;
int * sorted = sort(grid,i,j,input3-1 ,size);
int startCollinearIndex=0;int endCollinearIndex=0;
for(int k=0;k<size-1;k++){
//int dis = dis(i,j,sorted[0].x,sorted[0].y);int ans_=2; int lastx= sorted[0].x; int lasty=sorted[0].y;
if(!col(i,j,sorted[k].x,sorted[k].y,sorted[k+1].x,sorted[k+1].y)){
    endCollinearIndex=k;
    int lastx,lasty,k1,l1;
int ans_ = findmaxequidistantpoints(size,i,j,sorted,startCollinearIndex,endCollinearIndex,k1,l1,lastx,lasty,input1,input2);
if(ans_>ans &&  valid(input1,input2,i,j,k1,l1) && valid1(input1,input2,i,j,lastx,lasty,ans_) )ans=ans_;
    startCollinearIndex=k+1;
}
  

}








int * sorted1=sort1(grid,i,j,input3-1,size);
int startCollinearIndex=0;int endCollinearIndex=0;
for(int k=0;k<size-1;k++){
//int dis = dis(i,j,sorted[0].x,sorted[0].y);int ans_=2; int lastx= sorted[0].x; int lasty=sorted[0].y;
if(!col(i,j,sorted[k].x,sorted[k].y,sorted[k+1].x,sorted[k+1].y)){
    endCollinearIndex=k;
    int lastx,lasty,k1,l1;
int ans_ = findmaxequidistantpoints(size,i,j,sorted,startCollinearIndex,endCollinearIndex,k1,l1,lastx,lasty,input1,input2);
if(ans_>ans   && valid(input1,input2,i,j,k1,l1) && valid1(input1,input2,i,j,lastx,lasty,ans_) )ans=ans_;
    startCollinearIndex=k+1;
}
  

}


}
    //write logic
    if(ans<3)return -1;else return ans;
    
}


int main(){
  string str="((21,11),(6,6),(41,2),(2,5),(2,6),(2,7),(3,4),(6,1),(6,2),(2,3),(6,3),(6,4),(6,5),(61,71))";
            char *cstr = new char[str.length() + 1];
strcpy(cstr, str.c_str());
            
    cout<<(  maxTreeDestroyed(6,7,14,cstr));
    return 0;
}