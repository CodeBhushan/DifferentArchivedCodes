#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<iostream>
using namespace std;
struct pairr{
int x; int y;
};
struct pairr* arr;
bool isDigit (char c) {
    if ((c>='0') && (c<='9')) return true;
    return false;
}

int split(char * str, bool** grid, int row, int col, int input3){
    int ans =0;int index=0; arr = new struct pairr[input3];
    int length = strlen(str);
    int startdigitindex=2;
    int enddigitindex=2;
    
    bool x=true;int x1,y1;
    
    for(int i =2;i<length-2;i++){
        if(isDigit(str[i])){
            startdigitindex=i;
            while(isDigit(str[++i]));
            enddigitindex=i-1;
       
            char* substring1 = new char[enddigitindex-startdigitindex+1];
            for(int k =0;k<enddigitindex-startdigitindex+1;k++){
                   substring1[k]=str[k+startdigitindex];
                    }

            int number = atoi(substring1);
            if(x){
               if(number<1 || number >row)return -1;
                x1=number;
                x=!x;
                }else{
               if(number<1||number>col)return -1;
                y1=number;
                x=!x;
ans++;
if(ans>input3)return -1;
                grid[x1-1][y1-1]=true;
                arr[index].x=x1-1; arr[index].y=y1-1;index++;
            }          
        }        
    }
    
    if(ans!=input3)return -1;
    return ans;
}

bool col(int i, int j, int k, int l, int m , int n){
        
        if((l - j) * (m - k) - (k - i) * (n - l)==0)return true; else return false;
}
int dist(int i, int j, int k, int l){
    return (j-l)*(j-l)+(i-k)*(i-k);
}





bool valid1(int input1, int input2, int i, int j, int lastx, int lasty, int ans_)
    {
        int x =lastx+(lastx-i)/(ans_-1) ;
        int y = lasty+(lasty-j)/(ans_-1) ;
        if(x>=0 && x<input1 && y>=0 && y<input2)return false; return true;
    }

    bool valid(int input1,int input2, int i, int j, int k, int l)
    {
        int x =2*i-k;
        int y = 2*j-l;
        if(x>=0 && x<input1 && y>=0 && y<input2)return false; return true;
    }

int maxTreeDestroyed(int input1, int input2, int input3, char * input4){
    if(input3<3 || input3>input1*input2)
    return -1;
    bool ** grid  = new bool*[input1];
    for  ( int i =0;i<input1;i++){
        grid[i]= new bool[input2];
        
    }
    for(int i =0;i<input1;i++)
    for(int j =0;j<input2;j++){
        grid[i][j]=false;
    }
    
    
    
    if(split(input4,grid,input1,input2,input3)==-1 ) return -1;
    
    int ans=1;
    
     //for(int i =0;i<input1;i++)for(int j =0;j<input2;j++)if(grid[i][j])
   // int i,j,k,l;
    int m,n,lastx,lasty,ans_;for (int z =0;z<input3;z++)
            { //i = arr[z].x; //j =arr[z].y;
                //for(int k =i;k<input1;k++)for(int l=0;l<input2;l++)if(grid[k][l] && !(i==k && j==l))
                for(int z1=0;z1<input3;z1++)if(arr[z1].x>=arr[z].x && !(arr[z].x==arr[z1].x && arr[z].y==arr[z1].y))
                    {//k = arr[z1].x; l =arr[z1].y;
 
                        if(valid(input1,input2,i,arr[z].y,arr[z1].x,arr[z1].y)){
                            
                            //int dis = dist(i,j,k,l);
                             ans_=2;
                              lastx= arr[z1].x;  lasty=arr[z1].y;
                             m =arr[z1].x-(arr[z].x-arr[z1].x);
                             n =arr[z1].y-(arr[z].y-arr[z1].y);
                            while(m>=0 && m<input1 && n>=0 && n<input2 && grid[m][n]){
                            //if(i==5 && j==0 && k==5 && l==1)  cout<<m<<n<<endl;
                              
                                
                                        ans_++;lastx=m;lasty=n;m=m-arr[z].x+arr[z1].x;n=n-arr[z].y+arr[z1].y;
                                
                            }
                            
                            if(ans_>ans && valid1(input1,input2,arr[z].x,arr[z].y,lastx,lasty,ans_)){
                            ans=ans_;
                           
                            }
                        }

                        



                    

                    }



            }




  // if(ans<3)return -1;else 
            return ans;
    
}

int main(){
  string str="((2,1),(6,6),(4,2),(2,5),(2,6),(2,7),(2,3),(6,3),(6,4),(6,5),(6,7))";
            char *cstr = new char[str.length() + 1];
strcpy(cstr, str.c_str());
            
    cout<<(  maxTreeDestroyed(61,71,11,cstr));
    return 0;
}
