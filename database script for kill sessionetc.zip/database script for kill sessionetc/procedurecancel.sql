SELECT * FROM v$session ;--module action client_info for finding sid and serial#
CALL SYSCS_UTIL.SYSCS_SET_DATABASE_PROPERTY( 'derby.database.sqlAuthorization', 'true');
GRANT SELECT ON v_$session TO icp_p;
GRANT ALTER system TO freya;

select count(*) from v$session
select client_info from v$session where client_info is not null;
select * from v$session where audsid=userenv('sessionid'); 
select program from v$session where audsid=userenv('sessionid'); 

CREATE OR REPLACE
PROCEDURE usp_kill_session
  (
    p_uniqueClientId IN VARCHAR2,
    --p_sid     IN VARCHAR2,
    --p_serial# IN VARCHAR2
  )
IS
  cursor_name pls_integer DEFAULT dbms_sql.open_cursor;
  ignore pls_integer;
  p_sid     VARCHAR2;
  p_serial# VARCHAR2;
BEGIN
  SELECT SID INTO p_sid FROM v$session WHERE client_info = p_uniqueClientId;
  SELECT SERIAL#
  INTO p_serial#
  FROM v$session
  WHERE client_info = p_uniqueClientId;
  SELECT COUNT(*)
  INTO ignore
  FROM V$session
  WHERE username = USER
  AND sid        = p_sid
  AND serial#    = p_serial# ;
  IF ( ignore    = 1 ) THEN
    dbms_sql.parse(cursor_name, 'alter system kill session ''' ||p_sid||','||p_serial#||'''', dbms_sql.native);
    ignore := dbms_sql.execute(cursor_name);
  ELSE
    raise_application_error( -20001, 'You do not own session ''' || p_sid || ',' || p_serial# || '''' );
  END IF;
END;

select * from dba_role_privs where grantee ='FREYA';

SELECT * FROM DBA_SYS_PRIVS WHERE grantee ='SYSTEM';

select * from v$session;


select sid, serial#, username, program,user,module, action, client_info from v$session where program ='SQL Developer';


begin
    
    dbms_application_info.set_module('freyamodule','freyaaction');
    dbms_application_info.set_client_info('myclient');
  end;
  /
select sid, serial#, username, program,user,module, action, client_info from v$session where program ='SQL Developer';

begin
    
    dbms_application_info.set_module(null,null);
    dbms_application_info.set_client_info(null);
  end;
  /
  
  
  create or replace
PROCEDURE usp_kill_session
  (
    p_sid     IN VARCHAR2,
    p_serial# IN VARCHAR2)
              IS
  cursor_name pls_integer DEFAULT dbms_sql.open_cursor;
  ignore pls_integer;
BEGIN
  SELECT COUNT(*)
  INTO ignore
  FROM V$session
  WHERE username = USER
  AND sid        = p_sid
  AND serial#    = p_serial# ;
  IF ( ignore    = 1 ) THEN
    dbms_sql.parse(cursor_name, 'alter system kill session ''' ||p_sid||','||p_serial#||'''', dbms_sql.native);
    ignore := dbms_sql.execute(cursor_name);
  ELSE
    raise_application_error( -20001, 'You do not own session ''' || p_sid || ',' || p_serial# || '''' );
  END IF;
END;
