-- For Oracle, login as the icp_p user using SQL*Plus or TOAD or some other utility.   
-- ORACLE Schema:

-- Insert updated DB_Tools package
CREATE OR REPLACE PACKAGE icp_p.db_tools
IS
  FUNCTION object_exists(v_object_name IN VARCHAR2,
                         v_object_type IN VARCHAR2) RETURN NUMBER;
  FUNCTION constraint_exists(v_constraint_name IN VARCHAR2) RETURN NUMBER;
  PROCEDURE drop_table(v_table_name IN VARCHAR2);
  PROCEDURE drop_index(v_index_name IN VARCHAR2);
  PROCEDURE drop_sequence(v_sequence_name IN VARCHAR2);
  FUNCTION column_exists(p_table_name IN VARCHAR2,
                         p_column_name IN VARCHAR2) RETURN BOOLEAN;
END db_tools;
/

CREATE OR REPLACE PACKAGE BODY icp_p.db_tools
IS
  FUNCTION object_exists(v_object_name IN VARCHAR2,
                         v_object_type IN VARCHAR2) RETURN NUMBER
  IS
    v_object_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(*) INTO v_object_exists
      FROM user_objects
     WHERE object_name = v_object_name
       AND object_type = v_object_type;
    RETURN v_object_exists;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(SQLERRM);
      RAISE;
  END object_exists;
  PROCEDURE drop_table(v_table_name IN VARCHAR2)
  IS
  BEGIN
    IF object_exists(v_table_name, 'TABLE') > 0 THEN
      DBMS_OUTPUT.PUT_LINE(v_table_name||' exists.');
      EXECUTE IMMEDIATE 'drop table '||v_table_name||' purge';
    ELSE
      DBMS_OUTPUT.PUT_LINE(v_table_name||' does not exists.');
    END IF;
  END drop_table;
  PROCEDURE drop_index(v_index_name IN VARCHAR2)
  IS
  BEGIN
    IF object_exists(v_index_name, 'INDEX') > 0 THEN
      DBMS_OUTPUT.PUT_LINE(v_index_name||' exists.');
      EXECUTE IMMEDIATE 'drop index '||v_index_name;
    ELSE
      DBMS_OUTPUT.PUT_LINE(v_index_name||' does not exists.');
    END IF;
  END drop_index;
  procedure drop_sequence(v_sequence_name IN varchar2)
  is
  begin
    if object_exists(v_sequence_name, 'SEQUENCE') > 0 then
      dbms_output.put_line(v_sequence_name||' exists.');
      execute immediate 'drop sequence '||v_sequence_name;
    end if;
  end drop_sequence;
  FUNCTION constraint_exists(v_constraint_name IN VARCHAR2)
   RETURN NUMBER
  IS
    v_constraint_exists NUMBER := 0;
  BEGIN
    SELECT COUNT(*) INTO v_constraint_exists
      FROM user_constraints
     WHERE constraint_name = v_constraint_name;
    RETURN v_constraint_exists;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(SQLERRM);
      RAISE;
  END constraint_exists;

  FUNCTION column_exists(p_table_name IN VARCHAR2,
                         p_column_name IN VARCHAR2)
   RETURN BOOLEAN
  IS
    v_column_exists PLS_INTEGER := 0;
  BEGIN
      SELECT COUNT(*) INTO v_column_exists
        FROM user_tab_columns
       WHERE column_name = p_column_name
         AND table_name  = p_table_name;

   IF v_column_exists = 1 THEN
     RETURN TRUE;
   ELSE
     RETURN FALSE;
   END IF;

  EXCEPTION

      WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(SQLERRM);
      RAISE;

  END column_exists;

end db_tools;
/

begin 
  execute immediate 'ALTER TABLE ICP_P.ROUTE_PARAMETER ADD DDR_ROUTE_OPTION VARCHAR2(10)'; 
  exception when others then null; 
end;
/

UPDATE ICP_P.RULESET_VERSION SET DEPLOYMENT_PENDING = 'Y' 
         WHERE ENTERPRISE_IID  NOT IN
         (SELECT T.DESCENDENT_IID FROM ICP_P.ENTERPRISE E, ICP_P.ENTERPRISE_TREE T
         WHERE E.NAME = 'Overpayment Detection System Enterprise'
         AND T.ANCESTOR_IID = E.ENTERPRISE_IID);


CREATE OR REPLACE FORCE VIEW ICP_P.V_FE_POLICY
(
   IID,
   POLICY_IID,
   POLICY_EID,
   CONTRACTOR_EID,
   CONTRACTOR_DETERMINATION_NUM,
   CMS_NUMBER,
   CONTRACTOR_NUMBER,
   STATUS,
   POLICY_TITLE,
   POLICY_TYPE,
   EFFECTIVE_DATE,
   REVISION_DATE,
   EXPIRATION_DATE,
   EXTRACT_DATE,
   URL,
   PDF_NAME,
   POLICY_PDF,
   ENTERPRISE_IID,
   ENTERPRISE_NAME,
   IS_DISABLED,
   DESCRIPTION,
   COMMENTS,
   IS_OVERRIDE,
   TYPE,
   ICD_VERSION
)
AS
   SELECT temp.POLICY_EID AS iid,
          temp.POLICY_IID,
          temp.POLICY_EID,
          temp.CONTRACTOR_EID,
          temp.CONTRACTOR_DETERMINATION_NUM,
          temp.CMS_NUMBER,
          temp.CONTRACTOR_NUMBER,
          temp.STATUS,
          temp.POLICY_TITLE,
          temp.POLICY_TYPE,
          temp.EFFECTIVE_DATE,
          temp.REVISION_DATE,
          temp.EXPIRATION_DATE,
          temp.EXTRACT_DATE,
          temp.URL,
          temp.PDF_NAME,
          temp.POLICY_PDF,
          temp.ENTERPRISE_IID,
          temp.ENTERPRISE_NAME,
          temp.IS_DISABLED,
          temp.DESCRIPTION,
          temp.COMMENTS,
          temp.IS_OVERRIDE,
          temp.TYPE,
          temp.ICD_VERSION
     FROM (SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  0 enterprise_iid,
                  'System' enterprise_name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'N' is_override,
                  'S' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date)
            WHERE    c.contractor_type = 'MA'
                  OR c.contractor_type = 'FI'
                  OR c.contractor_type = 'NA'
                  OR c.contractor_type = 'DP'
                  OR c.contractor_type = 'DM'
                  OR c.contractor_type = 'DC'
                  OR c.contractor_type = 'RI'
                  OR c.contractor_type = 'DA'
                  OR c.contractor_type = 'ND'
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lro.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_relation_or lro
                     ON (    p.contractor_eid = lro.contractor_or_eid
                         AND p.policy_eid = lro.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lro.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lro.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lro.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lro.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lro.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_relation_or lro
                     ON (    o.contractor_or_eid = lro.contractor_or_eid
                         AND o.policy_or_eid = lro.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lro.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lro.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lro.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lro.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lro.contractor_or_eid
                                      AND lp.policy_eid = lro.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lro.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_relation_or lro
                     ON (    o.contractor_or_eid = lro.contractor_or_eid
                         AND o.policy_or_eid = lro.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lro.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lro.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lro.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lro.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lpro.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_procedure_or lpro
                     ON (    p.contractor_eid = lpro.contractor_or_eid
                         AND p.policy_eid = lpro.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lpro.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lpro.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lpro.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lpro.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lpro.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_procedure_or lpro
                     ON (    o.contractor_or_eid = lpro.contractor_or_eid
                         AND o.policy_or_eid = lpro.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lpro.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lpro.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lpro.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lpro.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lpro.contractor_or_eid
                                      AND lp.policy_eid = lpro.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lpro.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_procedure_or lpro
                     ON (    o.contractor_or_eid = lpro.contractor_or_eid
                         AND o.policy_or_eid = lpro.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lpro.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lpro.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lpro.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lpro.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lfo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_frequency_or lfo
                     ON (    p.contractor_eid = lfo.contractor_or_eid
                         AND p.policy_eid = lfo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lfo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lfo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lfo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lfo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lfo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_frequency_or lfo
                     ON (    o.contractor_or_eid = lfo.contractor_or_eid
                         AND o.policy_or_eid = lfo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lfo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lfo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lfo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lfo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lfo.contractor_or_eid
                                      AND lp.policy_eid = lfo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lfo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_frequency_or lfo
                     ON (    o.contractor_or_eid = lfo.contractor_or_eid
                         AND o.policy_or_eid = lfo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lfo.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lfo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lfo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lfo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lfo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lfo
                     ON (    p.contractor_eid = lfo.contractor_or_eid
                         AND p.policy_eid = lfo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lfo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lfo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lfo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lfo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lfo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lfo
                     ON (    o.contractor_or_eid = lfo.contractor_or_eid
                         AND o.policy_or_eid = lfo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lfo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lfo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lfo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lfo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lfo.contractor_or_eid
                                      AND lp.policy_eid = lfo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lfo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lfo
                     ON (    o.contractor_or_eid = lfo.contractor_or_eid
                         AND o.policy_or_eid = lfo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lfo.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lfo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lfo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lfo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  ldo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_diagnosis_or ldo
                     ON (    p.contractor_eid = ldo.contractor_or_eid
                         AND p.policy_eid = ldo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = ldo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             ldo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             ldo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             ldo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  ldo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_diagnosis_or ldo
                     ON (    o.contractor_or_eid = ldo.contractor_or_eid
                         AND o.policy_or_eid = ldo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = ldo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             ldo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             ldo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             ldo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             ldo.contractor_or_eid
                                      AND lp.policy_eid = ldo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  ldo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_diagnosis_or ldo
                     ON (    o.contractor_or_eid = ldo.contractor_or_eid
                         AND o.policy_or_eid = ldo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = ldo.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             ldo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             ldo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             ldo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lposo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_pos_or lposo
                     ON (    p.contractor_eid = lposo.contractor_or_eid
                         AND p.policy_eid = lposo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lposo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lposo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lposo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lposo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lposo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_pos_or lposo
                     ON (    o.contractor_or_eid = lposo.contractor_or_eid
                         AND o.policy_or_eid = lposo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lposo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lposo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lposo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lposo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lposo.contractor_or_eid
                                      AND lp.policy_eid = lposo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lposo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_pos_or lposo
                     ON (    o.contractor_or_eid = lposo.contractor_or_eid
                         AND o.policy_or_eid = lposo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lposo.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lposo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lposo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lposo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lposo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN LCD_TYPE_OF_BILL_OR lposo
                     ON (    p.contractor_eid = lposo.contractor_or_eid
                         AND p.policy_eid = lposo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lposo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lposo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lposo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lposo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lposo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN LCD_TYPE_OF_BILL_OR lposo
                     ON (    o.contractor_or_eid = lposo.contractor_or_eid
                         AND o.policy_or_eid = lposo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lposo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lposo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lposo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lposo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lposo.contractor_or_eid
                                      AND lp.policy_eid = lposo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lposo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN LCD_TYPE_OF_BILL_OR lposo
                     ON (    o.contractor_or_eid = lposo.contractor_or_eid
                         AND o.policy_or_eid = lposo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lposo.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lposo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lposo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lposo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lposo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN LCD_REVENUE_CODE_OR lposo
                     ON (    p.contractor_eid = lposo.contractor_or_eid
                         AND p.policy_eid = lposo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lposo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lposo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lposo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lposo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lposo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN LCD_REVENUE_CODE_OR lposo
                     ON (    o.contractor_or_eid = lposo.contractor_or_eid
                         AND o.policy_or_eid = lposo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lposo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lposo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lposo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lposo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lposo.contractor_or_eid
                                      AND lp.policy_eid = lposo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lposo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN LCD_REVENUE_CODE_OR lposo
                     ON (    o.contractor_or_eid = lposo.contractor_or_eid
                         AND o.policy_or_eid = lposo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lposo.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lposo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lposo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lposo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lmo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_modifier_or lmo
                     ON (    p.contractor_eid = lmo.contractor_or_eid
                         AND p.policy_eid = lmo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lmo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lmo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lmo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lmo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lmo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_modifier_or lmo
                     ON (    o.contractor_or_eid = lmo.contractor_or_eid
                         AND o.policy_or_eid = lmo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lmo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lmo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lmo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lmo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lmo.contractor_or_eid
                                      AND lp.policy_eid = lmo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lmo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_modifier_or lmo
                     ON (    o.contractor_or_eid = lmo.contractor_or_eid
                         AND o.policy_or_eid = lmo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lmo.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lmo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lmo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lmo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lprovspo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_provider_specialty_or lprovspo
                     ON (    p.contractor_eid = lprovspo.contractor_or_eid
                         AND p.policy_eid = lprovspo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lprovspo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lprovspo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lprovspo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lprovspo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lprovspo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_provider_specialty_or lprovspo
                     ON (    o.contractor_or_eid = lprovspo.contractor_or_eid
                         AND o.policy_or_eid = lprovspo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lprovspo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lprovspo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lprovspo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lprovspo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lprovspo.contractor_or_eid
                                      AND lp.policy_eid =
                                             lprovspo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lprovspo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_provider_specialty_or lprovspo
                     ON (    o.contractor_or_eid = lprovspo.contractor_or_eid
                         AND o.policy_or_eid = lprovspo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lprovspo.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lprovspo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lprovspo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lprovspo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lvalo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_value_code_or lvalo
                     ON (    p.contractor_eid = lvalo.contractor_or_eid
                         AND p.policy_eid = lvalo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lvalo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lvalo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lvalo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lvalo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lvalo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_value_code_or lvalo
                     ON (    o.contractor_or_eid = lvalo.contractor_or_eid
                         AND o.policy_or_eid = lvalo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lvalo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lvalo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lvalo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lvalo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lvalo.contractor_or_eid
                                      AND lp.policy_eid = lvalo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lvalo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_value_code_or lvalo
                     ON (    o.contractor_or_eid = lvalo.contractor_or_eid
                         AND o.policy_or_eid = lvalo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lvalo.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lvalo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lvalo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lvalo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lcondo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_condition_code_or lcondo
                     ON (    p.contractor_eid = lcondo.contractor_or_eid
                         AND p.policy_eid = lcondo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lcondo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lcondo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lcondo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lcondo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lcondo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_condition_code_or lcondo
                     ON (    o.contractor_or_eid = lcondo.contractor_or_eid
                         AND o.policy_or_eid = lcondo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lcondo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lcondo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lcondo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lcondo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lcondo.contractor_or_eid
                                      AND lp.policy_eid =
                                             lcondo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lcondo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_condition_code_or lcondo
                     ON (    o.contractor_or_eid = lcondo.contractor_or_eid
                         AND o.policy_or_eid = lcondo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lcondo.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lcondo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lcondo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lcondo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lc2co.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_c2c_or lc2co
                     ON (    p.contractor_eid = lc2co.contractor_or_eid
                         AND p.policy_eid = lc2co.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lc2co.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lc2co.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lc2co.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lc2co.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lc2co.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_c2c_or lc2co
                     ON (    o.contractor_or_eid = lc2co.contractor_or_eid
                         AND o.policy_or_eid = lc2co.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lc2co.enterprise_iid)
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lc2co.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lc2co.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lc2co.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lc2co.contractor_or_eid
                                      AND lp.policy_eid = lc2co.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lc2co.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_c2c_or lc2co
                     ON (    o.contractor_or_eid = lc2co.contractor_or_eid
                         AND o.policy_or_eid = lc2co.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lc2co.enterprise_iid)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lc2co.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lc2co.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lc2co.enterprise_iid))
           UNION
           SELECT lp.iid policy_iid,
                  lp.policy_or_eid,
                  lp.contractor_or_eid,
                  lp.policy_determination_num,
                  lp.policy_number,
                  c.contractor_number,
                  ld.status,
                  lp.policy_title,
                  NULL policy_type,
                  lp.effective_date,
                  lp.revision_date,
                  lp.expiration_date,
                  TO_CHAR (lp.create_date, 'YYYYMMDD'),
                  lp.url,
                  lp.pdf_name,
                  NULL POLICY_PDF,
                  lp.enterprise_iid,
                  e.name,
                  lp.is_disabled,
                  lp.description,
                  lp.comments,
                  'Y' is_override,
                  'C' TYPE,
                  lp.icd_version
             FROM lcd_policy_or lp
                  JOIN enterprise e ON (e.enterprise_iid = lp.enterprise_iid)
                  JOIN lcd_contractor c
                     ON (c.contractor_eid = lp.CONTRACTOR_OR_EID)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
           UNION
           SELECT lp.iid policy_iid,
                  lp.policy_or_eid,
                  lp.contractor_or_eid,
                  lp.policy_determination_num,
                  lp.policy_number,
                  c.contractor_number,
                  'A' status,
                  lp.policy_title,
                  NULL policy_type,
                  lp.effective_date,
                  lp.revision_date,
                  lp.expiration_date,
                  TO_CHAR (lp.create_date, 'YYYYMMDD'),
                  lp.url,
                  lp.pdf_name,
                  NULL POLICY_PDF,
                  lp.enterprise_iid,
                  e.name,
                  lp.is_disabled,
                  lp.description,
                  lp.comments,
                  'Y' is_override,
                  'C' TYPE,
                  lp.icd_version
             FROM lcd_policy_or lp
                  JOIN enterprise e ON (e.enterprise_iid = lp.enterprise_iid)
                  JOIN lcd_contractor_or c
                     ON (c.contractor_or_eid = lp.CONTRACTOR_OR_EID)) temp;

-- END V_FE_POLICY

CREATE OR REPLACE FORCE VIEW ICP_P.V_GROUPER_REBUNDLE_UNIFIED
(
   IID,
   PROCEDURE_CODE,
   GROUPER_EID,
   EFFECTIVE_DATE,
   EXPIRATION_DATE,
   DISCLOSURE_EID,
   KB_SOURCE,
   TABLE_ORIGIN
)
AS
   SELECT g.GROUPER_IID AS IID,
          COALESCE (g.PROCEDURE_CODE, r.PROCEDURE_CODE) AS "PROCEDURE_CODE",
          COALESCE (g.GROUPER_EID, r.GROUPER_EID) AS "GROUPER_EID",
          COALESCE (g.EFFECTIVE_DATE, r.EFFECTIVE_DATE) AS "EFFECTIVE_DATE",
          CASE
             WHEN (    g.PROCEDURE_CODE IS NOT NULL
                   AND r.PROCEDURE_CODE IS NOT NULL)
             THEN
                g.EXPIRATION_DATE
             WHEN (g.PROCEDURE_CODE IS NOT NULL AND r.PROCEDURE_CODE IS NULL)
             THEN
                g.EXPIRATION_DATE
             WHEN (g.PROCEDURE_CODE IS NULL AND r.PROCEDURE_CODE IS NOT NULL)
             THEN
                r.EXPIRATION_DATE
          END
             AS "EXPIRATION_DATE",
          COALESCE (g.DISCLOSURE_EID, r.DISCLOSURE_EID) AS "DISCLOSURE_EID",
          COALESCE (g.KB_SOURCE_EID, r.KB_SOURCE_EID) AS "KB_SOURCE",
          CASE
             WHEN (    g.PROCEDURE_CODE IS NOT NULL
                   AND r.PROCEDURE_CODE IS NOT NULL)
             THEN
                'Both'
             WHEN (g.PROCEDURE_CODE IS NOT NULL AND r.PROCEDURE_CODE IS NULL)
             THEN
                'Grouper'
             WHEN (g.PROCEDURE_CODE IS NULL AND r.PROCEDURE_CODE IS NOT NULL)
             THEN
                'Rebundle'
          END
             AS "TABLE_ORIGIN"
     FROM GROUPER g
          FULL JOIN REBUNDLE r
             ON     g.PROCEDURE_CODE = r.PROCEDURE_CODE
                AND g.GROUPER_EID = r.GROUPER_EID;

-- END V_GROUPER_REBUNDLE_UNIFIED


CREATE OR REPLACE FORCE VIEW ICP_P.V_LCD_CONTRACTOR
(
   IID,
   CONTRACTOR_EID,
   CONTRACTOR_NAME,
   CONTRACTOR_NUMBER,
   CONTRACTOR_TYPE,
   EXTRACT_DATE,
   IMPORT_DATE,
   ENTERPRISE_IID,
   ENTERPRISE_NAME,
   DESCRIPTION,
   IS_OVERRIDE,
   STATUS
)
AS
   SELECT temp.LCD_CONTRACTOR_IID AS iid,
          temp.contractor_eid,
          temp.contractor_name,
          temp.contractor_number,
          temp.contractor_type,
          temp.extract_date,
          temp.import_date,
          temp.enterprise_iid,
          temp.enterprise_name,
          temp.description,
          temp.is_override,
          temp.status
     FROM (SELECT lc.LCD_CONTRACTOR_IID,
                  lc.contractor_eid CONTRACTOR_EID,
                  lc.contractor_name CONTRACTOR_NAME,
                  lc.contractor_number CONTRACTOR_NUMBER,
                  lc.contractor_type CONTRACTOR_TYPE,
                  lc.extract_date EXTRACT_DATE,
                  ld.import_date IMPORT_DATE,
                  0 ENTERPRISE_IID,
                  'System' ENTERPRISE_NAME,
                  NULL DESCRIPTION,
                  'N' IS_OVERRIDE,
                  ld.status STATUS
             FROM lcd_contractor lc
                  JOIN lcd_data ld
                     ON (    lc.contractor_eid = ld.contractor_eid
                         AND lc.extract_date = ld.extract_date)
           UNION
           SELECT l.iid IID,
                  l.contractor_or_eid CONTRACTOR_EID,
                  l.contractor_name CONTRACTOR_NAME,
                  l.contractor_number CONTRACTOR_NUMBER,
                  l.contractor_type CONTRACTOR_TYPE,
                  TO_CHAR (l.create_date, 'YYYYMMDD') EXTRACT_DATE,
                  NULL IMPORT_DATE,
                  l.enterprise_iid ENTERPRISE_IID,
                  e.name ENTERPRISE_NAME,
                  l.description DESCRIPTION,
                  'Y' IS_OVERRIDE,
                  'A' STATUS
             FROM lcd_contractor_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid))
          temp;

-- END V_LCD_CONTRACTOR


CREATE OR REPLACE FORCE VIEW ICP_P.V_LCD_DATA_CONTRACTOR
(
   V_LCD_DATA_CONTRACTOR_IID,
   LCD_CONTRACTOR_IID,
   CONTRACTOR_EID,
   CONTRACTOR_NAME,
   CONTRACTOR_NUMBER,
   CONTRACTOR_TYPE,
   EXTRACT_DATE,
   STATUS,
   IMPORT_DATE
)
AS
   SELECT lc.lcd_contractor_iid AS v_lcd_data_contractor_iid,
          lc.lcd_contractor_iid,
          lc.contractor_eid,
          lc.contractor_name,
          lc.contractor_number,
          lc.contractor_type,
          lc.extract_date,
          ld.status,
          ld.import_date
     FROM lcd_contractor lc
          JOIN lcd_data ld
             ON (    lc.contractor_eid = ld.contractor_eid
                 AND lc.extract_date = ld.extract_date);

-- END V_LCD_DATA_CONTRACTOR


CREATE OR REPLACE FORCE VIEW ICP_P.V_LCD_FE_PROCEDURE_OVERRIDE
(
   IID,
   POLICY_EID,
   CONTRACTOR_EID,
   RELATION_EID,
   PROCEDURE_CODE,
   SUPPORT,
   EFFECTIVE_DATE,
   EXPIRATION_DATE,
   TYPE,
   IS_DISABLED,
   EXTRACT_DATE,
   ENTERPRISE_IID,
   ENTERPRISE_NAME,
   IS_OVERRIDE,
   IS_ORIGINAL,
   PROCEDURE_TYPE,
   STATUS,
   POLICY_NUMBER,
   CONTRACTOR_NUMBER,
   CONTRACTOR_DETERMINATION_NUM,
   IMPORT_DATE,
   CMS_NUMBER
)
AS
   SELECT temp.LCD_PROCEDURE_IID AS iid,
          temp.POLICY_EID,
          temp.CONTRACTOR_EID,
          temp.RELATION_EID,
          temp.PROCEDURE_CODE,
          temp.SUPPORT,
          temp.EFFECTIVE_DATE,
          temp.EXPIRATION_DATE,
          temp.TYPE,
          temp.IS_DISABLED,
          temp.EXTRACT_DATE,
          temp.ENTERPRISE_IID,
          temp.ENTERPRISE_NAME,
          temp.IS_OVERRIDE,
          temp.IS_ORIGINAL,
          temp.PROCEDURE_TYPE,
          temp.STATUS,
          temp.POLICY_NUMBER,
          temp.CONTRACTOR_NUMBER,
          temp.CONTRACTOR_DETERMINATION_NUM,
          temp.IMPORT_DATE,
          temp.CMS_NUMBER
     FROM (SELECT lpr.lcd_procedure_iid,
                  lpr.policy_eid,
                  lpr.contractor_eid,
                  lpr.relation_eid,
                  lpr.procedure_code,
                  lpr.support,
                  lpr.effective_date,
                  lpr.expiration_date,
                  lpr.TYPE,
                  'N' is_disabled,
                  lpr.extract_date,
                  0 enterprise_iid,
                  'System' enterprise_name,
                  'N' is_override,
                  'Y' is_original,
                  'S' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_policy lp
                  INNER JOIN lcd_contractor c
                     ON (    lp.contractor_eid = c.contractor_eid
                         AND lp.extract_date = c.extract_date)
                  JOIN lcd_procedure lpr
                     ON (    lpr.policy_eid = lp.policy_eid
                         AND lpr.extract_date = lp.extract_date
                         AND lpr.policy_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date)
            WHERE    c.contractor_type = 'MA'
                  OR c.contractor_type = 'FI'
                  OR c.contractor_type = 'NA'
                  OR c.contractor_type = 'DP'
                  OR c.contractor_type = 'DM'
                  OR c.contractor_type = 'DC'
                  OR c.contractor_type = 'RI'
                  OR c.contractor_type = 'DA'
                  OR c.contractor_type = 'ND'
           UNION
           SELECT l.iid,
                  l.policy_or_eid,
                  l.contractor_or_eid,
                  l.RELATION_OR_EID,
                  l.procedure_code,
                  l.support,
                  l.effective_date,
                  l.expiration_date,
                  NULL TYPE,
                  l.is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  l.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'Y' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  ld.IMPORT_DATE,
                  NULL
             FROM lcd_procedure_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    l.contractor_or_eid = lo.contractor_or_eid
                         AND l.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date)
            WHERE    c.contractor_type = 'MA'
                  OR c.contractor_type = 'FI'
                  OR c.contractor_type = 'NA'
                  OR c.contractor_type = 'DP'
                  OR c.contractor_type = 'DM'
                  OR c.contractor_type = 'DC'
                  OR c.contractor_type = 'RI'
                  OR c.contractor_type = 'DA'
                  OR c.contractor_type = 'ND'
           UNION
           SELECT l.iid,
                  l.policy_or_eid,
                  l.contractor_or_eid,
                  l.RELATION_OR_EID,
                  l.procedure_code,
                  l.support,
                  l.effective_date,
                  l.expiration_date,
                  NULL TYPE,
                  l.is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  l.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'Y' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' Status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  NULL,
                  NULL
             FROM lcd_procedure_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    l.contractor_or_eid = lo.contractor_or_eid
                         AND l.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE (c.contractor_type = 'FACILITYCUSTOM')
           UNION
           SELECT l.iid,
                  l.policy_or_eid,
                  l.contractor_or_eid,
                  l.RELATION_OR_EID,
                  l.procedure_code,
                  l.support,
                  l.effective_date,
                  l.expiration_date,
                  NULL TYPE,
                  l.is_disabled,
                  lp.extract_date,
                  l.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'Y' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_procedure_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    l.contractor_or_eid = lp.contractor_eid
                         AND l.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  l.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  l.CMS_NUMBER
             FROM lcd_procedure lp
                  INNER JOIN lcd_frequency_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    l.contractor_eid = lp.contractor_eid
                         AND l.policy_eid = lp.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  ld.IMPORT_DATE,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_frequency_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  NULL,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_frequency_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_procedure_or o
                  INNER JOIN lcd_frequency_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  l.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  l.CMS_NUMBER
             FROM lcd_procedure lp
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    l.contractor_eid = lp.contractor_eid
                         AND l.policy_eid = lp.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  ld.IMPORT_DATE,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  NULL,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_procedure_or o
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  l.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  l.CMS_NUMBER
             FROM lcd_procedure lp
                  INNER JOIN lcd_diagnosis_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    lp.contractor_eid = l.contractor_eid
                         AND lp.policy_eid = l.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  ld.IMPORT_DATE,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_diagnosis_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  NULL,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_diagnosis_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_procedure_or o
                  INNER JOIN lcd_diagnosis_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  l.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  l.CMS_NUMBER
             FROM lcd_procedure lp
                  INNER JOIN lcd_pos_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    lp.contractor_eid = l.contractor_eid
                         AND lp.policy_eid = l.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  ld.IMPORT_DATE,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_pos_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  NULL,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_pos_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_procedure_or o
                  INNER JOIN lcd_pos_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  l.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  l.CMS_NUMBER
             FROM lcd_procedure lp
                  INNER JOIN LCD_TYPE_OF_BILL_OR lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    lp.contractor_eid = l.contractor_eid
                         AND lp.policy_eid = l.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  ld.IMPORT_DATE,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN LCD_TYPE_OF_BILL_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  NULL,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN LCD_TYPE_OF_BILL_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_procedure_or o
                  INNER JOIN LCD_TYPE_OF_BILL_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  l.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  l.CMS_NUMBER
             FROM lcd_procedure lp
                  INNER JOIN LCD_REVENUE_CODE_OR lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    lp.contractor_eid = l.contractor_eid
                         AND lp.policy_eid = l.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  ld.IMPORT_DATE,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN LCD_REVENUE_CODE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  NULL,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN LCD_REVENUE_CODE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_procedure_or o
                  INNER JOIN LCD_REVENUE_CODE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  l.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  l.CMS_NUMBER
             FROM lcd_procedure lp
                  INNER JOIN lcd_modifier_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    l.contractor_eid = lp.contractor_eid
                         AND l.policy_eid = lp.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  ld.IMPORT_DATE,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_modifier_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  NULL,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_modifier_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_procedure_or o
                  INNER JOIN lcd_modifier_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  l.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  l.CMS_NUMBER
             FROM lcd_procedure lp
                  INNER JOIN lcd_provider_specialty_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    l.contractor_eid = lp.contractor_eid
                         AND l.policy_eid = lp.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  ld.IMPORT_DATE,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_provider_specialty_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  NULL,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_provider_specialty_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_procedure_or o
                  INNER JOIN lcd_provider_specialty_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  l.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  l.CMS_NUMBER
             FROM lcd_procedure lp
                  INNER JOIN lcd_value_code_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    l.contractor_eid = lp.contractor_eid
                         AND l.policy_eid = lp.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  ld.IMPORT_DATE,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_value_code_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  NULL,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_value_code_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_procedure_or o
                  INNER JOIN lcd_value_code_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  l.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  l.CMS_NUMBER
             FROM lcd_procedure lp
                  INNER JOIN lcd_condition_code_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    l.contractor_eid = lp.contractor_eid
                         AND l.policy_eid = lp.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  ld.IMPORT_DATE,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_condition_code_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  NULL,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_condition_code_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_procedure_or o
                  INNER JOIN lcd_condition_code_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  l.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  l.CMS_NUMBER
             FROM lcd_procedure lp
                  INNER JOIN lcd_c2c_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    l.contractor_eid = lp.contractor_eid
                         AND l.policy_eid = lp.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  ld.IMPORT_DATE,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_c2c_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number,
                  NULL,
                  NULL,
                  NULL
             FROM lcd_procedure_or o
                  INNER JOIN lcd_c2c_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'FACILITYCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number,
                  lp.CONTRACTOR_DETERMINATION_NUM,
                  ld.IMPORT_DATE,
                  lp.CMS_NUMBER
             FROM lcd_procedure_or o
                  INNER JOIN lcd_c2c_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MA'
                       OR c.contractor_type = 'FI'
                       OR c.contractor_type = 'NA'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'RI'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))) temp;

-- END V_LCD_FE_PROCEDURE_OVERRIDE



CREATE OR REPLACE FORCE VIEW ICP_P.V_LCD_ORIGINAL_POLICY_OR
(
   IID,
   POLICY_IID,
   POLICY_EID,
   CONTRACTOR_EID,
   CONTRACTOR_DETERMINATION_NUM,
   CMS_NUMBER,
   CONTRACTOR_NUMBER,
   STATUS,
   POLICY_TITLE,
   POLICY_TYPE,
   EFFECTIVE_DATE,
   REVISION_DATE,
   EXPIRATION_DATE,
   EXTRACT_DATE,
   URL,
   PDF_NAME,
   POLICY_PDF,
   ENTERPRISE_IID,
   ENTERPRISE_NAME,
   IS_DISABLED,
   DESCRIPTION,
   COMMENTS,
   IS_OVERRIDE,
   TYPE,
   ICD_VERSION
)
AS
   SELECT temp.POLICY_IID AS iid,
          temp.POLICY_IID,
          temp.POLICY_EID,
          temp.CONTRACTOR_EID,
          temp.CONTRACTOR_DETERMINATION_NUM,
          temp.CMS_NUMBER,
          temp.CONTRACTOR_NUMBER,
          temp.STATUS,
          temp.POLICY_TITLE,
          temp.POLICY_TYPE,
          temp.EFFECTIVE_DATE,
          temp.REVISION_DATE,
          temp.EXPIRATION_DATE,
          temp.EXTRACT_DATE,
          temp.URL,
          temp.PDF_NAME,
          temp.POLICY_PDF,
          temp.ENTERPRISE_IID,
          temp.ENTERPRISE_NAME,
          temp.IS_DISABLED,
          temp.DESCRIPTION,
          temp.COMMENTS,
          temp.IS_OVERRIDE,
          temp.TYPE,
          temp.ICD_VERSION
     FROM (SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  0 enterprise_iid,
                  'System' enterprise_name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'N' is_override,
                  'S' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date)
           UNION
           SELECT lp.iid policy_iid,
                  lp.policy_or_eid,
                  lp.contractor_or_eid,
                  lp.policy_determination_num,
                  lp.policy_number,
                  c.contractor_number,
                  ld.status,
                  lp.policy_title,
                  NULL policy_type,
                  lp.effective_date,
                  lp.revision_date,
                  lp.expiration_date,
                  TO_CHAR (lp.create_date, 'YYYYMMDD'),
                  lp.url,
                  lp.pdf_name,
                  NULL POLICY_PDF,
                  lp.enterprise_iid,
                  e.name,
                  lp.is_disabled,
                  lp.description,
                  lp.comments,
                  'Y' is_override,
                  'C' TYPE,
                  lp.icd_version
             FROM lcd_policy_or lp
                  JOIN enterprise e ON (e.enterprise_iid = lp.enterprise_iid)
                  JOIN lcd_contractor c
                     ON (c.contractor_eid = lp.CONTRACTOR_OR_EID)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
           UNION
           SELECT lp.iid policy_iid,
                  lp.policy_or_eid,
                  lp.contractor_or_eid,
                  lp.policy_determination_num,
                  lp.policy_number,
                  c.contractor_number,
                  'A' status,
                  lp.policy_title,
                  NULL policy_type,
                  lp.effective_date,
                  lp.revision_date,
                  lp.expiration_date,
                  TO_CHAR (lp.create_date, 'YYYYMMDD'),
                  lp.url,
                  lp.pdf_name,
                  NULL POLICY_PDF,
                  lp.enterprise_iid,
                  e.name,
                  lp.is_disabled,
                  lp.description,
                  lp.comments,
                  'Y' is_override,
                  'C' TYPE,
                  lp.icd_version
             FROM lcd_policy_or lp
                  JOIN enterprise e ON (e.enterprise_iid = lp.enterprise_iid)
                  JOIN lcd_contractor_or c
                     ON (c.contractor_or_eid = lp.CONTRACTOR_OR_EID)) temp;


-- END V_LCD_ORIGINAL_POLICY_OR




CREATE OR REPLACE FORCE VIEW ICP_P.V_LCD_ORIGINAL_PROCEDURE_OR
(
   IID,
   POLICY_EID,
   CONTRACTOR_EID,
   RELATION_EID,
   PROCEDURE_CODE,
   SUPPORT,
   EFFECTIVE_DATE,
   EXPIRATION_DATE,
   TYPE,
   IS_DISABLED,
   EXTRACT_DATE,
   ENTERPRISE_IID,
   ENTERPRISE_NAME,
   IS_OVERRIDE,
   IS_ORIGINAL
)
AS
   SELECT temp.iid AS iid,
          temp.POLICY_EID,
          temp.CONTRACTOR_EID,
          temp.RELATION_EID,
          temp.PROCEDURE_CODE,
          temp.SUPPORT,
          temp.EFFECTIVE_DATE,
          temp.EXPIRATION_DATE,
          temp.TYPE,
          temp.IS_DISABLED,
          temp.EXTRACT_DATE,
          temp.ENTERPRISE_IID,
          temp.ENTERPRISE_NAME,
          temp.IS_OVERRIDE,
          temp.IS_ORIGINAL
     FROM (SELECT lcd_procedure_iid iid,
                  policy_eid,
                  contractor_eid,
                  relation_eid,
                  procedure_code,
                  support,
                  effective_date,
                  expiration_date,
                  TYPE,
                  'N' is_disabled,
                  extract_date,
                  0 enterprise_iid,
                  'System' enterprise_name,
                  'N' is_override,
                  'Y' is_original
             FROM lcd_procedure
           UNION
           SELECT l.iid,
                  l.policy_or_eid,
                  l.contractor_or_eid,
                  l.RELATION_OR_EID,
                  l.procedure_code,
                  l.support,
                  l.effective_date,
                  l.expiration_date,
                  NULL TYPE,
                  l.is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  l.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'Y' is_original
             FROM lcd_procedure_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    l.contractor_or_eid = lo.contractor_or_eid
                         AND l.policy_or_eid = lo.policy_or_eid)
           UNION
           SELECT l.iid,
                  l.policy_or_eid,
                  l.contractor_or_eid,
                  l.RELATION_OR_EID,
                  l.procedure_code,
                  l.support,
                  l.effective_date,
                  l.expiration_date,
                  NULL TYPE,
                  l.is_disabled,
                  lp.extract_date,
                  l.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'Y' is_original
             FROM lcd_procedure_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    l.contractor_or_eid = lp.contractor_eid
                         AND l.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_policy_or po
                            WHERE     po.contractor_or_eid =
                                         lp.contractor_eid
                                  AND po.policy_or_eid = lp.policy_eid)))
          temp;


-- END V_LCD_ORIGINAL_PROCEDURE_OR



CREATE OR REPLACE FORCE VIEW ICP_P.V_LCD_ORIGINAL_RELATION_OR
(
   IID,
   POLICY_EID,
   CONTRACTOR_EID,
   RELATION_EID,
   EDIT_ACTION_TYPE,
   CATEGORY,
   GROUP_NUM,
   EXTRACT_DATE,
   ENTERPRISE_IID,
   ENTERPRISE_NAME,
   IS_OVERRIDE
)
AS
   SELECT temp.iid AS iid,
          temp.POLICY_EID,
          temp.CONTRACTOR_EID,
          temp.RELATION_EID,
          temp.EDIT_ACTION_TYPE,
          temp.CATEGORY,
          temp.GROUP_NUM,
          temp.EXTRACT_DATE,
          temp.ENTERPRISE_IID,
          temp.ENTERPRISE_NAME,
          temp.IS_OVERRIDE
     FROM (SELECT lcd_relation_iid iid,
                  policy_eid,
                  contractor_eid,
                  relation_eid,
                  edit_action_type,
                  category,
                  group_num,
                  extract_date,
                  0 enterprise_iid,
                  'System' enterprise_name,
                  'N' is_override
             FROM lcd_relation
           UNION
           SELECT l.iid,
                  l.policy_or_eid,
                  l.contractor_or_eid,
                  l.relation_or_eid,
                  l.edit_action_type,
                  l.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  l.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    l.contractor_or_eid = lo.contractor_or_eid
                         AND l.policy_or_eid = lo.policy_or_eid)
           UNION
           SELECT l.iid,
                  l.policy_or_eid,
                  l.contractor_or_eid,
                  l.relation_or_eid,
                  l.edit_action_type,
                  l.category,
                  NULL group_num,
                  lp.extract_date,
                  l.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    l.contractor_or_eid = lp.contractor_eid
                         AND l.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')) temp;

-- END V_LCD_ORIGINAL_RELATION_OR




CREATE OR REPLACE FORCE VIEW ICP_P.V_LCD_POLICY_OVERRIDE
(
   IID,
   POLICY_IID,
   POLICY_EID,
   CONTRACTOR_EID,
   CONTRACTOR_DETERMINATION_NUM,
   CMS_NUMBER,
   CONTRACTOR_NUMBER,
   STATUS,
   POLICY_TITLE,
   POLICY_TYPE,
   EFFECTIVE_DATE,
   REVISION_DATE,
   EXPIRATION_DATE,
   EXTRACT_DATE,
   URL,
   PDF_NAME,
   POLICY_PDF,
   ENTERPRISE_IID,
   ENTERPRISE_NAME,
   IS_DISABLED,
   DESCRIPTION,
   COMMENTS,
   IS_OVERRIDE,
   TYPE,
   ICD_VERSION
)
AS
   SELECT temp.POLICY_IID AS iid,
          temp.POLICY_IID,
          temp.POLICY_EID,
          temp.CONTRACTOR_EID,
          temp.CONTRACTOR_DETERMINATION_NUM,
          temp.CMS_NUMBER,
          temp.CONTRACTOR_NUMBER,
          temp.STATUS,
          temp.POLICY_TITLE,
          temp.POLICY_TYPE,
          temp.EFFECTIVE_DATE,
          temp.REVISION_DATE,
          temp.EXPIRATION_DATE,
          temp.EXTRACT_DATE,
          temp.URL,
          temp.PDF_NAME,
          temp.POLICY_PDF,
          temp.ENTERPRISE_IID,
          temp.ENTERPRISE_NAME,
          temp.IS_DISABLED,
          temp.DESCRIPTION,
          temp.COMMENTS,
          temp.IS_OVERRIDE,
          temp.TYPE,
          temp.ICD_VERSION
     FROM (SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  0 enterprise_iid,
                  'System' enterprise_name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'N' is_override,
                  'S' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date)
            WHERE    c.contractor_type = 'MB'
                  OR c.contractor_type = 'CA'
                  OR c.contractor_type = 'NB'
                  OR c.contractor_type = 'DP'
                  OR c.contractor_type = 'DM'
                  OR c.contractor_type = 'DC'
                  OR c.contractor_type = 'DA'
                  OR c.contractor_type = 'ND'
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lro.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_relation_or lro
                     ON (    p.contractor_eid = lro.contractor_or_eid
                         AND p.policy_eid = lro.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lro.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lro.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lro.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lro.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lro.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_relation_or lro
                     ON (    o.contractor_or_eid = lro.contractor_or_eid
                         AND o.policy_or_eid = lro.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lro.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lro.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lro.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lro.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lro.contractor_or_eid
                                      AND lp.policy_eid = lro.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lro.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_relation_or lro
                     ON (    o.contractor_or_eid = lro.contractor_or_eid
                         AND o.policy_or_eid = lro.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lro.enterprise_iid)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lro.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lro.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lro.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lpro.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_procedure_or lpro
                     ON (    p.contractor_eid = lpro.contractor_or_eid
                         AND p.policy_eid = lpro.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lpro.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lpro.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lpro.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lpro.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lpro.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_procedure_or lpro
                     ON (    o.contractor_or_eid = lpro.contractor_or_eid
                         AND o.policy_or_eid = lpro.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lpro.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lpro.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lpro.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lpro.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lpro.contractor_or_eid
                                      AND lp.policy_eid = lpro.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lpro.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_procedure_or lpro
                     ON (    o.contractor_or_eid = lpro.contractor_or_eid
                         AND o.policy_or_eid = lpro.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lpro.enterprise_iid)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lpro.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lpro.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lpro.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lfo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_frequency_or lfo
                     ON (    p.contractor_eid = lfo.contractor_or_eid
                         AND p.policy_eid = lfo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lfo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lfo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lfo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lfo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lfo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_frequency_or lfo
                     ON (    o.contractor_or_eid = lfo.contractor_or_eid
                         AND o.policy_or_eid = lfo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lfo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lfo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lfo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lfo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lfo.contractor_or_eid
                                      AND lp.policy_eid = lfo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lfo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_frequency_or lfo
                     ON (    o.contractor_or_eid = lfo.contractor_or_eid
                         AND o.policy_or_eid = lfo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lfo.enterprise_iid)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lfo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lfo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lfo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lfo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lfo
                     ON (    p.contractor_eid = lfo.contractor_or_eid
                         AND p.policy_eid = lfo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lfo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lfo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lfo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lfo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lfo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lfo
                     ON (    o.contractor_or_eid = lfo.contractor_or_eid
                         AND o.policy_or_eid = lfo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lfo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lfo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lfo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lfo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lfo.contractor_or_eid
                                      AND lp.policy_eid = lfo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lfo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lfo
                     ON (    o.contractor_or_eid = lfo.contractor_or_eid
                         AND o.policy_or_eid = lfo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lfo.enterprise_iid)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lfo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lfo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lfo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  ldo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_diagnosis_or ldo
                     ON (    p.contractor_eid = ldo.contractor_or_eid
                         AND p.policy_eid = ldo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = ldo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             ldo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             ldo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             ldo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  ldo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_diagnosis_or ldo
                     ON (    o.contractor_or_eid = ldo.contractor_or_eid
                         AND o.policy_or_eid = ldo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = ldo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             ldo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             ldo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             ldo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             ldo.contractor_or_eid
                                      AND lp.policy_eid = ldo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  ldo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_diagnosis_or ldo
                     ON (    o.contractor_or_eid = ldo.contractor_or_eid
                         AND o.policy_or_eid = ldo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = ldo.enterprise_iid)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             ldo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             ldo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             ldo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lposo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_pos_or lposo
                     ON (    p.contractor_eid = lposo.contractor_or_eid
                         AND p.policy_eid = lposo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lposo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lposo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lposo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lposo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lposo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_pos_or lposo
                     ON (    o.contractor_or_eid = lposo.contractor_or_eid
                         AND o.policy_or_eid = lposo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lposo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lposo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lposo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lposo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lposo.contractor_or_eid
                                      AND lp.policy_eid = lposo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lposo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_pos_or lposo
                     ON (    o.contractor_or_eid = lposo.contractor_or_eid
                         AND o.policy_or_eid = lposo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lposo.enterprise_iid)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lposo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lposo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lposo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lmo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_modifier_or lmo
                     ON (    p.contractor_eid = lmo.contractor_or_eid
                         AND p.policy_eid = lmo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lmo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lmo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lmo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lmo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lmo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_modifier_or lmo
                     ON (    o.contractor_or_eid = lmo.contractor_or_eid
                         AND o.policy_or_eid = lmo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lmo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lmo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lmo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lmo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lmo.contractor_or_eid
                                      AND lp.policy_eid = lmo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lmo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_modifier_or lmo
                     ON (    o.contractor_or_eid = lmo.contractor_or_eid
                         AND o.policy_or_eid = lmo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lmo.enterprise_iid)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lmo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lmo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lmo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lprovspo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_provider_specialty_or lprovspo
                     ON (    p.contractor_eid = lprovspo.contractor_or_eid
                         AND p.policy_eid = lprovspo.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lprovspo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lprovspo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lprovspo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lprovspo.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lprovspo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_provider_specialty_or lprovspo
                     ON (    o.contractor_or_eid = lprovspo.contractor_or_eid
                         AND o.policy_or_eid = lprovspo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lprovspo.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lprovspo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lprovspo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lprovspo.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lprovspo.contractor_or_eid
                                      AND lp.policy_eid =
                                             lprovspo.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lprovspo.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_provider_specialty_or lprovspo
                     ON (    o.contractor_or_eid = lprovspo.contractor_or_eid
                         AND o.policy_or_eid = lprovspo.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lprovspo.enterprise_iid)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lprovspo.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lprovspo.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lprovspo.enterprise_iid))
           UNION
           SELECT p.lcd_policy_iid policy_iid,
                  p.policy_eid,
                  p.contractor_eid,
                  p.contractor_determination_num,
                  p.cms_number,
                  c.contractor_number,
                  ld.status,
                  p.policy_title,
                  p.policy_type,
                  p.effective_date,
                  p.revision_date,
                  p.expiration_date,
                  p.extract_date,
                  p.url,
                  p.pdf_name,
                  NULL POLICY_PDF,
                  lc2co.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  p.icd_version
             FROM lcd_policy p
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = p.contractor_eid
                         AND c.extract_date = p.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_c2c_or lc2co
                     ON (    p.contractor_eid = lc2co.contractor_or_eid
                         AND p.policy_eid = lc2co.policy_or_eid)
                  JOIN enterprise e
                     ON (e.enterprise_iid = lc2co.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lc2co.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lc2co.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lc2co.enterprise_iid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  ld.status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lc2co.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = o.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (o.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
                  INNER JOIN lcd_c2c_or lc2co
                     ON (    o.contractor_or_eid = lc2co.contractor_or_eid
                         AND o.policy_or_eid = lc2co.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lc2co.enterprise_iid)
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lc2co.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lc2co.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lc2co.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy lp
                                WHERE     lp.contractor_eid =
                                             lc2co.contractor_or_eid
                                      AND lp.policy_eid = lc2co.policy_or_eid))
           UNION
           SELECT o.iid policy_iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.policy_determination_num,
                  o.policy_number,
                  c.contractor_number,
                  'A' status,
                  o.policy_title,
                  NULL policy_type,
                  o.effective_date,
                  o.revision_date,
                  o.expiration_date,
                  TO_CHAR (o.create_date, 'YYYYMMDD'),
                  o.url,
                  o.pdf_name,
                  NULL POLICY_PDF,
                  lc2co.enterprise_iid,
                  e.name,
                  'N' is_disabled,
                  NULL description,
                  NULL comments,
                  'Y' is_override,
                  'C' TYPE,
                  o.icd_version
             FROM lcd_policy_or o
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = o.contractor_or_eid
                         AND c.create_date = o.create_date)
                  INNER JOIN lcd_c2c_or lc2co
                     ON (    o.contractor_or_eid = lc2co.contractor_or_eid
                         AND o.policy_or_eid = lc2co.policy_or_eid)
                  INNER JOIN enterprise e
                     ON (e.enterprise_iid = lc2co.enterprise_iid)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or lpo
                                WHERE     lpo.contractor_or_eid =
                                             lc2co.contractor_or_eid
                                      AND lpo.policy_or_eid =
                                             lc2co.policy_or_eid
                                      AND lpo.enterprise_iid =
                                             lc2co.enterprise_iid))
           UNION
           SELECT lp.iid policy_iid,
                  lp.policy_or_eid,
                  lp.contractor_or_eid,
                  lp.policy_determination_num,
                  lp.policy_number,
                  c.contractor_number,
                  ld.status,
                  lp.policy_title,
                  NULL policy_type,
                  lp.effective_date,
                  lp.revision_date,
                  lp.expiration_date,
                  TO_CHAR (lp.create_date, 'YYYYMMDD'),
                  lp.url,
                  lp.pdf_name,
                  NULL POLICY_PDF,
                  lp.enterprise_iid,
                  e.name,
                  lp.is_disabled,
                  lp.description,
                  lp.comments,
                  'Y' is_override,
                  'C' TYPE,
                  lp.icd_version
             FROM lcd_policy_or lp
                  JOIN enterprise e ON (e.enterprise_iid = lp.enterprise_iid)
                  JOIN lcd_contractor c
                     ON (c.contractor_eid = lp.CONTRACTOR_OR_EID)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
           UNION
           SELECT lp.iid policy_iid,
                  lp.policy_or_eid,
                  lp.contractor_or_eid,
                  lp.policy_determination_num,
                  lp.policy_number,
                  c.contractor_number,
                  'A' status,
                  lp.policy_title,
                  NULL policy_type,
                  lp.effective_date,
                  lp.revision_date,
                  lp.expiration_date,
                  TO_CHAR (lp.create_date, 'YYYYMMDD'),
                  lp.url,
                  lp.pdf_name,
                  NULL POLICY_PDF,
                  lp.enterprise_iid,
                  e.name,
                  lp.is_disabled,
                  lp.description,
                  lp.comments,
                  'Y' is_override,
                  'C' TYPE,
                  lp.icd_version
             FROM lcd_policy_or lp
                  JOIN enterprise e ON (e.enterprise_iid = lp.enterprise_iid)
                  JOIN lcd_contractor_or c
                     ON (c.contractor_or_eid = lp.CONTRACTOR_OR_EID)) temp;

-- END V_LCD_POLICY_OVERRIDE


CREATE OR REPLACE FORCE VIEW ICP_P.V_LCD_PROCEDURE_OVERRIDE
(
   IID,
   POLICY_EID,
   CONTRACTOR_EID,
   RELATION_EID,
   PROCEDURE_CODE,
   SUPPORT,
   EFFECTIVE_DATE,
   EXPIRATION_DATE,
   TYPE,
   IS_DISABLED,
   EXTRACT_DATE,
   ENTERPRISE_IID,
   ENTERPRISE_NAME,
   IS_OVERRIDE,
   IS_ORIGINAL,
   PROCEDURE_TYPE,
   STATUS,
   POLICY_NUMBER,
   CONTRACTOR_NUMBER
)
AS
   SELECT temp.IID AS iid,
          temp.POLICY_EID,
          temp.CONTRACTOR_EID,
          temp.RELATION_EID,
          temp.PROCEDURE_CODE,
          temp.SUPPORT,
          temp.EFFECTIVE_DATE,
          temp.EXPIRATION_DATE,
          temp.TYPE,
          temp.IS_DISABLED,
          temp.EXTRACT_DATE,
          temp.ENTERPRISE_IID,
          temp.ENTERPRISE_NAME,
          temp.IS_OVERRIDE,
          temp.IS_ORIGINAL,
          temp.PROCEDURE_TYPE,
          temp.STATUS,
          temp.POLICY_NUMBER,
          temp.CONTRACTOR_NUMBER
     FROM (SELECT lpr.lcd_procedure_iid iid,
                  lpr.policy_eid,
                  lpr.contractor_eid,
                  lpr.relation_eid,
                  lpr.procedure_code,
                  lpr.support,
                  lpr.effective_date,
                  lpr.expiration_date,
                  lpr.TYPE,
                  'N' is_disabled,
                  lpr.extract_date,
                  0 enterprise_iid,
                  'System' enterprise_name,
                  'N' is_override,
                  'Y' is_original,
                  'S' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure lpr
                  JOIN lcd_policy lp
                     ON (    lpr.contractor_eid = lp.contractor_eid
                         AND lpr.policy_eid = lp.policy_eid
                         AND lpr.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date)
            WHERE    c.contractor_type = 'MB'
                  OR c.contractor_type = 'CA'
                  OR c.contractor_type = 'NB'
                  OR c.contractor_type = 'DP'
                  OR c.contractor_type = 'DM'
                  OR c.contractor_type = 'DC'
                  OR c.contractor_type = 'DA'
                  OR c.contractor_type = 'ND'
           UNION
           SELECT l.iid,
                  l.policy_or_eid,
                  l.contractor_or_eid,
                  l.RELATION_OR_EID,
                  l.procedure_code,
                  l.support,
                  l.effective_date,
                  l.expiration_date,
                  NULL TYPE,
                  l.is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  l.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'Y' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    l.contractor_or_eid = lo.contractor_or_eid
                         AND l.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date)
            WHERE    c.contractor_type = 'MB'
                  OR c.contractor_type = 'CA'
                  OR c.contractor_type = 'NB'
                  OR c.contractor_type = 'DP'
                  OR c.contractor_type = 'DM'
                  OR c.contractor_type = 'DC'
                  OR c.contractor_type = 'DA'
                  OR c.contractor_type = 'ND'
           UNION
           SELECT l.iid,
                  l.policy_or_eid,
                  l.contractor_or_eid,
                  l.RELATION_OR_EID,
                  l.procedure_code,
                  l.support,
                  l.effective_date,
                  l.expiration_date,
                  NULL TYPE,
                  l.is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  l.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'Y' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' Status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    l.contractor_or_eid = lo.contractor_or_eid
                         AND l.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE (c.contractor_type = 'PROFESSIONALCUSTOM')
           UNION
           SELECT l.iid,
                  l.policy_or_eid,
                  l.contractor_or_eid,
                  l.RELATION_OR_EID,
                  l.procedure_code,
                  l.support,
                  l.effective_date,
                  l.expiration_date,
                  NULL TYPE,
                  l.is_disabled,
                  lp.extract_date,
                  l.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'Y' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    l.contractor_or_eid = lp.contractor_eid
                         AND l.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure lp
                  INNER JOIN lcd_frequency_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    l.contractor_eid = lp.contractor_eid
                         AND l.policy_eid = lp.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_frequency_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_frequency_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_frequency_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure lp
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    l.contractor_eid = lp.contractor_eid
                         AND l.policy_eid = lp.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure lp
                  INNER JOIN lcd_diagnosis_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    lp.contractor_eid = l.contractor_eid
                         AND lp.policy_eid = l.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_diagnosis_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_diagnosis_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_diagnosis_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure lp
                  INNER JOIN lcd_pos_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    lp.contractor_eid = l.contractor_eid
                         AND lp.policy_eid = l.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_pos_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_pos_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_pos_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure lp
                  INNER JOIN lcd_modifier_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    l.contractor_eid = lp.contractor_eid
                         AND l.policy_eid = lp.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_modifier_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_modifier_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_modifier_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure lp
                  INNER JOIN lcd_provider_specialty_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    l.contractor_eid = lp.contractor_eid
                         AND l.policy_eid = lp.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_provider_specialty_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_provider_specialty_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_provider_specialty_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))
           UNION
           SELECT lcd_procedure_iid iid,
                  lp.policy_eid,
                  lp.contractor_eid,
                  lp.relation_eid,
                  lp.procedure_code,
                  lp.support,
                  lp.effective_date,
                  lp.expiration_date,
                  lp.TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  l.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure lp
                  INNER JOIN lcd_c2c_or lao
                     ON (    lao.contractor_or_eid = lp.contractor_eid
                         AND lao.policy_or_eid = lp.policy_eid
                         AND lao.relation_or_eid = lp.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy l
                     ON (    l.contractor_eid = lp.contractor_eid
                         AND l.policy_eid = lp.policy_eid
                         AND l.extract_date = lp.extract_date)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = l.contractor_eid
                         AND c.extract_date = l.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 lp.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_c2c_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lo.contractor_or_eid
                         AND c.extract_date =
                                TO_CHAR (lo.create_date, 'YYYYMMDD'))
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  'A' status,
                  lo.policy_number,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_c2c_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
                  JOIN lcd_contractor_or c
                     ON (    c.contractor_or_eid = lo.contractor_or_eid
                         AND c.create_date = lo.create_date)
            WHERE     (c.contractor_type = 'PROFESSIONALCUSTOM')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.procedure_code,
                  o.support,
                  o.effective_date,
                  o.expiration_date,
                  NULL TYPE,
                  'N' is_disabled,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override,
                  'N' is_original,
                  'C' PROCEDURE_TYPE,
                  ld.status,
                  lp.cms_number POLICY_NUMBER,
                  c.contractor_number
             FROM lcd_procedure_or o
                  INNER JOIN lcd_c2c_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_contractor c
                     ON (    c.contractor_eid = lp.contractor_eid
                         AND c.extract_date = lp.extract_date)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = c.contractor_eid
                         AND ld.extract_date = c.extract_date
                         AND ld.status = 'A')
            WHERE     (   c.contractor_type = 'MB'
                       OR c.contractor_type = 'CA'
                       OR c.contractor_type = 'NB'
                       OR c.contractor_type = 'DP'
                       OR c.contractor_type = 'DM'
                       OR c.contractor_type = 'DC'
                       OR c.contractor_type = 'DA'
                       OR c.contractor_type = 'ND')
                  AND (    NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_relation_or lro
                                    WHERE     lro.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lro.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lro.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lro.enterprise_iid =
                                                 lao.enterprise_iid)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_procedure_or lpo
                                    WHERE     lpo.contractor_or_eid =
                                                 lao.contractor_or_eid
                                          AND lpo.policy_or_eid =
                                                 lao.policy_or_eid
                                          AND lpo.relation_or_eid =
                                                 lao.relation_or_eid
                                          AND lpo.enterprise_iid =
                                                 lao.enterprise_iid
                                          AND lpo.procedure_code =
                                                 o.procedure_code)
                       AND NOT EXISTS
                                  (SELECT 1
                                     FROM lcd_policy_or po
                                    WHERE     po.contractor_or_eid =
                                                 lp.contractor_eid
                                          AND po.policy_or_eid =
                                                 lp.policy_eid))) temp;

-- END V_LCD_PROCEDURE_OVERRIDE


CREATE OR REPLACE FORCE VIEW ICP_P.V_LCD_RELATION_OVERRIDE
(
   IID,
   POLICY_EID,
   CONTRACTOR_EID,
   RELATION_EID,
   EDIT_ACTION_TYPE,
   CATEGORY,
   GROUP_NUM,
   EXTRACT_DATE,
   ENTERPRISE_IID,
   ENTERPRISE_NAME,
   IS_OVERRIDE
)
AS
   SELECT temp.IID AS iid,
          temp.POLICY_EID,
          temp.CONTRACTOR_EID,
          temp.RELATION_EID,
          temp.EDIT_ACTION_TYPE,
          temp.CATEGORY,
          temp.GROUP_NUM,
          temp.EXTRACT_DATE,
          temp.ENTERPRISE_IID,
          temp.ENTERPRISE_NAME,
          temp.IS_OVERRIDE
     FROM (SELECT lcd_relation_iid iid,
                  policy_eid,
                  contractor_eid,
                  relation_eid,
                  edit_action_type,
                  category,
                  group_num,
                  extract_date,
                  0 enterprise_iid,
                  'System' enterprise_name,
                  'N' is_override
             FROM lcd_relation
           UNION
           SELECT l.iid,
                  l.policy_or_eid,
                  l.contractor_or_eid,
                  l.relation_or_eid,
                  l.edit_action_type,
                  l.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  l.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    l.contractor_or_eid = lo.contractor_or_eid
                         AND l.policy_or_eid = lo.policy_or_eid)
           UNION
           SELECT l.iid,
                  l.policy_or_eid,
                  l.contractor_or_eid,
                  l.relation_or_eid,
                  l.edit_action_type,
                  l.category,
                  NULL group_num,
                  lp.extract_date,
                  l.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or l
                  JOIN enterprise e ON (e.enterprise_iid = l.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    l.contractor_or_eid = lp.contractor_eid
                         AND l.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
           UNION
           SELECT lr.lcd_relation_iid iid,
                  lr.policy_eid,
                  lr.contractor_eid,
                  lr.relation_eid,
                  lr.edit_action_type,
                  lr.category,
                  lr.group_num,
                  lr.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation lr
                  INNER JOIN lcd_procedure_or lao
                     ON (    lao.contractor_or_eid = lr.contractor_eid
                         AND lao.policy_or_eid = lr.policy_eid
                         AND lao.relation_or_eid = lr.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lr.contractor_eid
                         AND ld.extract_date = lr.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_procedure_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_procedure_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_relation_or lro
                                WHERE     lro.contractor_or_eid =
                                             lao.contractor_or_eid
                                      AND lro.policy_or_eid =
                                             lao.policy_or_eid
                                      AND lro.relation_or_eid =
                                             lao.relation_or_eid
                                      AND lro.enterprise_iid =
                                             lao.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lr.lcd_relation_iid iid,
                  lr.policy_eid,
                  lr.contractor_eid,
                  lr.relation_eid,
                  lr.edit_action_type,
                  lr.category,
                  lr.group_num,
                  lr.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation lr
                  INNER JOIN lcd_frequency_or lao
                     ON (    lao.contractor_or_eid = lr.contractor_eid
                         AND lao.policy_or_eid = lr.policy_eid
                         AND lao.relation_or_eid = lr.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lr.contractor_eid
                         AND ld.extract_date = lr.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_frequency_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_frequency_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_relation_or lro
                                WHERE     lro.contractor_or_eid =
                                             lao.contractor_or_eid
                                      AND lro.policy_or_eid =
                                             lao.policy_or_eid
                                      AND lro.relation_or_eid =
                                             lao.relation_or_eid
                                      AND lro.enterprise_iid =
                                             lao.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lr.lcd_relation_iid iid,
                  lr.policy_eid,
                  lr.contractor_eid,
                  lr.relation_eid,
                  lr.edit_action_type,
                  lr.category,
                  lr.group_num,
                  lr.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation lr
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lao
                     ON (    lao.contractor_or_eid = lr.contractor_eid
                         AND lao.policy_or_eid = lr.policy_eid
                         AND lao.relation_or_eid = lr.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lr.contractor_eid
                         AND ld.extract_date = lr.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN LCD_FREQ_PROCEDURE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_relation_or lro
                                WHERE     lro.contractor_or_eid =
                                             lao.contractor_or_eid
                                      AND lro.policy_or_eid =
                                             lao.policy_or_eid
                                      AND lro.relation_or_eid =
                                             lao.relation_or_eid
                                      AND lro.enterprise_iid =
                                             lao.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lr.lcd_relation_iid iid,
                  lr.policy_eid,
                  lr.contractor_eid,
                  lr.relation_eid,
                  lr.edit_action_type,
                  lr.category,
                  lr.group_num,
                  lr.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation lr
                  INNER JOIN lcd_diagnosis_or lao
                     ON (    lao.contractor_or_eid = lr.contractor_eid
                         AND lao.policy_or_eid = lr.policy_eid
                         AND lao.relation_or_eid = lr.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lr.contractor_eid
                         AND ld.extract_date = lr.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_diagnosis_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_diagnosis_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_relation_or lro
                                WHERE     lro.contractor_or_eid =
                                             lao.contractor_or_eid
                                      AND lro.policy_or_eid =
                                             lao.policy_or_eid
                                      AND lro.relation_or_eid =
                                             lao.relation_or_eid
                                      AND lro.enterprise_iid =
                                             lao.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lr.lcd_relation_iid iid,
                  lr.policy_eid,
                  lr.contractor_eid,
                  lr.relation_eid,
                  lr.edit_action_type,
                  lr.category,
                  lr.group_num,
                  lr.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation lr
                  INNER JOIN lcd_pos_or lao
                     ON (    lao.contractor_or_eid = lr.contractor_eid
                         AND lao.policy_or_eid = lr.policy_eid
                         AND lao.relation_or_eid = lr.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lr.contractor_eid
                         AND ld.extract_date = lr.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_pos_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_pos_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_relation_or lro
                                WHERE     lro.contractor_or_eid =
                                             lao.contractor_or_eid
                                      AND lro.policy_or_eid =
                                             lao.policy_or_eid
                                      AND lro.relation_or_eid =
                                             lao.relation_or_eid
                                      AND lro.enterprise_iid =
                                             lao.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lr.lcd_relation_iid iid,
                  lr.policy_eid,
                  lr.contractor_eid,
                  lr.relation_eid,
                  lr.edit_action_type,
                  lr.category,
                  lr.group_num,
                  lr.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation lr
                  INNER JOIN LCD_TYPE_OF_BILL_OR lao
                     ON (    lao.contractor_or_eid = lr.contractor_eid
                         AND lao.policy_or_eid = lr.policy_eid
                         AND lao.relation_or_eid = lr.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lr.contractor_eid
                         AND ld.extract_date = lr.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN LCD_TYPE_OF_BILL_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN LCD_TYPE_OF_BILL_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_relation_or lro
                                WHERE     lro.contractor_or_eid =
                                             lao.contractor_or_eid
                                      AND lro.policy_or_eid =
                                             lao.policy_or_eid
                                      AND lro.relation_or_eid =
                                             lao.relation_or_eid
                                      AND lro.enterprise_iid =
                                             lao.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lr.lcd_relation_iid iid,
                  lr.policy_eid,
                  lr.contractor_eid,
                  lr.relation_eid,
                  lr.edit_action_type,
                  lr.category,
                  lr.group_num,
                  lr.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation lr
                  INNER JOIN LCD_REVENUE_CODE_OR lao
                     ON (    lao.contractor_or_eid = lr.contractor_eid
                         AND lao.policy_or_eid = lr.policy_eid
                         AND lao.relation_or_eid = lr.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lr.contractor_eid
                         AND ld.extract_date = lr.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN LCD_REVENUE_CODE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN LCD_REVENUE_CODE_OR lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_relation_or lro
                                WHERE     lro.contractor_or_eid =
                                             lao.contractor_or_eid
                                      AND lro.policy_or_eid =
                                             lao.policy_or_eid
                                      AND lro.relation_or_eid =
                                             lao.relation_or_eid
                                      AND lro.enterprise_iid =
                                             lao.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lr.lcd_relation_iid iid,
                  lr.policy_eid,
                  lr.contractor_eid,
                  lr.relation_eid,
                  lr.edit_action_type,
                  lr.category,
                  lr.group_num,
                  lr.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation lr
                  INNER JOIN lcd_modifier_or lao
                     ON (    lao.contractor_or_eid = lr.contractor_eid
                         AND lao.policy_or_eid = lr.policy_eid
                         AND lao.relation_or_eid = lr.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lr.contractor_eid
                         AND ld.extract_date = lr.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_modifier_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_modifier_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_relation_or lro
                                WHERE     lro.contractor_or_eid =
                                             lao.contractor_or_eid
                                      AND lro.policy_or_eid =
                                             lao.policy_or_eid
                                      AND lro.relation_or_eid =
                                             lao.relation_or_eid
                                      AND lro.enterprise_iid =
                                             lao.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lr.lcd_relation_iid iid,
                  lr.policy_eid,
                  lr.contractor_eid,
                  lr.relation_eid,
                  lr.edit_action_type,
                  lr.category,
                  lr.group_num,
                  lr.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation lr
                  INNER JOIN lcd_provider_specialty_or lao
                     ON (    lao.contractor_or_eid = lr.contractor_eid
                         AND lao.policy_or_eid = lr.policy_eid
                         AND lao.relation_or_eid = lr.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lr.contractor_eid
                         AND ld.extract_date = lr.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_provider_specialty_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_provider_specialty_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_relation_or lro
                                WHERE     lro.contractor_or_eid =
                                             lao.contractor_or_eid
                                      AND lro.policy_or_eid =
                                             lao.policy_or_eid
                                      AND lro.relation_or_eid =
                                             lao.relation_or_eid
                                      AND lro.enterprise_iid =
                                             lao.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lr.lcd_relation_iid iid,
                  lr.policy_eid,
                  lr.contractor_eid,
                  lr.relation_eid,
                  lr.edit_action_type,
                  lr.category,
                  lr.group_num,
                  lr.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation lr
                  INNER JOIN lcd_value_code_or lao
                     ON (    lao.contractor_or_eid = lr.contractor_eid
                         AND lao.policy_or_eid = lr.policy_eid
                         AND lao.relation_or_eid = lr.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lr.contractor_eid
                         AND ld.extract_date = lr.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_value_code_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_value_code_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_relation_or lro
                                WHERE     lro.contractor_or_eid =
                                             lao.contractor_or_eid
                                      AND lro.policy_or_eid =
                                             lao.policy_or_eid
                                      AND lro.relation_or_eid =
                                             lao.relation_or_eid
                                      AND lro.enterprise_iid =
                                             lao.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lr.lcd_relation_iid iid,
                  lr.policy_eid,
                  lr.contractor_eid,
                  lr.relation_eid,
                  lr.edit_action_type,
                  lr.category,
                  lr.group_num,
                  lr.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation lr
                  INNER JOIN lcd_condition_code_or lao
                     ON (    lao.contractor_or_eid = lr.contractor_eid
                         AND lao.policy_or_eid = lr.policy_eid
                         AND lao.relation_or_eid = lr.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lr.contractor_eid
                         AND ld.extract_date = lr.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_condition_code_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_condition_code_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_relation_or lro
                                WHERE     lro.contractor_or_eid =
                                             lao.contractor_or_eid
                                      AND lro.policy_or_eid =
                                             lao.policy_or_eid
                                      AND lro.relation_or_eid =
                                             lao.relation_or_eid
                                      AND lro.enterprise_iid =
                                             lao.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid))
           UNION
           SELECT lr.lcd_relation_iid iid,
                  lr.policy_eid,
                  lr.contractor_eid,
                  lr.relation_eid,
                  lr.edit_action_type,
                  lr.category,
                  lr.group_num,
                  lr.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation lr
                  INNER JOIN lcd_c2c_or lao
                     ON (    lao.contractor_or_eid = lr.contractor_eid
                         AND lao.policy_or_eid = lr.policy_eid
                         AND lao.relation_or_eid = lr.relation_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lr.contractor_eid
                         AND ld.extract_date = lr.extract_date
                         AND ld.status = 'A')
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  TO_CHAR (lo.create_date, 'YYYYMMDD'),
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_c2c_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy_or lo
                     ON (    o.contractor_or_eid = lo.contractor_or_eid
                         AND o.policy_or_eid = lo.policy_or_eid)
            WHERE (NOT EXISTS
                          (SELECT 1
                             FROM lcd_relation_or lro
                            WHERE     lro.contractor_or_eid =
                                         lao.contractor_or_eid
                                  AND lro.policy_or_eid = lao.policy_or_eid
                                  AND lro.relation_or_eid =
                                         lao.relation_or_eid
                                  AND lro.enterprise_iid = lao.enterprise_iid))
           UNION
           SELECT o.iid,
                  o.policy_or_eid,
                  o.contractor_or_eid,
                  o.relation_or_eid,
                  o.edit_action_type,
                  o.category,
                  NULL group_num,
                  lp.extract_date,
                  lao.enterprise_iid,
                  e.name enterprise_name,
                  'Y' is_override
             FROM lcd_relation_or o
                  INNER JOIN lcd_c2c_or lao
                     ON (    lao.contractor_or_eid = o.contractor_or_eid
                         AND lao.policy_or_eid = o.policy_or_eid
                         AND lao.relation_or_eid = o.relation_or_eid)
                  INNER JOIN enterprise e
                     ON (lao.enterprise_iid = e.enterprise_iid)
                  JOIN lcd_policy lp
                     ON (    o.contractor_or_eid = lp.contractor_eid
                         AND o.policy_or_eid = lp.policy_eid)
                  JOIN lcd_data ld
                     ON (    ld.contractor_eid = lp.contractor_eid
                         AND ld.extract_date = lp.extract_date
                         AND ld.status = 'A')
            WHERE     (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_relation_or lro
                                WHERE     lro.contractor_or_eid =
                                             lao.contractor_or_eid
                                      AND lro.policy_or_eid =
                                             lao.policy_or_eid
                                      AND lro.relation_or_eid =
                                             lao.relation_or_eid
                                      AND lro.enterprise_iid =
                                             lao.enterprise_iid))
                  AND (NOT EXISTS
                              (SELECT 1
                                 FROM lcd_policy_or po
                                WHERE     po.contractor_or_eid =
                                             lp.contractor_eid
                                      AND po.policy_or_eid = lp.policy_eid)))
          temp;

-- END V_LCD_RELATION_OVERRIDE



CREATE OR REPLACE FORCE VIEW ICP_P.V_POLICY
(
   V_POLICY_IID,
   POLICY_IID,
   POLICY_EID,
   EXTRACT_DATE,
   CONTRACTOR_DETERMINATION_NUM,
   CONTRACTOR_NUMBER,
   POLICY_TYPE,
   CMS_NUMBER,
   POLICY_TITLE,
   EFFECTIVE_DATE,
   REVISION_DATE,
   EXPIRATION_DATE,
   ICD_VERSION,
   PX_NOT_INCLUSIVE_FLAG,
   URL,
   PDF_NAME,
   POLICY_PDF,
   CONTRACTOR_EID,
   STATUS
)
AS
   SELECT p.lcd_policy_iid AS v_policy_iid,
          p.lcd_policy_iid,
          p.policy_eid,
          p.extract_date,
          p.contractor_determination_num,
          c.contractor_number,
          p.policy_type,
          p.cms_number,
          p.policy_title,
          p.effective_date,
          p.revision_date,
          p.expiration_date,
          p.ICD_VERSION,
          p.px_not_inclusive_flag,
          p.url,
          p.pdf_name,
          p.policy_pdf,
          p.contractor_eid,
          l.status
     FROM lcd_policy p
          JOIN lcd_contractor c
             ON (    c.contractor_eid = p.contractor_eid
                 AND c.extract_date = p.extract_date)
          JOIN lcd_data l
             ON (    l.contractor_eid = c.contractor_eid
                 AND l.extract_date = c.extract_date)
    WHERE    c.contractor_type = 'MB'
          OR c.contractor_type = 'CA'
          OR c.contractor_type = 'NB';

-- END V_POLICY

-- KB Smartload Enhancement--
BEGIN
   IF ICP_P.DB_TOOLS.OBJECT_EXISTS('KB_INFO','TABLE') = 0 THEN
      EXECUTE IMMEDIATE 'CREATE TABLE ICP_P.KB_INFO (IID NUMBER(38, 0) NOT NULL,FILENAME VARCHAR2(100) NOT NULL,VERSION VARCHAR2(10),INSTALLED_DATE DATE,INSTALLATION_STATUS VARCHAR2(20),FAILURE_COUNT varchar(10),TOTAL_COUNT varchar(10),ERROR_MESSAGE VARCHAR2(1000),CURRENT_KB VARCHAR2(1),CONSTRAINT KB_INFO PRIMARY KEY (IID) USING INDEX TABLESPACE INDX1)';
  END IF;
END;
/

-- End of KB--

BEGIN
    IF (ICP_P.DB_TOOLS.OBJECT_EXISTS('PK_CLAIM', 'INDEX') = 0) THEN
       EXECUTE IMMEDIATE 'CREATE UNIQUE INDEX PK_CLAIM ON CLAIM(CLAIM_IID) TABLESPACE INDX1';
       EXECUTE IMMEDIATE 'ALTER TABLE ICP_P.CLAIM MODIFY PRIMARY KEY USING INDEX PK_CLAIM';
   END IF;
END;
/

BEGIN 
  IF NOT DB_TOOLS.COLUMN_EXISTS('CLAIM_EDIT','PATTERN_EID') THEN
    execute immediate 'ALTER TABLE ICP_P.CLAIM_EDIT ADD PATTERN_EID VARCHAR2(50)'; 
  END IF;
  IF NOT DB_TOOLS.COLUMN_EXISTS('CLAIM_EDIT','ATTRIBUTE_GROUP') THEN
    execute immediate 'ALTER TABLE ICP_P.CLAIM_EDIT ADD ATTRIBUTE_GROUP NUMBER(38)'; 
  END IF;
  IF NOT DB_TOOLS.COLUMN_EXISTS('CLAIM_LINE_EDIT','PATTERN_EID') THEN
    execute immediate 'ALTER TABLE ICP_P.CLAIM_LINE_EDIT ADD PATTERN_EID VARCHAR2(50)'; 
  END IF;
  IF NOT DB_TOOLS.COLUMN_EXISTS('CLAIM_LINE_EDIT','ATTRIBUTE_GROUP') THEN
    execute immediate 'ALTER TABLE ICP_P.CLAIM_LINE_EDIT ADD ATTRIBUTE_GROUP NUMBER(38)'; 
  END IF;
END;
/

-- Update PATTERN_EID column (from the edit message) in CLAIM_LINE_EDIT and CLAIM_EDIT tables for previously run DDR claims
-- This is needed for DDR reporting.
update ICP_P.CLAIM_LINE_EDIT
set PATTERN_EID=REGEXP_REPLACE(EDIT_MESSAGE,'^.*\[Pattern (.*?)\].*$','\1')
where PATTERN_EID is null
and RULESET_ID is not null
and EDIT_MESSAGE like '%[Pattern%';

update ICP_P.CLAIM_EDIT
set PATTERN_EID=REGEXP_REPLACE(EDIT_MESSAGE,'^.*\[Pattern (.*?)\].*$','\1')
where PATTERN_EID is null
and RULESET_ID is not null
and EDIT_MESSAGE like '%[Pattern%';

DECLARE
    tmpCount NUMBER:=0;
BEGIN
    SELECT nvl((SELECT 1 FROM ICP_P.CONFIG_PROPERTY WHERE PATH='/t360/framework/passwordpolicy' AND PROPERTY_NAME='characters.requireupper'), 0) INTO tmpCount FROM dual;
    IF (tmpCount = 0) THEN
        INSERT into ICP_P.CONFIG_PROPERTY(PATH, PROPERTY_NAME, PROPERTY_VALUE, CONCURRENCY_ID,ENVIRONMENT)
               values ('/t360/framework/passwordpolicy','characters.requireupper','false',0,'localhost');
               COMMIT;
    END IF;
END;
/

DECLARE
    tmpCount NUMBER:=0;
BEGIN
    SELECT nvl((SELECT 1 FROM ICP_P.CONFIG_PROPERTY WHERE PATH='/t360/framework/passwordpolicy' AND PROPERTY_NAME='characters.requirelower'), 0) INTO tmpCount FROM dual;
    IF (tmpCount = 0) THEN
        INSERT into ICP_P.CONFIG_PROPERTY(PATH, PROPERTY_NAME, PROPERTY_VALUE, CONCURRENCY_ID,ENVIRONMENT)
               values ('/t360/framework/passwordpolicy','characters.requirelower','false',0,'localhost');
               COMMIT;
    END IF;
END;
/

/* BEGIN ACE specific code */

BEGIN
  IF ICP_P.DB_TOOLS.OBJECT_EXISTS('S_ACE_LOG','SEQUENCE') = 0 THEN
    EXECUTE IMMEDIATE 'CREATE SEQUENCE S_ACE_LOG START WITH 1';
  END IF;
END;
/

DECLARE
str_ LONG;
BEGIN
  IF ICP_P.DB_TOOLS.OBJECT_EXISTS('ACE_LOG','TABLE') = 0 THEN
    str_ :=
      'CREATE TABLE ACE_LOG (
        IID NUMBER(38),
        LOG_TIME TIMESTAMP,
        CURRENT_IID  NUMBER(38),
        CURRENT_EID  VARCHAR2(256),
        CURRENT_ENTRY_DATE DATE,
        PATIENT_MRN VARCHAR2(256),
        DUPLICATE_IID NUMBER(38),
        DUPLICATE_EID VARCHAR2(256),
        DUPLICATE_ENTRY_DATE DATE,
        TIME_WINDOW NUMBER(38),
        CLAIM_CHANGED NUMBER(38),
        TIME_BETWEEN_SUBMISSIONS NUMBER(38),
        WINDOW1_SETTING NUMBER(38),
        WINDOW2_SETTING NUMBER(38),
        CONSTRAINT ACE_LOG_PK PRIMARY KEY (IID)
      )';
    EXECUTE IMMEDIATE str_;
  END IF;
  IF ICP_P.DB_TOOLS.OBJECT_EXISTS('ACE_LOG_IX1','INDEX') = 0 THEN
    EXECUTE IMMEDIATE 'CREATE INDEX ACE_LOG_IX1 on ACE_LOG(LOG_TIME) NOLOGGING TABLESPACE INDX1';
  END IF;
END;
/

BEGIN
  IF ICP_P.DB_TOOLS.OBJECT_EXISTS('PURGE_ACE_LOGS','JOB') = 0 THEN
    DBMS_SCHEDULER.create_job (
      job_name        => 'purge_ace_logs',
      job_type        => 'PLSQL_BLOCK',
      job_action      => 'BEGIN DELETE FROM ACE_LOG WHERE LOG_TIME < SYSDATE-1461; END;',
      start_date      => SYSTIMESTAMP,
      repeat_interval => 'freq=weekly; byday=sun; byhour=20; byminute=0; bysecond=0;',
      end_date        => NULL,
      enabled         => TRUE,
      comments        => 'Purge ACE logs older than 90 days old');
    END IF;
END;
/

DECLARE
str_         LONG;
seq          PLS_INTEGER;
TYPE cur_typ IS REF CURSOR;
x            cur_typ;
BEGIN
  IF ICP_P.DB_TOOLS.OBJECT_EXISTS('S_REF_ID_GENERATOR','SEQUENCE') = 1 THEN
    OPEN x FOR 'select ICP_P.S_REF_ID_GENERATOR.NEXTVAL from dual';
    LOOP
        FETCH x INTO seq;
        EXIT WHEN x%NOTFOUND;
    END LOOP;
    EXECUTE IMMEDIATE 'DROP SEQUENCE ICP_P.S_REF_ID_GENERATOR';
  END IF;
  IF ICP_P.DB_TOOLS.OBJECT_EXISTS('S_SMARTATTACH_REF_ID','SEQUENCE') = 1 THEN
    OPEN x FOR 'select ICP_P.S_SMARTATTACH_REF_ID.NEXTVAL from dual';
    LOOP
        FETCH x INTO seq;
        EXIT WHEN x%NOTFOUND;
    END LOOP;
    EXECUTE IMMEDIATE 'DROP SEQUENCE ICP_P.S_SMARTATTACH_REF_ID';
  ELSE
    seq := 1;
  END IF;
  IF ICP_P.DB_TOOLS.OBJECT_EXISTS('S_SMARTATTACH_REF_ID','SEQUENCE') = 0 THEN
    str_ :=
      'CREATE SEQUENCE ICP_P.S_SMARTATTACH_REF_ID
        START WITH ' || seq || '
        INCREMENT BY 1
        MINVALUE 1
        MAXVALUE 1073741823
        CACHE 20
        NOORDER
        CYCLE';
    EXECUTE IMMEDIATE str_;
  END IF;
END;
/

DECLARE
str_ LONG;
BEGIN
  IF ICP_P.DB_TOOLS.OBJECT_EXISTS('S_CLAIM_SMARTATTACH_PK_ID','SEQUENCE') = 0 THEN
    str_ :=
      'CREATE SEQUENCE ICP_P.S_CLAIM_SMARTATTACH_PK_ID
        START WITH 1
        INCREMENT BY 1
        NOMINVALUE
        NOMAXVALUE
        CACHE 20
        NOORDER';
    EXECUTE IMMEDIATE str_;
  END IF;
END;
/

DECLARE
str_ LONG;
BEGIN
  IF ICP_P.DB_TOOLS.OBJECT_EXISTS('CLAIM_SMARTATTACH','TABLE') = 0 THEN
    str_ :=
      'CREATE TABLE ICP_P.CLAIM_SMARTATTACH (   
        IID NUMBER(38,0) NOT NULL,
        CLAIM_IID  NUMBER(38, 0)    NOT NULL,
        SMARTATTACH_ID VARCHAR2(40) NOT NULL,
        CONSTRAINT PK_CLAIM_SMARTATTACH_ID PRIMARY KEY (IID),
        CONSTRAINT FK_CLAIM_SMARTATTACH_ID FOREIGN KEY (CLAIM_IID) REFERENCES ICP_P.CLAIM(CLAIM_IID)
      )';
    EXECUTE IMMEDIATE str_;
  END IF;
END;
/

/* END ACE specific code */

DECLARE
  v_fe_inpatient_string   VARCHAR2(25) := 'Facility Inpatient';
  v_fe_in_patient_string  VARCHAR2(25) := 'Facility In-Patient';
  v_fe_outpatient_string  VARCHAR2(25) := 'Facility Outpatient';
  v_fe_out_patient_string VARCHAR2(25) := 'Facility Out-Patient';
  v_in_update_sql         VARCHAR2 (200) := 'update scheduled_purge set module = ' || chr(39) ||v_fe_inpatient_string || chr(39) || ' where module = ' || chr(39) ||v_fe_in_patient_string || chr(39) ;
  v_out_update_sql        VARCHAR2 (200) := 'update scheduled_purge set module = ' || chr(39) ||v_fe_outpatient_string || chr(39) || ' where module = ' || chr(39) ||v_fe_out_patient_string || chr(39) ;  
BEGIN 
  IF (ICP_P.DB_TOOLS.OBJECT_EXISTS('SCHEDULED_PURGE_CH4', 'CONSTRAINT') = 0) THEN
       EXECUTE IMMEDIATE 'ALTER TABLE SCHEDULED_PURGE drop constraint SCHEDULED_PURGE_CH4';
       EXECUTE IMMEDIATE v_in_update_sql ;
       EXECUTE IMMEDIATE v_out_update_sql ;
       EXECUTE IMMEDIATE 'ALTER TABLE SCHEDULED_PURGE add constraint SCHEDULED_PURGE_CH4 CHECK (MODULE IN (''Professional'', ''Facility All'', ''Facility Inpatient'', ''Facility Outpatient''))'; 
   END IF;
END;
/

begin 
  execute immediate 'ALTER TABLE ICP_P.Scheduled_Purge ADD PE_MODULE VARCHAR2(10)'; 
  execute immediate 'ALTER TABLE ICP_P.Scheduled_Purge ADD FE_MODULE VARCHAR2(10)'; 
  exception when others then null; 
end;
/

BEGIN
   IF ICP_P.DB_TOOLS.OBJECT_EXISTS('S_SCHEDULED_PURGE_ENTERPRISE','SEQUENCE') = 0 THEN
     EXECUTE IMMEDIATE 'CREATE SEQUENCE ICP_P.S_SCHEDULED_PURGE_ENTERPRISE
        START WITH 1
        INCREMENT BY 1
        NOMINVALUE
        NOMAXVALUE
        CACHE 20
        NOORDER';
   END IF;
END;
/  

BEGIN
   IF ICP_P.DB_TOOLS.OBJECT_EXISTS('SCHEDULED_PURGE_ENTERPRISE','TABLE') = 0 THEN
      EXECUTE IMMEDIATE 'CREATE TABLE ICP_P.SCHEDULED_PURGE_ENTERPRISE
        (IID NUMBER(38,0) NOT NULL, 
        SCHEDULED_PURGE_IID NUMBER(38,0) NOT NULL, 
        ENTERPRISE_IID NUMBER(38,0) NOT NULL, 
        CONSTRAINT SCHEDULED_PURGE_ENTERPRISE_PK PRIMARY KEY(IID),
        CONSTRAINT SCHEDULED_PURGE_ENTERPRISE_FK1 FOREIGN KEY(SCHEDULED_PURGE_IID)
        REFERENCES SCHEDULED_PURGE(IID) ON DELETE CASCADE)';
    END IF;
END;
/

-- PURGE_SCHEDULER program change
BEGIN
  DBMS_SCHEDULER.DROP_PROGRAM
    (program_name          => 'PURGE_SCHEDULER');
END;
/
BEGIN
  DBMS_SCHEDULER.CREATE_PROGRAM
    (
      program_name         => 'PURGE_SCHEDULER'
     ,program_type         => 'STORED_PROCEDURE'
     ,program_action       => 'claim_purge'
     ,number_of_arguments  => 23
     ,enabled              => FALSE
     ,comments             => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_enterprise_iid'
     ,argument_position    => 1
     ,argument_type        => 'NUMBER'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_context'
     ,argument_position    => 2
     ,argument_type        => 'NUMBER'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_claim_status'
     ,argument_position    => 3
     ,argument_type        => 'VARCHAR2'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_begin_claim_eid'
     ,argument_position    => 4
     ,argument_type        => 'VARCHAR2'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_end_claim_eid'
     ,argument_position    => 5
     ,argument_type        => 'VARCHAR2'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_begin_batch_eid'
     ,argument_position    => 6
     ,argument_type        => 'VARCHAR2'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_end_batch_eid'
     ,argument_position    => 7
     ,argument_type        => 'VARCHAR2'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_begin_external_entry_date'
     ,argument_position    => 8
     ,argument_type        => 'DATE'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_end_external_entry_date'
     ,argument_position    => 9
     ,argument_type        => 'DATE'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_discriminator'
     ,argument_position    => 10
     ,argument_type        => 'VARCHAR2'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_user_id'
     ,argument_position    => 11
     ,argument_type        => 'NUMBER'
     ,default_value        => 1
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_username'
     ,argument_position    => 12
     ,argument_type        => 'VARCHAR2'
     ,default_value        => 'SYSTEM'
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_frequency_hist'
     ,argument_position    => 13
     ,argument_type        => 'NUMBER'
     ,default_value        => 0
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_npt'
     ,argument_position    => 14
     ,argument_type        => 'NUMBER'
     ,default_value        => 0
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_in_out_patient'
     ,argument_position    => 15
     ,argument_type        => 'VARCHAR2'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_older_than_days'
     ,argument_position    => 16
     ,argument_type        => 'NUMBER'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_claim_eid_like'
     ,argument_position    => 17
     ,argument_type        => 'VARCHAR2'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_batch_eid_like'
     ,argument_position    => 18
     ,argument_type        => 'VARCHAR2'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_scheduled_purge_iid'
     ,argument_position    => 19
     ,argument_type        => 'NUMBER'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_include_nn_npt'
     ,argument_position    => 20
     ,argument_type        => 'NUMBER'
     ,default_value        => '0'
    );

  DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_include_nn_mfx'
     ,argument_position    => 21
     ,argument_type        => 'NUMBER'
     ,default_value        => '0'
    );
    
    DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_pe_module'
     ,argument_position    => 22
     ,argument_type        => 'VARCHAR2'
     ,default_value        => NULL
    );
    
    DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT
    (
      program_name         => 'PURGE_SCHEDULER'
     ,argument_name        => 'p_fe_module'
     ,argument_position    => 23
     ,argument_type        => 'VARCHAR2'
     ,default_value        => NULL
    );

  DBMS_SCHEDULER.ENABLE
    (name                  => 'PURGE_SCHEDULER');
END;
/

-- End of PURGE_SCHEDULER program change

-- usp_claim_purge procedure
create or replace PROCEDURE ICP_P.usp_claim_purge
( p_enterprise_iid            IN  claim.enterprise_iid%TYPE
, p_context                   IN  claim.context%TYPE
, p_claim_status              IN  claim.claim_status%TYPE
, p_begin_claim_eid           IN  claim.claim_eid%TYPE
, p_end_claim_eid             IN  claim.claim_eid%TYPE
, p_begin_batch_eid           IN  claim.batch_eid%TYPE
, p_end_batch_eid             IN  claim.batch_eid%TYPE
, p_begin_external_entry_date IN  claim.external_entry_date%TYPE
, p_end_external_entry_date   IN  claim.external_entry_date%TYPE
, p_discriminator             IN  claim.discriminator%TYPE
, p_user_id                   IN  audit_log.PERMISSIBLE_USER_IID%TYPE
, p_username                  IN  audit_log.USERNAME%TYPE
, p_frequency                 IN  INTEGER                             := 0
, p_npt                       IN  INTEGER                             := 0
, p_countonly                 IN  INTEGER                             := 0
, o_purgecount                OUT INTEGER
, p_in_out_patient            IN  claim.in_out_patient%TYPE
, p_older_than_days           IN  INTEGER
, p_claim_eid_like            IN  claim.claim_eid%TYPE
, p_batch_eid_like            IN  claim.batch_eid%TYPE
, p_scheduled_purge_iid       IN  scheduled_purge.iid%TYPE
, p_include_nn_npt            IN  scheduled_purge.include_nn_npt%TYPE := 0
, p_include_nn_mfx            IN  scheduled_purge.include_nn_mfx%TYPE := 0
, p_pe_module                 IN  scheduled_purge.pe_module%TYPE
, p_fe_module                 IN  scheduled_purge.fe_module%TYPE
)
AS
-- ******************************************************************************
--   NAME:       usp_claim_purge
--   PURPOSE:
--
--   REVISIONS:
--   Ver        Date        Author           Description
--   ---------  ----------  ---------------  ------------------------------------
--   1.0        11/07/2007  Jeff Evans       Created this procedure.
--   1.1        02/07/2008  Jeff Evans       Removed service date criteria.  In
--                                            comments added multiple counts for
--                                            active claims and non-active claims.
--   1.2        04/23/2008  Jeff Evans       Changed the system_entry_date to external_entry_date.
--   1.3        06/16/2008  Jeff Evans       Changed the truncate to delete in the claim_puge_list
--                                            table.  Also added "RAISE" to the exception handler.
--                                            Also, removed all the COMMIT statements.
--   1.4        09/16/2008  Jeff Evans       Removed all posibilities of needing a commits including
--                                            gathering statistics, any exception handling.  Using
--                                            new global temp table NPT_TEMP.
--   1.6        01/29/2009  Jeff Evans       Reverted the previous change and put COMMITS, TRUNCATES,
--                                            and stats gathering back in.  Added stats gathering
--                                            on the NPT table.
--   1.5        08/11/2009  Jeff Evans       Added functionality to delete claim info for the SUBMITTED_CLAIM_IID
--                                            before the actual claims because of the self referencing
--                                            foreign key.
--   1.6        08/11/2009  Jeff Evans       Added functionality to keep non analyzed claim info in the
--                                            NPT and MAX FREQUENCY tables.  Also fixed bug to include
--                                            only claims with the IS_MODIFIED = 'N' in the NPT and
--                                            MAX FREQUENCY routines.
--   2.0        11/06/2009  Jeff Evans       Changed begin/end claim_iid parameter to be claim_eid.
--
--   2.1        11/16/2009  Jeff Evans       Added the p_in_out_patient parameter for
--                                             facility claims.
--   2.2        12/18/2009  Jeff Evans       Added the p_older_than_days parameter.
--                                           Added the p_claim_eid_like parameter.
--                                           Added the p_batch_eid_like parameter.
--   2.3        12/18/2009  Jeff Evans       Changed input parameters to be prefixed with
--                                              p_  instead of  v_
--
--   2.4        12/18/2009  Jeff Evans       Removed the IF THEN to check for a WHERE
--                                             clause and put WHERE 1=1 by default.
--   2.5        01/06/2010  Jeff Evans       Change to do the same as CLAIM_PURGE so there
--                                             there is only one PURGE procedure.
--   2.6        01/08/2010  Jeff Evans       Added p_scheduled_purge_iid for logging.
--
--   2.7        04/22/2010  Jeff Evans       Added INCLUDE_NN_NPT and INCLUDE_NN_MFX to
--                                             support un-analyzed claims in NPT and MFX.
--   4.6        01/27/2011  Jeff Evans       Hot-fix.   Created NPT and NPT_TEMP as regular tables
--                                             not global temp tables.  Fixed the CASE statement for
--                                             specialty codes.  Added OR statement in where clause
--                                             for both adjusted_specialty_codes and bill_provider_specialty
--                                             to see if they exist.  Added criteria to only populate
--                                             'A'ctive claims.  Changed the where clause in the
--                                             exception list to only consider adjusted_specialty for
--                                             analyzed claims and billing_provider_specialty in
--                                             non-analyzed claims.  Changed the BULK COLLECT limit
--                                             to 100 from 10,000.
--   4.8        01/26/2012  Jeff Evans       Added ICD10_INDICATOR to the frequency
--                                             history tables.
--   4.9        08/27/2012  Prakash          Added Additional condition to implement purge in FE
--                                             Frequency history tables.
--   5.0        01/23/2013  Prakash          Added Additional condition to implement purge in LCD
--                                             Frequency history tables.
--              05/13/2013  Jeff Evans       Added call to usp_populate_ph_claim_data procedure.
--
--   5.3        05/16/2014  Jeff Evans       Added join to the claim_line table to get the claim_line_iid
--                                             value instead of multiple selects. Also added deletes to
--                                             each complete table instead of grouping them. These changes
--                                             were implemented for ACE for performance improvement.
--                                             US90074
--   5.3.1      09/11/2014  Jared Glade      Added USP_PPS_RESULTS_PURGE
--                                             US121067
--              10/27/2015  Gary Franklin    Added code to see if client is a CM client, or if they have 
--                                             any modified claims. If no modified claims exist, 
--                                             then skip the applied edit deletion section.  
--                                             The CM clients do not have a value in the submitted_claim_iid
--                                             column which can causes the purge process to be extremely 
--                                             slow for them. --DE89542
--              01/11/2016  Gary Franklin   Changed the delete statements that referenced  
--                                               fe_frequency_history.frequency_history_iid, 
--                                               since that column doesnt exist.  fe_frequency_history.iid 
--                                               is the correct column name.  --DE69342
--              04/28/2016  Gary Franklin   Changed the INSERT INTO npt_diagnosis and INSERT INTO npt_modifier
--                                             statements to only insert from npt_temp. This avoids duplicates.
--              04/28/2016  Gary Franklin   Commented out the "delete from claim where submitted_claim_iid =" 
--                                             statement since it is redundant with earlier code.
--   5.4        06/27/2016  Purnima          Added pe_module, fe_module columns. Added condition to 
--                                              check for scheduled_purge_enterprise table to purge 
--                                              onlyclaims whose enterprises have been selected. 
--
--   NOTES:
--
--   Deletes all claims and related records according to the passed in parameters
--   using bulk collections in order to limit the number of records deleted at a
--   time to reduce undo overhead and recoverablility.
--
--   For the range parameters, there must always be a begin and end range, you
--   cannot pass in NULL for one of the range parameters, you must pass in both.
--
--   Parameter List:
--
--   p_context                1 or 0  (1=live 0=test)
--   p_claim_status           'A' or 'I' ('A'=current 'I'=noncurrent)
--   p_begin_claim_eid        claim_eid
--   p_end_claim_eid          claim_eid
--   p_discriminator          'PRO' or 'INST' ('PRO'=professional 'INST' facility)
--   p_frequency              1 or 0
--   p_npt                    1 or 0
--   p_in_out_patient         'I' or 'O'
--   p_older_than_days        Integer, number of days older than SYSDATE - p_older_than_days
--   p_countonly              1 or 0  (1=return count only 0=return count and purge)
--   p_include_nn_npt         1 or 0  (1=NN claims will be added to NPT table 0=Not added)
--   p_include_nn_mfx         1 or 0  (1=NN claims will be added to MFX tables 0=Not added)
--   p_pe_module              'Y' or null (Y if atleast one Professinal enterprise is selected else Null)
--   p_fe_module              Null or 'ALL' or 'I' or 'O' (Null - No Facility enterprise is selected; 
--                            All - Both inpatient and outpatient are selected
--                            I- Only Inpatient is selected
--                            O- Only Outpatient is selected
--
-- ******************************************************************************


   TYPE t_claim_iid IS TABLE OF claim_purge_list%ROWTYPE
      INDEX BY PLS_INTEGER;

   claim_iids                    t_claim_iid;

   CURSOR c_claim_iid
   IS
   SELECT claim_iid, context, claim_status, is_modified, claim_line_iid
     FROM claim_purge_list
    ORDER BY claim_iid,claim_line_iid;

   v_err_message                 VARCHAR2 (512);
   v_sql                         VARCHAR2 (32767);

   v_live_active_count           PLS_INTEGER := 0;
   v_live_inactive_count         PLS_INTEGER := 0;
   v_test_active_count           PLS_INTEGER := 0;
   v_test_inactive_count         PLS_INTEGER := 0;
   v_non_modified_claim_count    PLS_INTEGER := 0;

   v_actual_claim_count          PLS_INTEGER := 0;

   v_scheduled_purge_log_iid     PLS_INTEGER;
   v_scheduled_purge_job_name    VARCHAR2(30);
   v_product_name                VARCHAR2(30);
   v_modified_claim_count        PLS_INTEGER := 0;
   
--   v_discriminator_prof          VARCHAR2(5) := 'PRO';
--   v_discriminator_inst          VARCHAR2(5) := 'INST';
--   v_in_patient                  VARCHAR2(1) := 'I';
--   v_out_patient                 VARCHAR2(1) := 'O';
--
-- Create the "select" clause for the query.
--

   v_claim_iid_sql               VARCHAR2 (32767)  :=
     'SELECT c.claim_iid, c.context, c.claim_status, c.is_modified, cl.claim_line_iid '||
     '  FROM claim c '||
     '  LEFT OUTER JOIN claim_line cl '||
     '    ON ( cl.claim_iid = c.claim_iid ) '||
     ' WHERE 1=1 ';

BEGIN

--
--  Check for required parameters.
--

    -- No parameters are required

--  Get job name

   SELECT job_name INTO v_scheduled_purge_job_name
     FROM scheduled_purge
    WHERE iid = p_scheduled_purge_iid;

--
-- Add to v_claim_iid_sql's WHERE clause depending on what parameters were passed.
--

   IF p_enterprise_iid IS NOT NULL THEN
      v_claim_iid_sql := v_claim_iid_sql||' AND c.enterprise_iid = '||p_enterprise_iid;
   END IF; 
   
   -- scheduled_purge_enterprise table contains enterprises selected for a particular job. 
   -- Only those enterprise related claims should be purged.
   IF p_scheduled_purge_iid IS NOT NULL THEN
      v_claim_iid_sql := v_claim_iid_sql||' AND c.enterprise_iid in (select enterprise_iid from scheduled_purge_enterprise where scheduled_purge_iid = ' || p_scheduled_purge_iid || ')' ;
   END IF; 

   IF p_context IS NOT NULL THEN
      v_claim_iid_sql := v_claim_iid_sql||' AND c.context = '||p_context;
   END IF;

   IF p_claim_status IS NOT NULL THEN
      v_claim_iid_sql := v_claim_iid_sql||' AND c.claim_status = '||chr(39)||p_claim_status||chr(39);
   END IF;

   IF p_begin_claim_eid IS NOT NULL THEN
      v_claim_iid_sql := v_claim_iid_sql||' AND c.claim_eid between '||chr(39)||p_begin_claim_eid||chr(39)
           ||' AND '||chr(39)||p_end_claim_eid||chr(39);
   END IF;

   IF p_begin_batch_eid IS NOT NULL THEN
      v_claim_iid_sql := v_claim_iid_sql||' AND c.batch_eid between '||chr(39)||p_begin_batch_eid||chr(39)
           ||' AND '||chr(39)||p_end_batch_eid||chr(39);
   END IF;

   IF p_begin_external_entry_date IS NOT NULL THEN
      v_claim_iid_sql := v_claim_iid_sql||' AND c.external_entry_date >= '||chr(39)
           ||to_char(p_begin_external_entry_date,'DD-MON-YYYY')||chr(39)||' AND c.external_entry_date <'||chr(39)
           ||to_char(p_end_external_entry_date+1,'DD-MON-YYYY')||chr(39);
   END IF;

   IF p_discriminator IS NOT NULL THEN
      v_claim_iid_sql := v_claim_iid_sql||' AND c.discriminator = '||chr(39)||p_discriminator||chr(39);
   END IF;

   IF p_in_out_patient IS NOT NULL THEN
      v_claim_iid_sql := v_claim_iid_sql||' AND c.in_out_patient = '||chr(39)||p_in_out_patient||chr(39);
   END IF;

--   IF p_pe_module is not null AND p_fe_module IS NULL THEN
--      v_claim_iid_sql := v_claim_iid_sql||' AND c.discriminator = '||chr(39)||v_discriminator_prof||chr(39);
--   -- ELSE IF p_discriminator_p is not null AND p_discriminator_i = 'ALL' THEN  (This case doenst need any filters)
--   ELSIF p_pe_module is not null AND p_fe_module = 'IP' THEN 
--      v_claim_iid_sql := v_claim_iid_sql||' AND (c.discriminator = '||chr(39)||v_discriminator_prof||chr(39) 
--                         || ' OR (c.discriminator = '||chr(39)||v_discriminator_inst||chr(39) ||' AND c.in_out_patient = '||chr(39)||v_in_patient||chr(39) || '))';
--   ELSIF p_pe_module is not null AND p_fe_module = 'OP' THEN 
--      v_claim_iid_sql := v_claim_iid_sql||' AND (c.discriminator = '||chr(39)||v_discriminator_prof||chr(39) 
--                         || ' OR (c.discriminator = '||chr(39)||v_discriminator_inst||chr(39) ||' AND c.in_out_patient = '||chr(39)||v_out_patient||chr(39) || '))';
--   ELSIF p_pe_module is null AND p_fe_module = 'ALL' THEN 
--      v_claim_iid_sql := v_claim_iid_sql||' AND c.discriminator = ' || chr(39) || v_discriminator_inst || chr(39);
--   ELSIF p_pe_module is null AND p_fe_module = 'IP' THEN 
--      v_claim_iid_sql := v_claim_iid_sql||' AND c.discriminator = '||chr(39)||v_discriminator_inst||chr(39) 
--                         || ' AND c.in_out_patient = '||chr(39)||v_in_patient||chr(39);
--   ELSIF p_pe_module is null AND p_fe_module = 'OP' THEN 
--      v_claim_iid_sql := v_claim_iid_sql||' AND c.discriminator = '||chr(39)||v_discriminator_inst||chr(39) 
--                         || ' AND c.in_out_patient = '||chr(39)||v_out_patient||chr(39);
--   END IF;

   IF p_older_than_days IS NOT NULL THEN
      v_claim_iid_sql := v_claim_iid_sql||' AND c.external_entry_date < SYSDATE - '||to_char(p_older_than_days);
   END IF;

   IF p_claim_eid_like IS NOT NULL THEN
      v_claim_iid_sql := v_claim_iid_sql||' AND c.claim_eid LIKE '||chr(39)||p_claim_eid_like||chr(39);
   END IF;

   IF p_batch_eid_like IS NOT NULL THEN
      v_claim_iid_sql := v_claim_iid_sql||' AND c.batch_eid LIKE '||chr(39)||p_batch_eid_like||chr(39);
   END IF;

--
-- Use GTT CLAIM_PURGE table to populate the IIDs necesary for the purge into
--   the CLAIM_PURGE_LIST table.
--

   EXECUTE IMMEDIATE 'TRUNCATE TABLE claim_purge_list';

   v_sql := 'INSERT INTO claim_purge_list '||v_claim_iid_sql;

   EXECUTE IMMEDIATE v_sql;

   COMMIT;
--
--  If v_countonly is set to 1 then only return the count and skip the next
--   section.
--

   SELECT COUNT(DISTINCT claim_iid) INTO o_purgecount
     FROM claim_purge_list;

   SELECT COUNT(DISTINCT claim_iid) INTO v_non_modified_claim_count
     FROM claim_purge_list
    WHERE is_modified = 'N';

   SELECT COUNT(DISTINCT claim_iid) INTO v_live_active_count
     FROM claim_purge_list
    WHERE context = 1
      AND claim_status = 'A'
      AND is_modified = 'N';

   SELECT COUNT(DISTINCT claim_iid) INTO v_live_inactive_count
     FROM claim_purge_list
    WHERE context = 1
      AND claim_status = 'I'
      AND is_modified = 'N';

   SELECT COUNT(DISTINCT claim_iid) INTO v_test_active_count
     FROM claim_purge_list
    WHERE context = 0
      AND claim_status = 'A'
      AND is_modified = 'N';

   SELECT COUNT(DISTINCT claim_iid) INTO v_test_inactive_count
     FROM claim_purge_list
    WHERE context = 0
      AND claim_status = 'I'
      AND is_modified = 'N';

 IF p_countonly = 0
   THEN

--
--  purge_claim_log info
--

    SELECT s_scheduled_purge_log.NEXTVAL INTO v_scheduled_purge_log_iid
      FROM dual;

    INSERT INTO scheduled_purge_log
        (iid, scheduled_purge_iid, claims_purged, total_records_purged, purge_start, purge_end,
         error_message,
         total_live_active_claims, total_live_inactive_claims,
         total_test_active_claims, total_test_inactive_claims)
    VALUES ( v_scheduled_purge_log_iid, p_scheduled_purge_iid,
             NULL, NULL, SYSDATE, NULL, NULL, v_live_active_count,
             v_live_inactive_count, v_test_active_count, v_test_inactive_count
           );

   INSERT INTO audit_log
               (audit_log_iid, audit_domain, component_name,
                component_iid, component_eid, audit_message,
                audit_activity, audit_level, audit_date,
                permissible_user_iid, username
               )
        VALUES ( s_audit_log.NEXTVAL, 'D', 'Purge',
                 9999999, '9999999',
                 '( '||v_scheduled_purge_job_name||' ) purge started: '||to_char(sysdate,'MM/DD/YYYY HH:MI:SS'),
                 'Purging', 'INFO', sysdate, p_user_id, p_username
               );
   COMMIT;

     -- Added for Update purge script for all of the product to not store ODS information.

       SELECT upper(INFO_VALUE) INTO v_product_name FROM product_info
        WHERE INFO_PATH = '/product'
        AND INFO_NAME = 'name';

      IF v_product_name  <>  'CLAIMSMANAGER' THEN
        usp_populate_ph_claim_data;
      END IF;
-- End


   COMMIT;

--
--  NPT stuff will go here.
--

   IF p_npt = 1 AND p_include_nn_npt = 0
   THEN

      INSERT INTO npt_temp(npt_iid,patient_mrn,billing_provider_eid,billing_provider_specialty,service_start_date,
                 enterprise_iid,adjusted_procedure_code,department_eid,plan_eid,organizational_group_eid,
                 organizational_eid,user_defined_1,user_defined_2,user_defined_3,create_date,is_imported,
                 claim_eid,claim_line_eid,claim_line_iid,upin,billing_provider_taxonomy, tax_id_number,
                 servicing_physician_eid, servicing_provider_speciality,
                 servicing_provider_taxonomy, group_eid,user_defined_4,user_defined_5,user_defined_6,user_defined_7,user_defined_8,
                 user_defined_9,user_defined_10,user_defined_11,user_defined_12,user_defined_13,user_defined_14,user_defined_15,
                 user_defined_16,user_defined_17,user_defined_18,user_defined_19,user_defined_20,user_defined_21,user_defined_22,
                 user_defined_23,user_defined_24,user_defined_25)
      SELECT s_npt.NEXTVAL npt_iid
           , c.patient_mrn
           , cl.billing_provider_eid
           , CASE WHEN cl.adjusted_specialty_code IS NULL
                  THEN cl.billing_provider_specialty
             ELSE cl.adjusted_specialty_code
             END adjusted_specialty_code
           , cl.service_start_date
           , c.enterprise_iid
           , cl.adjusted_procedure_code
           , cl.billing_provider_department department_eid
           , c.plan_eid
           , cl.organizational_group_eid
           , cl.organizational_eid
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 1)  user_defined_1
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 2)  user_defined_2
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 3)  user_defined_3
           , SYSDATE create_date
           , 'N' is_imported
           , c.claim_eid
           , cl.claim_line_eid
           , cl.claim_line_iid
           , cl.billing_provider_upin upin
           , cl.billing_provider_taxonomy
           , cl.billing_provider_tax_id tax_id_number
           , cl.servicing_provider_eid servicing_physician_eid
           , cl.servicing_provider_specialty
           , cl.servicing_provider_taxonomy
           , cl.organizational_group_eid group_eid
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 4) user_defined_4
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 5) user_defined_5
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 6) user_defined_6
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 7) user_defined_7
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 8) user_defined_8
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 9) user_defined_9
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 10) user_defined_10
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 11) user_defined_11
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 12) user_defined_12
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 13) user_defined_13
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 14) user_defined_14
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 15) user_defined_15
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 16) user_defined_16
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 17) user_defined_17
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 18) user_defined_18
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 19) user_defined_19
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 20) user_defined_20
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 21) user_defined_21
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 22) user_defined_22
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 23) user_defined_23
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 24) user_defined_24
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 25) user_defined_25
        FROM claim c
  INNER JOIN claim_line cl
          ON (c.claim_iid = cl.claim_iid)
       WHERE c.claim_iid in (SELECT claim_iid FROM claim_purge_list)
         AND c.is_modified = 'N'
         AND c.claim_status = 'A'
         AND c.patient_mrn IS NOT NULL
         AND c.context = 1
         AND c.analysis_status <> 'NN'
         AND cl.service_start_date IS NOT NULL
         AND cl.service_start_date > ADD_MONTHS(SYSDATE,-48)
         AND cl.adjusted_specialty_code IS NOT NULL
         AND cl.status != 'D'
         AND NOT EXISTS
            (SELECT e1.separation, e1.descendent_iid, e1.ancestor_iid, f1.*
               FROM v_freya_list_data f1
         INNER JOIN enterprise_tree e1
                 ON (f1.enterprise_iid = e1.ancestor_iid)
              WHERE f1.freya_list_eid = '121'
                AND e1.descendent_iid = c.enterprise_iid
                AND cl.adjusted_procedure_code between f1.first_begin_value and f1.first_end_value
                AND e1.separation = (SELECT MIN(e2.separation)
                                       FROM v_freya_list_data f2
                                 INNER JOIN enterprise_tree e2
                                         ON (f2.enterprise_iid = e2.ancestor_iid)
                                      WHERE f2.freya_list_eid = f1.freya_list_eid
                                        AND f2.first_begin_value = f1.first_begin_value
                                        AND e2.descendent_iid = e1.descendent_iid));

      COMMIT;

       -- Delete 48 months before records from NPT table

       DELETE FROM npt WHERE service_start_date < ADD_MONTHS(SYSDATE,-48);

      COMMIT;

       INSERT INTO npt(npt_iid,patient_mrn,billing_provider_eid,billing_provider_specialty,service_start_date,
                       enterprise_iid,adjusted_procedure_code,department_eid,plan_eid,organizational_group_eid,
                       organizational_eid,user_defined_1,user_defined_2,user_defined_3,create_date,is_imported,
                       claim_eid,claim_line_eid,upin,billing_provider_taxonomy,tax_id_number,servicing_physician_eid,
                       servicing_provider_speciality,servicing_provider_taxonomy,group_eid,
                       user_defined_4,user_defined_5,user_defined_6,user_defined_7,user_defined_8,user_defined_9,user_defined_10,
                       user_defined_11,user_defined_12,user_defined_13,user_defined_14,user_defined_15,user_defined_16,user_defined_17,
                       user_defined_18,user_defined_19,user_defined_20,user_defined_21,user_defined_22,user_defined_23,user_defined_24,
                       user_defined_25,claim_line_iid)
       SELECT npt_iid,patient_mrn,billing_provider_eid,billing_provider_specialty,service_start_date,
              enterprise_iid,adjusted_procedure_code,department_eid,plan_eid,organizational_group_eid,
              organizational_eid,user_defined_1,user_defined_2,user_defined_3,create_date,is_imported,
              claim_eid,claim_line_eid,upin,billing_provider_taxonomy,tax_id_number,servicing_physician_eid,
              servicing_provider_speciality,servicing_provider_taxonomy,group_eid,
              user_defined_4,user_defined_5,user_defined_6,user_defined_7,user_defined_8,user_defined_9,user_defined_10,
              user_defined_11,user_defined_12,user_defined_13,user_defined_14,user_defined_15,user_defined_16,user_defined_17,
              user_defined_18,user_defined_19,user_defined_20,user_defined_21,user_defined_22,user_defined_23,user_defined_24,
              user_defined_25,claim_line_iid
         FROM npt_temp;

      INSERT INTO npt_diagnosis (npt_diagnosis_iid, diagnosis_code, diagnosis_order, npt_iid)
             SELECT s_npt_diagnosis.NEXTVAL, cld.diagnosis_code, cld.diagnosis_order, n.npt_iid
               FROM npt_temp N
         INNER JOIN claim_line_diagnosis cld
                 ON (n.claim_line_iid = cld.claim_line_iid);

      INSERT INTO npt_modifier (npt_modifier_iid, modifier_code, modifier_order, npt_iid)
             SELECT s_npt_modifier.NEXTVAL, clm.modifier_code, clm.modifier_order, n.npt_iid
               FROM npt_temp N
         INNER JOIN claim_line_modifier clm
                 ON (n.claim_line_iid = clm.claim_line_iid);

       COMMIT;

       EXECUTE IMMEDIATE 'TRUNCATE TABLE npt_temp';

       DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'NPT',estimate_percent=>'1',cascade=>true);

   END IF;  -- NPT CHECK

   IF p_npt = 1 AND p_include_nn_npt = 1
   THEN

       INSERT INTO npt_temp(npt_iid,patient_mrn,billing_provider_eid,billing_provider_specialty,service_start_date,
                 enterprise_iid,adjusted_procedure_code,department_eid,plan_eid,organizational_group_eid,
                 organizational_eid,user_defined_1,user_defined_2,user_defined_3,create_date,is_imported,
                 claim_eid,claim_line_eid,claim_line_iid,upin,billing_provider_taxonomy, tax_id_number,
                 servicing_physician_eid, servicing_provider_speciality,
                 servicing_provider_taxonomy, group_eid,user_defined_4,user_defined_5,user_defined_6,user_defined_7,user_defined_8,
                 user_defined_9,user_defined_10,user_defined_11,user_defined_12,user_defined_13,user_defined_14,user_defined_15,
                 user_defined_16,user_defined_17,user_defined_18,user_defined_19,user_defined_20,user_defined_21,user_defined_22,
                 user_defined_23,user_defined_24,user_defined_25)
      SELECT s_npt.NEXTVAL npt_iid
           , c.patient_mrn
           , cl.billing_provider_eid
           , CASE WHEN cl.adjusted_specialty_code IS NULL
                  THEN cl.billing_provider_specialty
             ELSE cl.adjusted_specialty_code
             END adjusted_specialty_code
           , cl.service_start_date
           , c.enterprise_iid
           , cl.adjusted_procedure_code
           , cl.billing_provider_department department_eid
           , c.plan_eid
           , cl.organizational_group_eid
           , cl.organizational_eid
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 1)  user_defined_1
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 2)  user_defined_2
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 3)  user_defined_3
           , SYSDATE create_date
           , 'N' is_imported
           , c.claim_eid
           , cl.claim_line_eid
           , cl.claim_line_iid
           , cl.billing_provider_upin upin
           , cl.billing_provider_taxonomy
           , cl.billing_provider_tax_id tax_id_number
           , cl.servicing_provider_eid servicing_physician_eid
           , cl.servicing_provider_specialty
           , cl.servicing_provider_taxonomy
           , cl.organizational_group_eid group_eid
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 4) user_defined_4
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 5) user_defined_5
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 6) user_defined_6
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 7) user_defined_7
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 8) user_defined_8
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 9) user_defined_9
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 10) user_defined_10
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 11) user_defined_11
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 12) user_defined_12
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 13) user_defined_13
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 14) user_defined_14
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 15) user_defined_15
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 16) user_defined_16
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 17) user_defined_17
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 18) user_defined_18
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 19) user_defined_19
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 20) user_defined_20
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 21) user_defined_21
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 22) user_defined_22
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 23) user_defined_23
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 24) user_defined_24
           , (SELECT value FROM claim_line_user_defined_field WHERE claim_line_iid = cl.claim_line_iid AND ordinal = 25) user_defined_25
        FROM claim c
  INNER JOIN claim_line cl
          ON (c.claim_iid = cl.claim_iid)
       WHERE c.claim_iid in (SELECT claim_iid FROM claim_purge_list)
         AND c.is_modified = 'N'
         AND c.claim_status = 'A'
         AND c.patient_mrn IS NOT NULL
         AND c.context = 1
         AND cl.service_start_date IS NOT NULL
         AND cl.service_start_date > ADD_MONTHS(SYSDATE,-48)
         AND (cl.adjusted_specialty_code IS NOT NULL
               OR
              cl.billing_provider_specialty IS NOT NULL)
         AND cl.status != 'D'
         AND NOT EXISTS
            (SELECT e1.separation, e1.descendent_iid, e1.ancestor_iid, f1.*
               FROM v_freya_list_data f1
         INNER JOIN enterprise_tree e1
                 ON (f1.enterprise_iid = e1.ancestor_iid)
              WHERE f1.freya_list_eid = '121'
                AND e1.descendent_iid = c.enterprise_iid
                AND (cl.adjusted_procedure_code between f1.first_begin_value and f1.first_end_value
                      OR
                     cl.submitted_procedure_code between f1.first_begin_value and f1.first_end_value
                    )
                and e1.separation = (SELECT MIN(e2.separation)
                                       FROM v_freya_list_data f2
                                 INNER JOIN enterprise_tree e2
                                         ON (f2.enterprise_iid = e2.ancestor_iid)
                                      WHERE f2.freya_list_eid = f1.freya_list_eid
                                        AND f2.first_begin_value = f1.first_begin_value
                                        AND e2.descendent_iid = e1.descendent_iid));

      COMMIT;

       --- Delete 48 months before data from NPT table

       DELETE FROM npt WHERE service_start_date < ADD_MONTHS(SYSDATE,-48);

      COMMIT;

       INSERT INTO npt(npt_iid,patient_mrn,billing_provider_eid,billing_provider_specialty,service_start_date,
                       enterprise_iid,adjusted_procedure_code,department_eid,plan_eid,organizational_group_eid,
                       organizational_eid,user_defined_1,user_defined_2,user_defined_3,create_date,is_imported,
                       claim_eid,claim_line_eid,upin,billing_provider_taxonomy,tax_id_number,servicing_physician_eid,
                       servicing_provider_speciality,servicing_provider_taxonomy,group_eid,
                       user_defined_4,user_defined_5,user_defined_6,user_defined_7,user_defined_8,user_defined_9,user_defined_10,
                       user_defined_11,user_defined_12,user_defined_13,user_defined_14,user_defined_15,user_defined_16,user_defined_17,
                       user_defined_18,user_defined_19,user_defined_20,user_defined_21,user_defined_22,user_defined_23,user_defined_24,
                       user_defined_25,claim_line_iid)
       SELECT npt_iid,patient_mrn,billing_provider_eid,billing_provider_specialty,service_start_date,
              enterprise_iid,adjusted_procedure_code,department_eid,plan_eid,organizational_group_eid,
              organizational_eid,user_defined_1,user_defined_2,user_defined_3,create_date,is_imported,
              claim_eid,claim_line_eid,upin,billing_provider_taxonomy,tax_id_number,servicing_physician_eid,
              servicing_provider_speciality,servicing_provider_taxonomy,group_eid,
              user_defined_4,user_defined_5,user_defined_6,user_defined_7,user_defined_8,user_defined_9,user_defined_10,
              user_defined_11,user_defined_12,user_defined_13,user_defined_14,user_defined_15,user_defined_16,user_defined_17,
              user_defined_18,user_defined_19,user_defined_20,user_defined_21,user_defined_22,user_defined_23,user_defined_24,
              user_defined_25,claim_line_iid FROM npt_temp;

      INSERT INTO npt_diagnosis (npt_diagnosis_iid, diagnosis_code, diagnosis_order, npt_iid)
             SELECT s_npt_diagnosis.NEXTVAL, cld.diagnosis_code, cld.diagnosis_order, n.npt_iid
               FROM npt_temp n
         INNER JOIN claim_line_diagnosis cld
                 ON (n.claim_line_iid = cld.claim_line_iid);

      INSERT INTO npt_modifier (npt_modifier_iid, modifier_code, modifier_order, npt_iid)
             SELECT s_npt_modifier.NEXTVAL, clm.modifier_code, clm.modifier_order, n.npt_iid
               FROM npt_temp n
         INNER JOIN claim_line_modifier clm
                 ON (n.claim_line_iid = clm.claim_line_iid);

       COMMIT;

       EXECUTE IMMEDIATE 'TRUNCATE TABLE npt_temp';

       DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'NPT',estimate_percent=>'1',cascade=>true);

   END IF;  -- NPT CHECK


--
--  Frequency stuff will go here.
--

   IF  p_discriminator='PRO' AND p_frequency = 1 AND p_include_nn_mfx = 0 AND (p_context IS NULL OR p_context = 1)
   THEN

--   Use temporary table FREQUENCY_HISTORY_TEMP to get data from active
--    claim data set that will be purged.

     INSERT INTO frequency_history_temp (patient_mrn
                                 , claim_eid, claim_line_eid, service_start_date
                                 , service_end_date, procedure_code
                                 , billing_provider_eid, billing_provider_specialty
                                 , service_units, context, enterprise_iid
                                 , claim_line_iid, is_imported, icd10_indicator )
     SELECT c.patient_mrn
          , c.claim_eid
          , cl.claim_line_eid
          , cl.service_start_date
          , cl.service_end_date
          , CASE WHEN cl.adjusted_procedure_code IS NULL THEN cl.submitted_procedure_code
                 ELSE cl.adjusted_procedure_code
            END adjusted_procedure_code
          , cl.billing_provider_eid
          , cl.billing_provider_specialty
          , cl.service_units
          , c.context
          , c.enterprise_iid
          , cl.claim_line_iid
          , 'N'
          , cl.icd10_indicator
      FROM claim c INNER JOIN claim_line cl ON (c.claim_iid = cl.claim_iid)
     WHERE c.claim_iid IN (SELECT claim_iid FROM claim_purge_list)
       AND c.context = 1
       AND c.claim_status = 'A'
       AND c.is_modified = 'N'
       AND c.patient_mrn IS NOT NULL
       AND c.analysis_status <> 'NN'
       AND cl.adjusted_procedure_code IS NOT NULL
       AND cl.service_units IS NOT NULL
       AND cl.service_start_date IS NOT NULL
       AND cl.status != 'D'
       AND EXISTS
       (SELECT mfc.procedure_code_beg
             , mfc.procedure_code_end
             , mfg.enterprise_iid
             , et.descendent_iid
             , et.ancestor_iid
             , et.separation
          FROM max_frequency_group mfg INNER JOIN max_frequency_codes mfc
            ON (mfc.max_frequency_group_iid = mfg.max_frequency_group_iid)
         INNER JOIN enterprise_tree et
            ON (et.ancestor_iid = mfg.enterprise_iid)
         WHERE et.descendent_iid = c.enterprise_iid
           AND cl.adjusted_procedure_code between mfc.procedure_code_beg and mfc.procedure_code_end
           AND et.separation = (SELECT MIN(et2.separation)
                                  FROM max_frequency_group mfg2 INNER JOIN max_frequency_codes mfc2
                                    ON (mfc2.max_frequency_group_iid = mfg2.max_frequency_group_iid)
                                 INNER JOIN enterprise_tree et2
                                    ON (et2.ancestor_iid = mfg2.enterprise_iid)
                                 WHERE et2.descendent_iid = et.descendent_iid
                                   AND mfc2.procedure_code_beg = mfc.procedure_Code_beg
                                   AND mfc2.procedure_code_end = mfc.procedure_code_end));




INSERT INTO frequency_history_temp (patient_mrn
                                 , claim_eid, claim_line_eid, service_start_date
                                 , service_end_date, procedure_code
                                 , billing_provider_eid, billing_provider_specialty
                                 , service_units, context, enterprise_iid
                                 , claim_line_iid, is_imported, icd10_indicator )
     SELECT c.patient_mrn
          , c.claim_eid
          , cl.claim_line_eid
          , cl.service_start_date
          , cl.service_end_date
          , CASE WHEN cl.adjusted_procedure_code IS NULL THEN cl.submitted_procedure_code
                 ELSE cl.adjusted_procedure_code
            END adjusted_procedure_code
          , cl.billing_provider_eid
          , cl.billing_provider_specialty
          , cl.service_units
          , c.context
          , c.enterprise_iid
          , cl.claim_line_iid
          , 'N'
          , cl.icd10_indicator
      FROM claim c INNER JOIN claim_line cl ON (c.claim_iid = cl.claim_iid)
     WHERE c.claim_iid IN (SELECT claim_iid FROM claim_purge_list)
       AND c.context = 1
       AND c.claim_status = 'A'
       AND c.is_modified = 'N'
       AND c.patient_mrn IS NOT NULL
       AND c.analysis_status <> 'NN'
       AND cl.adjusted_procedure_code IS NOT NULL
       AND cl.service_units IS NOT NULL
       AND cl.service_start_date IS NOT NULL
       AND cl.status != 'D'
AND EXISTS

                                   (SELECT lfp.procedure_code_begin
             , lfp.procedure_code_end
             , lfp.enterprise_iid
             , et.descendent_iid
             , et.ancestor_iid
             , et.separation
          FROM V_LCD_FREQ_PROCEDURE_OVERRIDE lfp
            JOIN v_lcd_contractor lc ON (lc.contractor_eid = lfp.contractor_eid
          AND lc.extract_date = lfp.extract_date)
  JOIN V_LCD_DATA_CONTRACTOR l
    ON (l.contractor_eid = lc.contractor_eid
          AND
        l.extract_date = lc.extract_date
       )

         INNER JOIN enterprise_tree et
            ON (et.ancestor_iid = lfp.enterprise_iid)
         WHERE et.descendent_iid = c.enterprise_iid
           AND cl.adjusted_procedure_code between lfp.procedure_code_begin and lfp.procedure_code_end
           AND et.separation = (SELECT MIN(et2.separation)
                                  FROM V_LCD_FREQ_PROCEDURE_OVERRIDE lfp2
                                 INNER JOIN enterprise_tree et2
                                    ON (et2.ancestor_iid = lfp2.enterprise_iid)
                                 WHERE et2.descendent_iid = et.descendent_iid
                                   AND lfp2.procedure_code_begin = lfp.procedure_code_begin
                                   AND lfp2.procedure_code_end = lfp.procedure_code_end)
                                   AND
                                    (lc.contractor_type = 'MB'
                                    OR lc.contractor_type = 'CA'
                                    OR lc.contractor_type = 'NB'
                                    OR lc.contractor_type = 'DP'
                                    OR lc.contractor_type = 'DM'
                                    OR lc.contractor_type = 'DC'
                                    OR lc.contractor_type = 'DA'
                                   OR lc.contractor_type = 'ND')
                                  );


--   Remove any potential duplicates

     DELETE FROM frequency_history_diag
      WHERE frequency_history_iid IN (SELECT frequency_history_iid
                                        FROM frequency_history
                                       WHERE (claim_eid, claim_line_eid) IN (SELECT claim_eid, claim_line_eid
                                                                               FROM frequency_history_temp)
                                     );

     DELETE FROM frequency_history_mod
      WHERE frequency_history_iid IN (SELECT frequency_history_iid
                                        FROM frequency_history
                                       WHERE (claim_eid, claim_line_eid) IN (SELECT claim_eid, claim_line_eid
                                                                               FROM frequency_history_temp)
                                     );

     DELETE FROM frequency_history
      WHERE (claim_eid, claim_line_eid) IN (SELECT claim_eid, claim_line_eid
                                              FROM frequency_history_temp);

--   Add new frequency history data . . . starting with the frequency_history table

     INSERT INTO frequency_history (frequency_history_iid, patient_mrn
                                 , claim_eid, claim_line_eid, service_start_date
                                 , service_end_date, procedure_code
                                 , billing_provider_eid, billing_provider_specialty
                                 , service_units, context, enterprise_iid
                                 , claim_line_iid, is_imported, icd10_indicator )
     SELECT s_frequency_history.NEXTVAL, patient_mrn
          , claim_eid, claim_line_eid, service_start_date
          , service_end_date, procedure_code
          , billing_provider_eid, billing_provider_specialty
          , service_units, context, enterprise_iid
          , claim_line_iid, is_imported, icd10_indicator
       FROM frequency_history_temp;

     INSERT INTO frequency_history_diag (frequency_history_diag_iid
                                      , diagnosis_code, diagnosis_order
                                      , frequency_history_iid)
     SELECT s_frequency_history_diag.NEXTVAL, cld.diagnosis_code
          , cld.diagnosis_order, fh.frequency_history_iid
       FROM frequency_history fh INNER JOIN claim_line_diagnosis cld
         ON (fh.claim_line_iid = cld.claim_line_iid);

     INSERT INTO frequency_history_mod (frequency_history_mod_iid
                                     , modifier_code, modifier_order
                                     , frequency_history_iid)
     SELECT s_frequency_history_mod.NEXTVAL
          , CASE WHEN clm.adjusted_modifier_code IS NULL THEN clm.modifier_code
            ELSE clm.adjusted_modifier_code
            END adjusted_modifier_code
          , clm.modifier_order, fh.frequency_history_iid
       FROM frequency_history fh INNER JOIN claim_line_modifier clm
         ON (fh.claim_line_iid = clm.claim_line_iid);

     COMMIT;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE frequency_history_temp';

      DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'FREQUENCY_HISTORY',estimate_percent=>'1',cascade=>true);
      DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'FREQUENCY_HISTORY_DIAG',estimate_percent=>'1',cascade=>true);
      DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'FREQUENCY_HISTORY_MOD',estimate_percent=>'1',cascade=>true);

   END IF;  -- Frequency

   IF  p_discriminator='PRO'  AND p_frequency = 1 AND p_include_nn_mfx = 1 AND (p_context IS NULL OR p_context = 1)
   THEN

--   Use temporary table FREQUENCY_HISTORY_TEMP to get data from active
--    claim data set that will be purged.

     INSERT INTO frequency_history_temp (patient_mrn
                                 , claim_eid, claim_line_eid, service_start_date
                                 , service_end_date, procedure_code
                                 , billing_provider_eid, billing_provider_specialty
                                 , service_units, context, enterprise_iid
                                 , claim_line_iid, is_imported, icd10_indicator )
     SELECT c.patient_mrn
          , c.claim_eid
          , cl.claim_line_eid
          , cl.service_start_date
          , cl.service_end_date
          , CASE WHEN cl.adjusted_procedure_code IS NULL THEN cl.submitted_procedure_code
                 ELSE cl.adjusted_procedure_code
            END adjusted_procedure_code
          , cl.billing_provider_eid
          , cl.billing_provider_specialty
          , cl.service_units
          , c.context
          , c.enterprise_iid
          , cl.claim_line_iid
          , 'N'
          , cl.icd10_indicator
      FROM claim c inner join claim_line cl ON (c.claim_iid = cl.claim_iid)
     WHERE c.claim_iid IN (SELECT claim_iid FROM claim_purge_list)
       AND c.context = 1
       AND c.claim_status = 'A'
       AND c.is_modified = 'N'
       AND c.patient_mrn IS NOT NULL
       AND (cl.adjusted_procedure_code IS NOT NULL
              OR
            cl.submitted_procedure_code IS NOT NULL)
       AND cl.service_units IS NOT NULL
       AND cl.service_start_date IS NOT NULL
       AND cl.status != 'D'
       AND EXISTS
       (SELECT mfc.procedure_code_beg
             , mfc.procedure_code_end
             , mfg.enterprise_iid
             , et.descendent_iid
             , et.ancestor_iid
             , et.separation
          FROM max_frequency_group mfg INNER JOIN max_frequency_codes mfc
            ON (mfc.max_frequency_group_iid = mfg.max_frequency_group_iid)
         INNER JOIN enterprise_tree et
            ON (et.ancestor_iid = mfg.enterprise_iid)
         WHERE et.descendent_iid = c.enterprise_iid
           AND (cl.adjusted_procedure_code BETWEEN mfc.procedure_code_beg AND mfc.procedure_code_end
                 OR
                cl.submitted_procedure_code BETWEEN mfc.procedure_code_beg AND mfc.procedure_code_end
               )
           AND et.separation = (SELECT MIN(et2.separation)
                                  FROM max_frequency_group mfg2 INNER JOIN max_frequency_codes mfc2
                                    ON (mfc2.max_frequency_group_iid = mfg2.max_frequency_group_iid)
                                 INNER JOIN enterprise_tree et2
                                    ON (et2.ancestor_iid = mfg2.enterprise_iid)
                                 WHERE et2.descendent_iid = et.descendent_iid
                                   AND mfc2.procedure_code_beg = mfc.procedure_Code_beg
                                   AND mfc2.procedure_code_end = mfc.procedure_code_end));



     INSERT INTO frequency_history_temp (patient_mrn
                                 , claim_eid, claim_line_eid, service_start_date
                                 , service_end_date, procedure_code
                                 , billing_provider_eid, billing_provider_specialty
                                 , service_units, context, enterprise_iid
                                 , claim_line_iid, is_imported, icd10_indicator )
     SELECT c.patient_mrn
          , c.claim_eid
          , cl.claim_line_eid
          , cl.service_start_date
          , cl.service_end_date
          , CASE WHEN cl.adjusted_procedure_code IS NULL THEN cl.submitted_procedure_code
                 ELSE cl.adjusted_procedure_code
            END adjusted_procedure_code
          , cl.billing_provider_eid
          , cl.billing_provider_specialty
          , cl.service_units
          , c.context
          , c.enterprise_iid
          , cl.claim_line_iid
          , 'N'
          , cl.icd10_indicator
      FROM claim c inner join claim_line cl ON (c.claim_iid = cl.claim_iid)
     WHERE c.claim_iid IN (SELECT claim_iid FROM claim_purge_list)
       AND c.context = 1
       AND c.claim_status = 'A'
       AND c.is_modified = 'N'
       AND c.patient_mrn IS NOT NULL
       AND (cl.adjusted_procedure_code IS NOT NULL
              OR
            cl.submitted_procedure_code IS NOT NULL)
       AND cl.service_units IS NOT NULL
       AND cl.service_start_date IS NOT NULL
       AND cl.status != 'D'
       AND EXISTS

                                   (SELECT lfp.procedure_code_begin
             , lfp.procedure_code_end
             , lfp.enterprise_iid
             , et.descendent_iid
             , et.ancestor_iid
             , et.separation
          FROM V_LCD_FREQ_PROCEDURE_OVERRIDE lfp
            JOIN v_lcd_contractor lc ON (lc.contractor_eid = lfp.contractor_eid
          AND lc.extract_date = lfp.extract_date)
  JOIN V_LCD_DATA_CONTRACTOR l
    ON (l.contractor_eid = lc.contractor_eid
          AND
        l.extract_date = lc.extract_date
       )

         INNER JOIN enterprise_tree et
            ON (et.ancestor_iid = lfp.enterprise_iid)
         WHERE et.descendent_iid = c.enterprise_iid
           AND (cl.adjusted_procedure_code BETWEEN lfp.procedure_code_begin AND lfp.procedure_code_end
                 OR
                cl.submitted_procedure_code BETWEEN lfp.procedure_code_begin AND lfp.procedure_code_end
               )
           AND et.separation = (SELECT MIN(et2.separation)
                                  FROM V_LCD_FREQ_PROCEDURE_OVERRIDE lfp2
                                 INNER JOIN enterprise_tree et2
                                    ON (et2.ancestor_iid = lfp2.enterprise_iid)
                                 WHERE et2.descendent_iid = et.descendent_iid
                                   AND lfp2.procedure_code_begin = lfp.procedure_code_begin
                                   AND lfp2.procedure_code_end = lfp.procedure_code_end)
                                   AND
                                    (lc.contractor_type = 'MB'
                                    OR lc.contractor_type = 'CA'
                                    OR lc.contractor_type = 'NB'
                                    OR lc.contractor_type = 'DP'
                                    OR lc.contractor_type = 'DM'
                                    OR lc.contractor_type = 'DC'
                                    OR lc.contractor_type = 'DA'
                                    OR lc.contractor_type = 'ND')
                                  );

--   Remove any potential duplicates

     DELETE FROM frequency_history_diag
      WHERE frequency_history_iid IN (SELECT frequency_history_iid
                                        FROM frequency_history
                                       WHERE (claim_eid, claim_line_eid) IN (SELECT claim_eid, claim_line_eid
                                                                               FROM frequency_history_temp)
                                     );

     DELETE FROM frequency_history_mod
      WHERE frequency_history_iid IN (SELECT frequency_history_iid
                                        FROM frequency_history
                                       WHERE (claim_eid, claim_line_eid) IN (SELECT claim_eid, claim_line_eid
                                                                               FROM frequency_history_temp)
                                     );

     DELETE FROM frequency_history
      WHERE (claim_eid, claim_line_eid) IN (SELECT claim_eid, claim_line_eid
                                              FROM frequency_history_temp);

--   Add new frequency history data . . . starting with the frequency_history table

     INSERT INTO frequency_history (frequency_history_iid, patient_mrn
                                 , claim_eid, claim_line_eid, service_start_date
                                 , service_end_date, procedure_code
                                 , billing_provider_eid, billing_provider_specialty
                                 , service_units, context, enterprise_iid
                                 , claim_line_iid, is_imported, icd10_indicator )
     SELECT s_frequency_history.NEXTVAL, patient_mrn
          , claim_eid, claim_line_eid, service_start_date
          , service_end_date, procedure_code
          , billing_provider_eid, billing_provider_specialty
          , service_units, context, enterprise_iid
          , claim_line_iid, is_imported, icd10_indicator
       FROM frequency_history_temp;

     INSERT INTO frequency_history_diag (frequency_history_diag_iid
                                      , diagnosis_code, diagnosis_order
                                      , frequency_history_iid)
     SELECT s_frequency_history_diag.NEXTVAL, cld.diagnosis_code
          , cld.diagnosis_order, fh.frequency_history_iid
       FROM frequency_history fh INNER JOIN claim_line_diagnosis cld
         ON (fh.claim_line_iid = cld.claim_line_iid);

     INSERT INTO frequency_history_mod (frequency_history_mod_iid
                                     , modifier_code, modifier_order
                                     , frequency_history_iid)
     SELECT s_frequency_history_mod.NEXTVAL
          , CASE WHEN clm.adjusted_modifier_code IS NULL THEN clm.modifier_code
            ELSE clm.adjusted_modifier_code
            END adjusted_modifier_code
          , clm.modifier_order, fh.frequency_history_iid
       FROM frequency_history fh INNER JOIN claim_line_modifier clm
         ON (fh.claim_line_iid = clm.claim_line_iid);

     COMMIT;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE frequency_history_temp';

      DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'FREQUENCY_HISTORY',estimate_percent=>'1',cascade=>true);
      DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'FREQUENCY_HISTORY_DIAG',estimate_percent=>'1',cascade=>true);
      DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'FREQUENCY_HISTORY_MOD',estimate_percent=>'1',cascade=>true);

   END IF;  -- Frequency

--Prakash Added Additional condition for FE

IF  p_discriminator='INST' AND p_frequency = 1 AND p_include_nn_mfx = 0 AND (p_context IS NULL OR p_context = 1)
   THEN

--   Use temporary table FE_FREQUENCY_HISTORY_TEMP to get data from active
--    claim data set that will be purged.

     INSERT INTO fe_frequency_history_temp (patient_mrn
                                 , claim_eid, claim_line_eid, service_start_date
                                 , service_end_date, procedure_code
                                 , facility_eid, type_of_bill
                                 , service_units, context, enterprise_iid
                                 , claim_line_iid, is_imported, icd10_indicator )
     SELECT c.patient_mrn
          , c.claim_eid
          , cl.claim_line_eid
          , cl.service_start_date
          , cl.service_end_date
          , CASE WHEN cl.adjusted_procedure_code IS NULL THEN cl.submitted_procedure_code
                 ELSE cl.adjusted_procedure_code
            END adjusted_procedure_code
          , c.facility_eid
          , c.type_of_bill
          , cl.service_units
          , c.context
          , c.enterprise_iid
          , cl.claim_line_iid
          , 'N'
          , cl.icd10_indicator
      FROM claim c INNER JOIN claim_line cl ON (c.claim_iid = cl.claim_iid)
     WHERE c.claim_iid IN (SELECT claim_iid FROM claim_purge_list)
       AND c.context = 1
       AND c.claim_status = 'A'
       AND c.in_out_patient='O'
       AND c.is_modified = 'N'
       AND c.patient_mrn IS NOT NULL
       AND c.analysis_status <> 'NN'
       AND cl.adjusted_procedure_code IS NOT NULL
       AND cl.service_units IS NOT NULL
       AND cl.service_start_date IS NOT NULL
       AND cl.status != 'D'
       AND EXISTS
       (SELECT mfc.procedure_code_beg
             , mfc.procedure_code_end
             , mfg.enterprise_iid
             , et.descendent_iid
             , et.ancestor_iid
             , et.separation
          FROM V_FE_PROC_MAX_FREQ_GROUP mfg INNER JOIN V_FE_PROC_MAX_FREQ_CODES mfc
            ON (mfc.max_frequency_codes_iid = mfg.iid)
         INNER JOIN enterprise_tree et
            ON (et.ancestor_iid = mfg.enterprise_iid)
         WHERE et.descendent_iid = c.enterprise_iid
           AND cl.adjusted_procedure_code between mfc.procedure_code_beg and mfc.procedure_code_end
           AND et.separation = (SELECT MIN(et2.separation)
                                  FROM V_FE_PROC_MAX_FREQ_GROUP mfg2 INNER JOIN V_FE_PROC_MAX_FREQ_CODES mfc2
                                    ON (mfc2.max_frequency_codes_iid = mfg2.iid)
                                 INNER JOIN enterprise_tree et2
                                    ON (et2.ancestor_iid = mfg2.enterprise_iid)
                                 WHERE et2.descendent_iid = et.descendent_iid
                                   AND mfc2.procedure_code_beg = mfc.procedure_Code_beg
                                   AND mfc2.procedure_code_end = mfc.procedure_code_end));


INSERT INTO fe_frequency_history_temp (patient_mrn
                                 , claim_eid, claim_line_eid, service_start_date
                                 , service_end_date, procedure_code
                                 , facility_eid, type_of_bill
                                 , service_units, context, enterprise_iid
                                 , claim_line_iid, is_imported, icd10_indicator )
     SELECT c.patient_mrn
          , c.claim_eid
          , cl.claim_line_eid
          , cl.service_start_date
          , cl.service_end_date
          , CASE WHEN cl.adjusted_procedure_code IS NULL THEN cl.submitted_procedure_code
                 ELSE cl.adjusted_procedure_code
            END adjusted_procedure_code
          , c.facility_eid
          , c.type_of_bill
          , cl.service_units
          , c.context
          , c.enterprise_iid
          , cl.claim_line_iid
          , 'N'
          , cl.icd10_indicator
      FROM claim c INNER JOIN claim_line cl ON (c.claim_iid = cl.claim_iid)
     WHERE c.claim_iid IN (SELECT claim_iid FROM claim_purge_list)
       AND c.context = 1
       AND c.claim_status = 'A'
       AND c.in_out_patient='O'
       AND c.is_modified = 'N'
       AND c.patient_mrn IS NOT NULL
       AND c.analysis_status <> 'NN'
       AND cl.adjusted_procedure_code IS NOT NULL
       AND cl.service_units IS NOT NULL
       AND cl.service_start_date IS NOT NULL
       AND cl.status != 'D'
       AND EXISTS

              (SELECT lfp.procedure_code_begin
             , lfp.procedure_code_end
             , lfp.enterprise_iid
             , et.descendent_iid
             , et.ancestor_iid
             , et.separation
          FROM V_LCD_FREQ_PROCEDURE_OVERRIDE lfp
            JOIN v_lcd_contractor lc ON (lc.contractor_eid = lfp.contractor_eid
          AND lc.extract_date = lfp.extract_date)
  JOIN V_LCD_DATA_CONTRACTOR l
    ON (l.contractor_eid = lc.contractor_eid
          AND
        l.extract_date = lc.extract_date
       )

         INNER JOIN enterprise_tree et
            ON (et.ancestor_iid = lfp.enterprise_iid)
         WHERE et.descendent_iid = c.enterprise_iid
           AND cl.adjusted_procedure_code between lfp.procedure_code_begin and lfp.procedure_code_end
           AND et.separation = (SELECT MIN(et2.separation)
                                  FROM V_LCD_FREQ_PROCEDURE_OVERRIDE lfp2
                                 INNER JOIN enterprise_tree et2
                                    ON (et2.ancestor_iid = lfp2.enterprise_iid)
                                 WHERE et2.descendent_iid = et.descendent_iid
                                   AND lfp2.procedure_code_begin = lfp.procedure_code_begin
                                   AND lfp2.procedure_code_end = lfp.procedure_code_end)
                                   AND
                                   (lc.contractor_type = 'MA' OR
                      lc.contractor_type = 'FI' OR
                      lc.contractor_type = 'NA' OR
                      lc.contractor_type = 'DP' OR
                      lc.contractor_type = 'DM' OR
                      lc.contractor_type = 'DC' OR
                      lc.contractor_type = 'RI' OR
                      lc.contractor_type = 'DA' OR
                      lc.contractor_type = 'ND')
                                  );

--   Remove any potential duplicates

     DELETE FROM fe_frequency_history_diag
      WHERE frequency_history_iid IN (SELECT a.iid
                                        FROM fe_frequency_history a
                                       WHERE (claim_eid, claim_line_eid) IN (SELECT claim_eid, claim_line_eid
                                                                               FROM fe_frequency_history_temp)
                                     );

     DELETE FROM fe_frequency_history_mod
      WHERE frequency_history_iid IN (SELECT a.iid
                                        FROM fe_frequency_history a
                                       WHERE (claim_eid, claim_line_eid) IN (SELECT claim_eid, claim_line_eid
                                                                               FROM fe_frequency_history_temp)
                                     );

     DELETE FROM fe_frequency_history
      WHERE (claim_eid, claim_line_eid) IN (SELECT claim_eid, claim_line_eid
                                              FROM fe_frequency_history_temp);

--   Add new frequency history data . . . starting with the frequency_history table

     INSERT INTO fe_frequency_history (iid, patient_mrn
                                 , claim_eid, claim_line_eid, service_start_date
                                 , service_end_date, procedure_code
                                 , facility_eid,type_of_bill
                                 , service_units, context, enterprise_iid
                                 , claim_line_iid, is_imported, icd10_indicator )
     SELECT s_fe_frequency_history.NEXTVAL, patient_mrn
          , claim_eid, claim_line_eid, service_start_date
          , service_end_date, procedure_code
          , facility_eid,type_of_bill
          , service_units, context, enterprise_iid
          , claim_line_iid, is_imported, icd10_indicator
       FROM fe_frequency_history_temp;



         INSERT INTO FE_FREQUENCY_HISTORY_DIAG (IID,
                                       DIAGNOSIS_CODE,
                                       DIAGNOSIS_ORDER
                                      ,FREQUENCY_HISTORY_IID)
     SELECT s_fe_frequency_history_diag.NEXTVAL,
     C.PRINCIPAL_DIAGNOSIS ,0,  FH.IID
       FROM FE_FREQUENCY_HISTORY FH INNER JOIN CLAIM C
         ON (FH.CLAIM_EID = C.CLAIM_EID) WHERE  c.context = 1
       AND c.claim_status = 'A'
       AND c.is_modified = 'N'
       AND c.in_out_patient='O'
       AND c.patient_mrn IS NOT NULL
       AND c.analysis_status <> 'NN' AND C.PRINCIPAL_DIAGNOSIS IS NOT NULL;


         INSERT INTO FE_FREQUENCY_HISTORY_DIAG (IID,
                                       DIAGNOSIS_CODE,
                                       DIAGNOSIS_ORDER
                                      , FREQUENCY_HISTORY_IID)
                                  SELECT s_fe_frequency_history_diag.NEXTVAL,
                                  ICA.CODE AS PRINCIPAL_DIAGNOSIS ,
                                  ICA.ORDINAL,FH.IID
       FROM CLAIM C INNER JOIN INSTITUTIONAL_CLAIM_ATTRIBUTE ICA
                            ON (C.CLAIM_IID = ICA.CLAIM_IID)
                   INNER JOIN FE_FREQUENCY_HISTORY FH
                   ON(FH.CLAIM_EID = C.CLAIM_EID)
                                WHERE  c.context = 1
       AND c.claim_status = 'A'
       AND c.is_modified = 'N'
       AND c.in_out_patient='O'
       AND c.patient_mrn IS NOT NULL
       AND c.analysis_status <> 'NN' AND ICA.RECORD_TYPE IN('CD') AND ICA.CODE IS NOT NULL;


     INSERT INTO fe_frequency_history_mod (iid
                                     , modifier_code, modifier_order
                                     , frequency_history_iid)
     SELECT s_fe_frequency_history_mod.NEXTVAL
          , CASE WHEN clm.adjusted_modifier_code IS NULL THEN clm.modifier_code
            ELSE clm.adjusted_modifier_code
            END adjusted_modifier_code
          , clm.modifier_order, fh.iid
       FROM fe_frequency_history fh INNER JOIN claim_line_modifier clm
         ON (fh.claim_line_iid = clm.claim_line_iid);

     COMMIT;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE fe_frequency_history_temp';

      DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'FE_FREQUENCY_HISTORY',estimate_percent=>'1',cascade=>true);
      DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'FE_FREQUENCY_HISTORY_DIAG',estimate_percent=>'1',cascade=>true);
      DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'FE_FREQUENCY_HISTORY_MOD',estimate_percent=>'1',cascade=>true);

   END IF;


IF p_discriminator='INST' AND p_frequency = 1 AND p_include_nn_mfx = 1 AND (p_context IS NULL OR p_context = 1)
   THEN

--   Use temporary table FREQUENCY_HISTORY_TEMP to get data from active
--    claim data set that will be purged.

     INSERT INTO fe_frequency_history_temp (patient_mrn
                                 , claim_eid, claim_line_eid, service_start_date
                                 , service_end_date, procedure_code
                                 , facility_eid, type_of_bill
                                 , service_units, context, enterprise_iid
                                 , claim_line_iid, is_imported, icd10_indicator )
     SELECT c.patient_mrn
          , c.claim_eid
          , cl.claim_line_eid
          , cl.service_start_date
          , cl.service_end_date
          , CASE WHEN cl.adjusted_procedure_code IS NULL THEN cl.submitted_procedure_code
                 ELSE cl.adjusted_procedure_code
            END adjusted_procedure_code
          , c.facility_eid
          , c.type_of_bill
          , cl.service_units
          , c.context
          , c.enterprise_iid
          , cl.claim_line_iid
          , 'N'
          , cl.icd10_indicator
      FROM claim c inner join claim_line cl ON (c.claim_iid = cl.claim_iid)
     WHERE c.claim_iid IN (SELECT claim_iid FROM claim_purge_list)
       AND c.context = 1
       AND c.claim_status = 'A'
       AND c.is_modified = 'N'
       AND c.in_out_patient='O'
       AND c.patient_mrn IS NOT NULL
       AND (cl.adjusted_procedure_code IS NOT NULL
              OR
            cl.submitted_procedure_code IS NOT NULL)
       AND cl.service_units IS NOT NULL
       AND cl.service_start_date IS NOT NULL
       AND cl.status != 'D'
       AND EXISTS
       (SELECT mfc.procedure_code_beg
             , mfc.procedure_code_end
             , mfg.enterprise_iid
             , et.descendent_iid
             , et.ancestor_iid
             , et.separation
          FROM V_FE_PROC_MAX_FREQ_GROUP mfg INNER JOIN V_FE_PROC_MAX_FREQ_CODES mfc
            ON (mfc.max_frequency_codes_iid = mfg.iid)
         INNER JOIN enterprise_tree et
            ON (et.ancestor_iid = mfg.enterprise_iid)
         WHERE et.descendent_iid = c.enterprise_iid
           AND (cl.adjusted_procedure_code BETWEEN mfc.procedure_code_beg AND mfc.procedure_code_end
                 OR
                cl.submitted_procedure_code BETWEEN mfc.procedure_code_beg AND mfc.procedure_code_end
               )
           AND et.separation = (SELECT MIN(et2.separation)
                                 FROM V_FE_PROC_MAX_FREQ_GROUP mfg2 INNER JOIN V_FE_PROC_MAX_FREQ_CODES mfc2
                                    ON (mfc2.max_frequency_codes_iid = mfg2.iid)
                                 INNER JOIN enterprise_tree et2
                                    ON (et2.ancestor_iid = mfg2.enterprise_iid)
                                 WHERE et2.descendent_iid = et.descendent_iid
                                   AND mfc2.procedure_code_beg = mfc.procedure_Code_beg
                                   AND mfc2.procedure_code_end = mfc.procedure_code_end));



   INSERT INTO fe_frequency_history_temp (patient_mrn
                                 , claim_eid, claim_line_eid, service_start_date
                                 , service_end_date, procedure_code
                                 , facility_eid, type_of_bill
                                 , service_units, context, enterprise_iid
                                 , claim_line_iid, is_imported, icd10_indicator )
     SELECT c.patient_mrn
          , c.claim_eid
          , cl.claim_line_eid
          , cl.service_start_date
          , cl.service_end_date
          , CASE WHEN cl.adjusted_procedure_code IS NULL THEN cl.submitted_procedure_code
                 ELSE cl.adjusted_procedure_code
            END adjusted_procedure_code
          , c.facility_eid
          , c.type_of_bill
          , cl.service_units
          , c.context
          , c.enterprise_iid
          , cl.claim_line_iid
          , 'N'
          , cl.icd10_indicator
      FROM claim c inner join claim_line cl ON (c.claim_iid = cl.claim_iid)
     WHERE c.claim_iid IN (SELECT claim_iid FROM claim_purge_list)
       AND c.context = 1
       AND c.claim_status = 'A'
       AND c.is_modified = 'N'
       AND c.in_out_patient='O'
       AND c.patient_mrn IS NOT NULL
       AND (cl.adjusted_procedure_code IS NOT NULL
              OR
            cl.submitted_procedure_code IS NOT NULL)
       AND cl.service_units IS NOT NULL
       AND cl.service_start_date IS NOT NULL
       AND cl.status != 'D'
       AND EXISTS


                                   (SELECT lfp.procedure_code_begin
             , lfp.procedure_code_end
             , lfp.enterprise_iid
             , et.descendent_iid
             , et.ancestor_iid
             , et.separation
          FROM V_LCD_FREQ_PROCEDURE_OVERRIDE lfp
            JOIN v_lcd_contractor lc ON (lc.contractor_eid = lfp.contractor_eid
          AND lc.extract_date = lfp.extract_date)
  JOIN V_LCD_DATA_CONTRACTOR l
    ON (l.contractor_eid = lc.contractor_eid
          AND
        l.extract_date = lc.extract_date
       )

         INNER JOIN enterprise_tree et
            ON (et.ancestor_iid = lfp.enterprise_iid)
         WHERE et.descendent_iid = c.enterprise_iid
            AND (cl.adjusted_procedure_code BETWEEN lfp.procedure_code_begin AND lfp.procedure_code_end
                 OR
                cl.submitted_procedure_code BETWEEN lfp.procedure_code_begin AND lfp.procedure_code_end
               )
           AND et.separation = (SELECT MIN(et2.separation)
                                  FROM V_LCD_FREQ_PROCEDURE_OVERRIDE lfp2
                                 INNER JOIN enterprise_tree et2
                                    ON (et2.ancestor_iid = lfp2.enterprise_iid)
                                 WHERE et2.descendent_iid = et.descendent_iid
                                   AND lfp2.procedure_code_begin = lfp.procedure_code_begin
                                   AND lfp2.procedure_code_end = lfp.procedure_code_end)
                                   AND
                                   (lc.contractor_type = 'MA' OR
                      lc.contractor_type = 'FI' OR
                      lc.contractor_type = 'NA' OR
                      lc.contractor_type = 'DP' OR
                      lc.contractor_type = 'DM' OR
                      lc.contractor_type = 'DC' OR
                      lc.contractor_type = 'RI' OR
                      lc.contractor_type = 'DA' OR
                      lc.contractor_type = 'ND')
                                  );

--   Remove any potential duplicates
--Modified the iid to frequency_history_iid to delete correctly
     DELETE FROM fe_frequency_history_diag
      WHERE frequency_history_iid IN (SELECT a.iid FROM fe_frequency_history a
                  WHERE (claim_eid, claim_line_eid) IN (SELECT claim_eid, claim_line_eid
                                                                               FROM fe_frequency_history_temp)
                                     );
--Modified the iid to frequency_history_iid to delete correctly
     DELETE FROM fe_frequency_history_mod
      WHERE frequency_history_iid IN (SELECT a.iid
                                        FROM fe_frequency_history a
                                       WHERE (claim_eid, claim_line_eid) IN (SELECT claim_eid, claim_line_eid
                                                                               FROM fe_frequency_history_temp)
                                     );

     DELETE FROM fe_frequency_history
      WHERE (claim_eid, claim_line_eid) IN (SELECT claim_eid, claim_line_eid
                                              FROM fe_frequency_history_temp);

--   Add new frequency history data . . . starting with the frequency_history table

    INSERT INTO fe_frequency_history (iid, patient_mrn
                                 , claim_eid, claim_line_eid, service_start_date
                                 , service_end_date, procedure_code
                                 , facility_eid, type_of_bill
                                 , service_units, context, enterprise_iid
                                 , claim_line_iid, is_imported, icd10_indicator )
     SELECT s_fe_frequency_history.NEXTVAL, patient_mrn
          , claim_eid, claim_line_eid, service_start_date
          , service_end_date, procedure_code
          , facility_eid, type_of_bill
          , service_units, context, enterprise_iid
          , claim_line_iid, is_imported, icd10_indicator
       FROM fe_frequency_history_temp;


         INSERT INTO FE_FREQUENCY_HISTORY_DIAG (IID,
                                       DIAGNOSIS_CODE,
                                       DIAGNOSIS_ORDER
                                      ,FREQUENCY_HISTORY_IID)
     SELECT s_fe_frequency_history_diag.NEXTVAL,
     C.PRINCIPAL_DIAGNOSIS ,0,  FH.IID
       FROM FE_FREQUENCY_HISTORY FH INNER JOIN CLAIM C
         ON (FH.CLAIM_EID = C.CLAIM_EID) WHERE  c.context = 1
       AND c.claim_status = 'A'
       AND c.is_modified = 'N'
       AND c.in_out_patient='O'
       AND c.patient_mrn IS NOT NULL  AND C.PRINCIPAL_DIAGNOSIS IS NOT NULL;

         INSERT INTO FE_FREQUENCY_HISTORY_DIAG (IID,
                                       DIAGNOSIS_CODE,
                                       DIAGNOSIS_ORDER
                                      , FREQUENCY_HISTORY_IID)
                                  SELECT s_fe_frequency_history_diag.NEXTVAL,
                                  ICA.CODE AS PRINCIPAL_DIAGNOSIS ,
                                  ICA.ORDINAL,FH.IID
       FROM CLAIM C INNER JOIN INSTITUTIONAL_CLAIM_ATTRIBUTE ICA
                            ON (C.CLAIM_IID = ICA.CLAIM_IID)
                   INNER JOIN FE_FREQUENCY_HISTORY FH
                   ON(FH.CLAIM_EID = C.CLAIM_EID)
                                WHERE c.context = 1
       AND c.claim_status = 'A'
       AND c.is_modified = 'N'
       AND c.in_out_patient='O'
                AND c.patient_mrn IS NOT NULL AND ICA.RECORD_TYPE IN('CD') AND ICA.CODE IS NOT NULL;



     INSERT INTO fe_frequency_history_mod (iid
                                     , modifier_code, modifier_order
                                     , frequency_history_iid)
     SELECT s_fe_frequency_history_mod.NEXTVAL
          , CASE WHEN clm.adjusted_modifier_code IS NULL THEN clm.modifier_code
            ELSE clm.adjusted_modifier_code
            END adjusted_modifier_code
          , clm.modifier_order, fh.iid
       FROM fe_frequency_history fh INNER JOIN claim_line_modifier clm
         ON (fh.claim_line_iid = clm.claim_line_iid);

     COMMIT;


      EXECUTE IMMEDIATE 'TRUNCATE TABLE fe_frequency_history_temp';

      DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'FE_FREQUENCY_HISTORY',estimate_percent=>'1',cascade=>true);
      DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'FE_FREQUENCY_HISTORY_DIAG',estimate_percent=>'1',cascade=>true);
      DBMS_STATS.GATHER_TABLE_STATS(user,tabname=>'FE_FREQUENCY_HISTORY_MOD',estimate_percent=>'1',cascade=>true);

   END IF;  -- FE Frequency


   -- Run the PPS Results Purge
   usp_pps_results_purge;

--
--  Bulk operations using cursors and limits to purge the data.
--

-- Do NOT run the following section (submitted_claim_iid) for Claims Manager, but DO run it for CES
-- also dont run it if a ces client does not have any modified claims:
-- DE89542
  
select count(0) into v_modified_claim_count from icp_p.claim where submitted_claim_iid is not null;
     
   IF v_modified_claim_count > 0 THEN

        OPEN c_claim_iid;
        LOOP
          FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;


--
--  Remove child claims first  SUBMITTED_CLAIM_IIDs
--


            FORALL idx IN 1 .. claim_iids.COUNT
              DELETE FROM claim_line_edit
               WHERE claim_line_iid IN (SELECT claim_line_iid
                                          FROM claim_line cl
                                          JOIN claim c
                                            ON ( c.claim_iid = cl.claim_iid)
                                         WHERE c.submitted_claim_iid = claim_iids(idx).claim_iid
                                       );

            FORALL idx IN 1 .. claim_iids.COUNT
              DELETE FROM ruleset_processing_history
               WHERE claim_line_iid IN (SELECT claim_line_iid
                                          FROM claim_line cl
                                          JOIN claim c
                                            ON ( c.claim_iid = cl.claim_iid)
                                         WHERE c.submitted_claim_iid = claim_iids(idx).claim_iid
                                       );

           FORALL idx IN 1 .. claim_iids.COUNT
             DELETE FROM ruleset_processing_history
               WHERE claim_iid IN ( SELECT claim_iid
                                     FROM claim
                                    WHERE submitted_claim_iid = claim_iids(idx).claim_iid
                                 );


            FORALL idx IN 1 .. claim_iids.COUNT
              DELETE FROM claim_line_diagnosis
               WHERE claim_line_iid IN (SELECT claim_line_iid
                                          FROM claim_line cl
                                          JOIN claim c
                                            ON ( c.claim_iid = cl.claim_iid)
                                         WHERE c.submitted_claim_iid = claim_iids(idx).claim_iid
                                       );

            FORALL idx IN 1 .. claim_iids.COUNT
              DELETE FROM claim_line_modifier
               WHERE claim_line_iid IN (SELECT claim_line_iid
                                          FROM claim_line cl
                                          JOIN claim c
                                            ON ( c.claim_iid = cl.claim_iid)
                                         WHERE c.submitted_claim_iid = claim_iids(idx).claim_iid
                                       );

            FORALL idx IN 1 .. claim_iids.COUNT
              DELETE FROM claim_line_user_defined_field
               WHERE claim_line_iid IN (SELECT claim_line_iid
                                          FROM claim_line cl
                                          JOIN claim c
                                            ON ( c.claim_iid = cl.claim_iid)
                                         WHERE c.submitted_claim_iid = claim_iids(idx).claim_iid
                                       );

            FORALL idx IN 1 .. claim_iids.COUNT
              DELETE FROM claim_line_history
               WHERE claim_line_iid IN (SELECT claim_line_iid
                                          FROM claim_line cl
                                          JOIN claim c
                                            ON ( c.claim_iid = cl.claim_iid)
                                         WHERE c.submitted_claim_iid = claim_iids(idx).claim_iid
                                       );

            FORALL idx IN 1 .. claim_iids.COUNT
              DELETE FROM claim_line
               WHERE claim_line_iid IN (SELECT claim_line_iid
                                          FROM claim_line cl
                                          JOIN claim c
                                            ON ( c.claim_iid = cl.claim_iid)
                                         WHERE c.submitted_claim_iid = claim_iids(idx).claim_iid
                                       );

            FORALL idx IN 1 .. claim_iids.COUNT
              DELETE FROM institutional_claim_attribute
               WHERE claim_iid = ( SELECT claim_iid
                                     FROM claim
                                    WHERE submitted_claim_iid = claim_iids(idx).claim_iid
                                 );

            FORALL idx IN 1 .. claim_iids.COUNT
              DELETE FROM claim_edit
               WHERE claim_iid = ( SELECT claim_iid
                                     FROM claim
                                    WHERE submitted_claim_iid = claim_iids(idx).claim_iid
                                 );

           FORALL idx IN 1 .. claim_iids.COUNT
              DELETE FROM claim_processing_history
               WHERE claim_iid = ( SELECT claim_iid
                                     FROM claim
                                    WHERE submitted_claim_iid = claim_iids(idx).claim_iid
                                 );

            FORALL idx IN 1 .. claim_iids.COUNT
              DELETE FROM claim
               WHERE submitted_claim_iid = claim_iids(idx).claim_iid;

         EXIT WHEN c_claim_iid%NOTFOUND;
             COMMIT;
         END LOOP;
         CLOSE c_claim_iid;

     END IF;
-- END DE89542

--
--  Now remove the CLAIMs
--

     OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

        FORALL idx IN 1 .. claim_iids.COUNT
          DELETE from claim_line_edit
           WHERE claim_line_iid = claim_iids(idx).claim_line_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

     OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

        FORALL idx IN 1 .. claim_iids.COUNT
          DELETE from ruleset_processing_history
           WHERE claim_line_iid = claim_iids(idx).claim_line_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

      OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

        FORALL idx IN 1 .. claim_iids.COUNT
          DELETE from ruleset_processing_history
           WHERE claim_iid = claim_iids(idx).claim_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

     OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

        FORALL idx IN 1 .. claim_iids.COUNT
          DELETE from claim_line_diagnosis
           WHERE claim_line_iid = claim_iids(idx).claim_line_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

     OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

        FORALL idx IN 1 .. claim_iids.COUNT
          DELETE from claim_line_modifier
           WHERE claim_line_iid = claim_iids(idx).claim_line_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

     OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

        FORALL idx IN 1 .. claim_iids.COUNT
          DELETE from claim_line_user_defined_field
           WHERE claim_line_iid = claim_iids(idx).claim_line_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

     OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

        FORALL idx IN 1 .. claim_iids.COUNT
          DELETE from claim_line_history
           WHERE claim_line_iid = claim_iids(idx).claim_line_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

     OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

        FORALL idx IN 1 .. claim_iids.COUNT
          DELETE from claim_line
           WHERE claim_line_iid = claim_iids(idx).claim_line_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

     OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

        FORALL idx IN 1 .. claim_iids.COUNT
          DELETE from institutional_claim_attribute
           WHERE claim_iid = claim_iids(idx).claim_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

     OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

        FORALL idx IN 1 .. claim_iids.COUNT
          DELETE from claim_edit
           WHERE claim_iid = claim_iids(idx).claim_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

     OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

            FORALL idx IN 1 .. claim_iids.COUNT
          DELETE from claim_processing_history
           WHERE claim_iid = claim_iids(idx).claim_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

     OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

--        FORALL idx IN 1 .. claim_iids.COUNT
--          DELETE from claim
--           WHERE submitted_claim_iid = claim_iids(idx).claim_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

     OPEN c_claim_iid;
      LOOP

        FETCH c_claim_iid BULK COLLECT INTO claim_iids LIMIT 100000;

        FORALL idx IN 1 .. claim_iids.COUNT
          DELETE from claim
           WHERE claim_iid = claim_iids(idx).claim_iid;

      -- Update current claim counts

        v_actual_claim_count := v_actual_claim_count + claim_iids.COUNT;

        UPDATE scheduled_purge_log
           SET total_records_purged = v_actual_claim_count
         WHERE iid = v_scheduled_purge_log_iid;

      EXIT WHEN c_claim_iid%NOTFOUND;
          COMMIT;
      END LOOP;
     CLOSE c_claim_iid;

--
--  purge_claim_log info
--

    UPDATE scheduled_purge_log
       SET purge_end = SYSDATE
         , claims_purged = v_non_modified_claim_count
     WHERE iid = v_scheduled_purge_log_iid;


   INSERT INTO audit_log
               (audit_log_iid, audit_domain, component_name,
                component_iid, component_eid, audit_message,
                audit_activity, audit_level, audit_date,
                permissible_user_iid, username
               )
        VALUES ( s_audit_log.NEXTVAL, 'D', 'Purge',
                 9999999, '9999999',
                 '( '||v_scheduled_purge_job_name||' ) purge completed: '||to_char(sysdate,'MM/DD/YYYY HH:MI:SS')
                 ||' '||o_purgecount||' claims purged.',
                 'Purging', 'INFO', sysdate, p_user_id, p_username
               );
   COMMIT;

   EXECUTE IMMEDIATE 'TRUNCATE TABLE claim_purge_list';

   END IF;  -- IF for countonly.


EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
      DBMS_OUTPUT.put_line (SQLERRM);
      v_err_message := SQLERRM;

    UPDATE scheduled_purge_log
       SET purge_end = SYSDATE
         , error_message = v_err_message
     WHERE iid = v_scheduled_purge_log_iid;

   INSERT INTO audit_log
               (audit_log_iid, audit_domain, component_name,
                component_iid, component_eid, audit_message,
                audit_activity, audit_level, audit_date,
                permissible_user_iid, username
               )
        VALUES ( s_audit_log.NEXTVAL, 'D', 'Purge',
                 9999999, '9999999', 'Error in purge ( '||v_scheduled_purge_job_name||' ) '||v_err_message,
                 'Purging', 'ERROR', sysdate, p_user_id, p_username
               );
   COMMIT;

    EXECUTE IMMEDIATE 'TRUNCATE TABLE npt_temp';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE frequency_history_temp';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE claim_purge_list';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE fe_frequency_history_temp';


END usp_claim_purge;
/

-- End of usp_claim_purge procedure

-- claim_purge procedure
create or replace PROCEDURE ICP_P.claim_purge
( p_enterprise_iid            IN  claim.enterprise_iid%TYPE
, p_context                   IN  claim.context%TYPE
, p_claim_status              IN  claim.claim_status%TYPE
, p_begin_claim_eid           IN  claim.claim_eid%TYPE
, p_end_claim_eid             IN  claim.claim_eid%TYPE
, p_begin_batch_eid           IN  claim.batch_eid%TYPE
, p_end_batch_eid             IN  claim.batch_eid%TYPE
, p_begin_external_entry_date IN  claim.external_entry_date%TYPE
, p_end_external_entry_date   IN  claim.external_entry_date%TYPE
, p_discriminator             IN  claim.discriminator%TYPE
, p_user_id                   IN  audit_log.PERMISSIBLE_USER_IID%TYPE
, p_username                  IN  audit_log.USERNAME%TYPE
, p_frequency                 IN  INTEGER                             := 0
, p_npt                       IN  INTEGER                             := 0
, p_in_out_patient            IN  claim.in_out_patient%TYPE
, p_older_than_days           IN  INTEGER
, p_claim_eid_like            IN  claim.claim_eid%TYPE
, p_batch_eid_like            IN  claim.batch_eid%TYPE
, p_scheduled_purge_iid       IN  scheduled_purge.iid%TYPE
, p_include_nn_npt            IN  scheduled_purge.include_nn_npt%TYPE := 0
, p_include_nn_mfx            IN  scheduled_purge.include_nn_mfx%TYPE := 0
, p_pe_module                 IN  scheduled_purge.pe_module%TYPE
, p_fe_module                 IN  scheduled_purge.fe_module%TYPE
)
AS
-- ******************************************************************************
--   NAME:       claim_purge
--   PURPOSE:    Call USP_CLAIM_PURGE procedure with count and out variable returned.
--
--   REVISIONS:
--   Ver        Date        Author           Description
--   ---------  ----------  ---------------  ------------------------------------
--   1.0        01/06/2010  Jeff Evans       Created this procedure.
--   1.1        01/08/2010  Jeff Evans       Added p_scheduled_purge_iid for logging.
--   1.2        04/22/2010  Jeff Evans       Added INCLUDE_NN_NPT and INCLUDE_NN_MFX to
--                                             support un-analyzed claims in NPT and MFX.
--   1.3        06/27/2016  Purnima          Added pe_module and fe_module columns
--
--   NOTES:
--
--   Calls USP_CLAIM_PURGE procedure because you can't schedule a procedure
--     with an OUT parameter.
--
--   Parameter List:
--
--   p_context                1 or 0  (1=live 0=test)
--   p_claim_status           'A' or 'I' ('A'=current 'I'=noncurrent)
--   p_begin_claim_eid        claim_eid
--   p_end_claim_eid          claim_eid
--   p_discriminator          'PRO' or 'INST' ('PRO'=professional 'INST' facility)
--   p_frequency              1 or 0
--   p_npt                    1 or 0
--   p_in_out_patient         'I' or 'O'
--   p_older_than_days          Integer, number of days older than SYSDATE - p_older_than_days
--   p_include_nn_npt         1 or 0  (1=NN claims will be added to NPT table 0=Not added)
--   p_include_nn_mfx         1 or 0  (1=NN claims will be added to MFX tables 0=Not added)
--   p_pe_module              'Y' or null (Y if atleast one Professinal enterprise is selected else Null)
--   p_fe_module              Null or 'ALL' or 'IP' or 'OP' (Null - No Facility enterprise is selected; 
--                            All - Both inpatient and outpatient are selected
--                            IP- Only Inpatient is selected
--                            OP- Only Outpatient is selected
--
-- ******************************************************************************


   v_purgecount                  PLS_INTEGER    := 0;
   v_countonly                   PLS_INTEGER    := 0;
   v_discriminator               VARCHAR2(5)    := NULL;
   v_in_out_patient              VARCHAR2(1)    := NULL;

BEGIN

--
--  Check for required parameters.
--

    -- No parameters are required

  -- Call usp_claim_purge including the v_purgecount as the OUT parameter.
  -- usp_claim_purge (p_enterprise_iid, p_context, p_claim_status, p_begin_claim_eid, p_end_claim_eid, p_begin_batch_eid, p_end_batch_eid, p_begin_external_entry_date, p_end_external_entry_date, p_discriminator, p_user_id, p_username, p_frequency, p_npt, v_countonly, v_purgecount, p_in_out_patient, p_older_than_days, p_claim_eid_like, p_batch_eid_like, p_scheduled_purge_iid, p_include_nn_npt, p_include_nn_mfx, p_pe_module, p_fe_module);  
  IF p_pe_module IS NOT NULL THEN
    v_discriminator := 'PRO';
    usp_claim_purge (p_enterprise_iid, p_context, p_claim_status, p_begin_claim_eid, p_end_claim_eid, p_begin_batch_eid, p_end_batch_eid, p_begin_external_entry_date, p_end_external_entry_date, v_discriminator, p_user_id, p_username, p_frequency, p_npt, v_countonly, v_purgecount, p_in_out_patient, p_older_than_days, p_claim_eid_like, p_batch_eid_like, p_scheduled_purge_iid, p_include_nn_npt, p_include_nn_mfx, p_pe_module, p_fe_module);
  END IF;
  
  IF p_fe_module IS NOT NULL THEN
    v_discriminator := 'INST';
    IF p_fe_module = 'IP' THEN
      v_in_out_patient := 'I';
    END IF;
    IF p_fe_module = 'OP' THEN
      v_in_out_patient := 'O';
    END IF;
    
    usp_claim_purge (p_enterprise_iid, p_context, p_claim_status, p_begin_claim_eid, p_end_claim_eid, p_begin_batch_eid, p_end_batch_eid, p_begin_external_entry_date, p_end_external_entry_date, v_discriminator, p_user_id, p_username, p_frequency, p_npt, v_countonly, v_purgecount, v_in_out_patient, p_older_than_days, p_claim_eid_like, p_batch_eid_like, p_scheduled_purge_iid, p_include_nn_npt, p_include_nn_mfx, p_pe_module, p_fe_module);
  END IF;  
    
 
  COMMIT; 

EXCEPTION
   WHEN OTHERS
   THEN
      RAISE;

END claim_purge;
/
-- End of claim_purge procedure

--  schedule_purge procedure
create or replace PROCEDURE ICP_P.schedule_purge
( p_enterprise_iid            IN  claim.enterprise_iid%TYPE
, p_context                   IN  claim.context%TYPE
, p_claim_status              IN  claim.claim_status%TYPE
, p_begin_claim_eid           IN  claim.claim_eid%TYPE
, p_end_claim_eid             IN  claim.claim_eid%TYPE
, p_begin_batch_eid           IN  claim.batch_eid%TYPE
, p_end_batch_eid             IN  claim.batch_eid%TYPE
, p_begin_external_entry_date IN  claim.external_entry_date%TYPE
, p_end_external_entry_date   IN  claim.external_entry_date%TYPE
, p_module                    IN  VARCHAR2
, p_user_id                   IN  audit_log.PERMISSIBLE_USER_IID%TYPE
, p_username                  IN  audit_log.USERNAME%TYPE
, p_npt                       IN  INTEGER  := 0
, p_frequency_hist            IN  INTEGER  := 0
, p_older_than_days           IN  INTEGER  := 0
, p_job_name                  IN  VARCHAR2
, p_start_date                IN  DATE
, p_frequency                 IN  VARCHAR2
, p_day_of_week               IN  VARCHAR2
, p_week_number               IN  VARCHAR2
, p_claim_eid_like            IN  VARCHAR2
, p_batch_eid_like            IN  VARCHAR2
, p_scheduled_purge_iid       IN  scheduled_purge.iid%TYPE
, p_include_nn_npt            IN  scheduled_purge.include_nn_npt%TYPE
, p_include_nn_mfx            IN  scheduled_purge.include_nn_mfx%TYPE
, p_pe_module                 IN  scheduled_purge.pe_module%TYPE
, p_fe_module                 IN  scheduled_purge.fe_module%TYPE
)
AS
-- ******************************************************************************
--   NAME:       schedule_purge
--   PURPOSE:    Creates a job in the Oracle scheduler.
--
--   REVISIONS:
--   Ver        Date        Author           Description
--   ---------  ----------  ---------------  ------------------------------------
--   1.0        11/13/2009  Jeff Evans       Created this procedure
--   1.1        11/16/2009  Jeff Evans       Added p_in_out_patient parameter.
--   1.2        11/17/2009  Jeff Evans       Added p_frequency, p_day_of_week,
--                                            p_week_number
--   1.3        12/10/2009  Jeff Evans       Added "Yearly" as a frequency.
--
--   1.4        04/22/2010  Jeff Evans       Added INCLUDE_NN_NPT and INCLUDE_NN_MFX to
--                                             support un-analyzed claims in NPT and MFX.
--
--   1.5        04/27/2016  Purnima         Added pe_module and fe_module columns.
--
--   NOTES:
--
--
--   Parameter List:
--
--   p_enteprise_iid          Enterprise IID
--   p_context                1 or 0  (1=live 0=test)
--   p_claim_status           'A' or 'I' ('A'=current 'I'=noncurrent)
--   p_begin_claim_eid        claim_eid
--   p_end_claim_eid          claim_eid
--   p_begin_batch_eid        batch_eid
--   p_end_batch_eid          batch_eid
--   p_begin_external_entry_date
--   p_end_external_entry_date
--   p_module                'Professional', 'Facility All', 'Facility In-Patient', 'Facility Out-Patient'
--   p_frequency_hist         1 or 0
--   p_npt                    1 or 0
--   p_job_name               Unique Job name
--   p_older_than_days        number of days older than current date
--   p_start_time
--   p_frequency              'Weekly','Daily','Monthly','Yearly'
--   p_day_of_week            'Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'
--   p_week_number            '1','2','3','4'
--   p_claim_eid_like         String with wildcard  (contains)
--   p_batch_eid_like         String with wildcard  (contains)
--   p_include_nn_npt         1 or 0  (1=NN claims will be added to NPT table 0=Not added)
--   p_include_nn_mfx         1 or 0  (1=NN claims will be added to MFX tables 0=Not added)
-- ******************************************************************************
   v_repeat_interval  VARCHAR2(512);
   v_job_name         VARCHAR2(30);
BEGIN

--
--  Create repeat_interval string.
--
  CASE p_frequency
     WHEN 'Weekly'  THEN
         CASE p_day_of_week
            WHEN 'Sunday'     THEN v_repeat_interval := 'FREQ=WEEKLY;BYDAY=SUN';
            WHEN 'Monday'     THEN v_repeat_interval := 'FREQ=WEEKLY;BYDAY=MON';
            WHEN 'Tuesday'    THEN v_repeat_interval := 'FREQ=WEEKLY;BYDAY=TUE';
            WHEN 'Wednesday'  THEN v_repeat_interval := 'FREQ=WEEKLY;BYDAY=WED';
            WHEN 'Thursday'   THEN v_repeat_interval := 'FREQ=WEEKLY;BYDAY=THU';
            WHEN 'Friday'     THEN v_repeat_interval := 'FREQ=WEEKLY;BYDAY=FRI';
            WHEN 'Saturday'   THEN v_repeat_interval := 'FREQ=WEEKLY;BYDAY=SAT';
          END CASE;

     WHEN 'Daily'   THEN v_repeat_interval := 'FREQ=DAILY';

     WHEN 'Monthly' THEN
          CASE p_day_of_week
              WHEN 'Sunday'     THEN v_repeat_interval := 'FREQ=MONTHLY;BYDAY='||p_week_number||'SUN';
              WHEN 'Monday'     THEN v_repeat_interval := 'FREQ=MONTHLY;BYDAY='||p_week_number||'MON';
              WHEN 'Tuesday'    THEN v_repeat_interval := 'FREQ=MONTHLY;BYDAY='||p_week_number||'TUE';
              WHEN 'Wednesday'  THEN v_repeat_interval := 'FREQ=MONTHLY;BYDAY='||p_week_number||'WED';
              WHEN 'Thursday'   THEN v_repeat_interval := 'FREQ=MONTHLY;BYDAY='||p_week_number||'THU';
              WHEN 'Friday'     THEN v_repeat_interval := 'FREQ=MONTHLY;BYDAY='||p_week_number||'FRI';
              WHEN 'Saturday'   THEN v_repeat_interval := 'FREQ=MONTHLY;BYDAY='||p_week_number||'SAT';
          END CASE;

     WHEN 'Yearly' THEN v_repeat_interval := 'FREQ=YEARLY';


     ELSE v_repeat_interval := NULL;

  END CASE;

--
--  If p_job_name is NULL then it is a "PURGE NOW" and the name will be set
--   here with a datetime.
--

   IF p_job_name IS NULL THEN
      v_job_name := 'PURGE_'||to_char(SYSDATE,'DD_MON_YYYY_HHMISS');
   ELSE
      v_job_name := p_job_name;
   END IF;
--
--  Create job with name a program
--

DBMS_SCHEDULER.CREATE_JOB (
   job_name          =>  v_job_name,
   program_name      =>  'PURGE_SCHEDULER',
   repeat_interval   =>  v_repeat_interval,
   start_date        =>  p_start_date,
   enabled           =>  FALSE);

--
--  Set job's parameter values
--

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_enterprise_iid',
    argument_value    => p_enterprise_iid);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_context',
    argument_value    => p_context);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_claim_status',
    argument_value    => p_claim_status);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_begin_claim_eid',
    argument_value    => p_begin_claim_eid);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_end_claim_eid',
    argument_value    => p_end_claim_eid);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_begin_batch_eid',
    argument_value    => p_begin_batch_eid);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_end_batch_eid',
    argument_value    => p_end_batch_eid);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_begin_external_entry_date',
    argument_value    => p_begin_external_entry_date);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_end_external_entry_date',
    argument_value    => p_end_external_entry_date);

--
-- Change this to the appropriate mapping:
--
-- Based on pe_module and fe_module, the discriminator and in_out_patient will be determined. Hence, this mapping from module is removed.
/*
CASE p_module
     WHEN 'Professional' THEN
        DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
          job_name          => v_job_name,
           argument_name     => 'p_discriminator',
          argument_value    => 'PRO');
     WHEN 'Facility All' THEN
        DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
           job_name          => v_job_name,
           argument_name     => 'p_discriminator',
           argument_value    => 'INST');
     WHEN 'Facility In-Patient' THEN
        DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
           job_name          => v_job_name,
           argument_name     => 'p_discriminator',
           argument_value    => 'INST');
        DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
           job_name          => v_job_name,
           argument_name     => 'p_in_out_patient',
           argument_value    => 'I');
     WHEN 'Facility Out-Patient' THEN
        DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
           job_name          => v_job_name,
           argument_name     => 'p_discriminator',
           argument_value    => 'INST');
        DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
           job_name          => v_job_name,
           argument_name     => 'p_in_out_patient',
           argument_value    => 'O');
     ELSE
        DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
           job_name          => v_job_name,
           argument_name     => 'p_discriminator',
           argument_value    => NULL);
        DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
           job_name          => v_job_name,
           argument_name     => 'p_in_out_patient',
           argument_value    => NULL);
END CASE;
*/

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_user_id',
    argument_value    => p_user_id);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_username',
    argument_value    => p_username);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_frequency_hist',
    argument_value    => p_frequency_hist);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_npt',
    argument_value    => p_npt);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_older_than_days',
    argument_value    => p_older_than_days);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_claim_eid_like',
    argument_value    => p_claim_eid_like);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_batch_eid_like',
    argument_value    => p_batch_eid_like);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_include_nn_npt',
    argument_value    => p_include_nn_npt);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_include_nn_mfx',
    argument_value    => p_include_nn_mfx);

DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_scheduled_purge_iid',
    argument_value    => p_scheduled_purge_iid);
    
DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_pe_module',
    argument_value    => p_pe_module);   
    
DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE (
    job_name          => v_job_name,
    argument_name     => 'p_fe_module',
    argument_value    => p_fe_module);        

--
--  Enable Job
--

DBMS_SCHEDULER.ENABLE(name=>v_job_name);

END schedule_purge;
/
-- End of schedule_purge procedure

-- monitor_scheduled_purge procedure
create or replace PROCEDURE ICP_P.monitor_scheduled_purge
IS
--******************************************************************************
--   NAME:       monitor_scheduled_purge
--   PURPOSE:    Looks at SCHEDULED_PURGE table for new entries
--                 ( WHERE is_scheduled = 'N' ) and then calls the
--                 SCHEDULED_PURGE procedure to create the scheduled job.
--
--   REVISIONS:
--   Ver        Date        Author           Description
--   ---------  ----------  ---------------  -----------------------------------
--   1.0        12/08/2009  Jeff Evans       Created this procedure.
--   1.1        01/07/2009  Jeff Evans       Added entries for tracking job scheduling
--                                             in the AUDIT_LOG table.
--   1.2        01/08/2010  Jeff Evans       Added delete_purge procedure.
--
--   1.3        04/22/2010  Jeff Evans       Added INCLUDE_NN_NPT and INCLUDE_NN_MFX columns.
--   1.4        06/27/2016  Purnima          Added pe_module and fe_module columns.
--   NOTES:
--
--******************************************************************************
  v_err_message              varchar2(2000);
  v_username                 permissible_user.username%TYPE;
  v_permissible_user_iid     permissible_user.permissible_user_iid%TYPE;
  v_scheduled_purge_iid      scheduled_purge.iid%TYPE;
  v_job_name                 scheduled_purge.job_name%TYPE;

  BEGIN
     --  Delete jobs.
     FOR i IN ( SELECT * FROM scheduled_purge
                 WHERE status = 'D'
                   AND type = 'Repeating'
                   AND deleted IS NOT NULL
                   AND scheduled_purge_deleted IS NULL
              )
       LOOP

          -- Get username from permissible_user table.

          SELECT username INTO v_username
            FROM permissible_user
           WHERE permissible_user_iid = i.created_user_iid;

          SELECT i.created_user_iid INTO v_permissible_user_iid
            FROM dual;

          -- Get job_name and iid from scheduled_purge table (for AUDIT_LOG table).

          SELECT i.iid INTO v_scheduled_purge_iid
            FROM dual;

          SELECT i.job_name INTO v_job_name
            FROM dual;

          DELETE_PURGE(i.job_name);

          UPDATE scheduled_purge
             SET scheduled_purge_deleted = SYSDATE
           WHERE iid = i.iid;

          INSERT INTO audit_log
               (audit_log_iid, audit_domain, component_name,
                component_iid, component_eid, audit_message,
                audit_activity, audit_level, audit_date,
                permissible_user_iid, username
               )
          VALUES ( s_audit_log.NEXTVAL, 'D', 'Purge',
                 9999999, '9999999', 'Purge ('||i.job_name||') deleted by '||v_username||' ('||v_permissible_user_iid||')',
                 'Delete Purge Job', 'INFO', sysdate, v_permissible_user_iid, v_username
                 );

          COMMIT;

       END LOOP;
       
     --  Schedule new jobs.
     FOR i IN ( SELECT * FROM scheduled_purge
                 WHERE is_scheduled = 'N'
              )
       LOOP
       -- ENTERPRISE_IID will always be passed in as NULL, get username from permissible_user table

          SELECT username INTO v_username
            FROM permissible_user
           WHERE permissible_user_iid = i.created_user_iid;

          SELECT i.created_user_iid INTO v_permissible_user_iid
            FROM dual;

          -- Get job_name and iid from scheduled_purge table (for AUDIT_LOG table).

          SELECT i.iid INTO v_scheduled_purge_iid
            FROM dual;

          SELECT i.job_name INTO v_job_name
            FROM dual;
            
          SCHEDULE_PURGE ( NULL, i.context, i.claim_status, i.begin_claim_eid, i.end_claim_eid, i.begin_batch_eid, i.end_batch_eid, i.begin_import_date, i.end_import_date, i.module, i.created_user_iid, v_username, i.npt, i.frequency_history, i.older_than_days, i.job_name, i.start_time, i.frequency, i.day_of_week, i.week_number, i.claim_eid_like, i.batch_eid_like, i.iid, i.include_nn_npt, i.include_nn_mfx, i.pe_module, i.fe_module);

          UPDATE scheduled_purge
             SET is_scheduled = 'Y'
           WHERE iid = i.iid;

          INSERT INTO audit_log
               (audit_log_iid, audit_domain, component_name,
                component_iid, component_eid, audit_message,
                audit_activity, audit_level, audit_date,
                permissible_user_iid, username
               )
          VALUES ( s_audit_log.NEXTVAL, 'D', 'Purge',
                 9999999, '9999999', 'Purge ('||i.job_name||') scheduled by '||v_username||' ('||v_permissible_user_iid||')',
                 'Create Purge Job', 'INFO', sysdate, v_permissible_user_iid, v_username
                 );

          COMMIT;

       END LOOP;

   EXCEPTION
     WHEN OTHERS THEN
      ROLLBACK;
      DBMS_OUTPUT.put_line (SQLERRM);
      v_err_message := SQLERRM;

   UPDATE scheduled_purge
      SET error_message = v_err_message
    WHERE iid = v_scheduled_purge_iid;

   INSERT INTO audit_log
               (audit_log_iid, audit_domain, component_name,
                component_iid, component_eid, audit_message,
                audit_activity, audit_level, audit_date,
                permissible_user_iid, username
               )
        VALUES ( s_audit_log.NEXTVAL, 'D', 'Purge',
                 9999999, '9999999', 'Error in Scheduling Purge(iid = '||v_scheduled_purge_iid||'): '||v_err_message,
                 'Purging', 'ERROR', sysdate, v_permissible_user_iid, v_username
               );
   COMMIT;
       RAISE;
  END monitor_scheduled_purge;
/
-- End of monitor_scheduled_purge procedure

COMMIT;


--Stored procedure for Claim Edit Summary Report

create or replace PROCEDURE USP_CLAIM_EDIT_SUMMARY_REPORT(
    p_context       IN NUMBER,
    start_date      IN DATE,
    end_date        IN DATE,
    group_by_filter IN VARCHAR2,
    p_enterprise_id IN NUMBER,
    p_in_out_patient IN VARCHAR2,
    p_unique_id IN VARCHAR2,
    total_analyzed_claim_count OUT NUMBER,
    total_edit_claim_count OUT NUMBER) AS
BEGIN
  dbms_application_info.set_client_info(p_unique_id);
  IF group_by_filter = 'Count' THEN
    SELECT COUNT(*)
    INTO total_analyzed_claim_count
    FROM CLAIM
    WHERE IS_MODIFIED    = 'N'
    AND ANALYSIS_STATUS <> 'NN'
    AND claim_status     = 'A'
    AND context          = p_context
    AND enterprise_iid   = p_enterprise_id
    AND last_analysis_date BETWEEN start_date AND end_date
    AND ((p_in_out_patient IS NOT NULL AND in_out_patient = p_in_out_patient)
    OR in_out_patient is null);
    SELECT COUNT(*)
    INTO total_edit_claim_count
    FROM CLAIM
    WHERE (CLAIM_IID IN
      (SELECT DISTINCT(CLAIM_IID)
      FROM CLAIM_LINE
      WHERE CLAIM_LINE_IID IN
        (SELECT DISTINCT(CLAIM_LINE_IID) FROM claim_line_edit
        )
      )
    OR CLAIM_IID IN
      (SELECT DISTINCT(claim_iid) FROM CLAIM_EDIT
      ))
    AND IS_MODIFIED      = 'N'
    AND ANALYSIS_STATUS <> 'NN'
    AND claim_status     = 'A'
    AND context          = p_context
    AND enterprise_iid   = p_enterprise_id
    AND last_analysis_date BETWEEN start_date AND end_date
     AND ((p_in_out_patient IS NOT NULL AND in_out_patient = p_in_out_patient)
    OR in_out_patient is null);
  END IF;
  IF group_by_filter = 'Submitted Charge' THEN
    SELECT SUM(charged_amount)
    INTO total_analyzed_claim_count
    FROM CLAIM_LINE
    WHERE CLAIM_IID IN
      (SELECT CLAIM_IID
      FROM CLAIM
      WHERE IS_MODIFIED    = 'N'
      AND ANALYSIS_STATUS <> 'NN'
      AND claim_status     = 'A'
      AND context          = p_context
      AND enterprise_iid   = p_enterprise_id
      AND last_analysis_date BETWEEN start_date AND end_date
       AND ((p_in_out_patient IS NOT NULL AND in_out_patient = p_in_out_patient)
    OR in_out_patient is null)
      );
          
     select sum(charged_amount) into total_edit_claim_count from claim_line where claim_iid in
     ( SELECT DISTINCT(t.claim_iid)
       FROM
        (SELECT c.claim_iid
        FROM claim c
        JOIN claim_line cl
        ON (c.claim_iid = cl.claim_iid)
        JOIN claim_line_edit cle
        ON (cl.claim_line_iid = cle.claim_line_iid)
        WHERE C.IS_MODIFIED    = 'N'
      AND C.ANALYSIS_STATUS <> 'NN'
          AND C.claim_status     = 'A'
      AND C.context          = p_context
      AND C.enterprise_iid   = p_enterprise_id
      AND C.LAST_ANALYSIS_DATE BETWEEN start_date AND end_date
         AND ((p_in_out_patient IS NOT NULL AND C.IN_OUT_PATIENT = p_in_out_patient)
    OR C.IN_OUT_PATIENT is NULL)
        UNION 
        SELECT c.claim_iid
        FROM claim c
        JOIN claim_edit ce
        ON (c.claim_iid        = ce.claim_iid)
       WHERE C.IS_MODIFIED    = 'N'
      AND C.ANALYSIS_STATUS <> 'NN'
          AND C.claim_status     = 'A'
      AND C.context          = p_context
      AND C.enterprise_iid   = p_enterprise_id
      AND C.LAST_ANALYSIS_DATE BETWEEN start_date AND end_date
         AND ((p_in_out_patient IS NOT NULL AND C.IN_OUT_PATIENT = p_in_out_patient)
    OR C.IN_OUT_PATIENT is NULL))t);
    
   
  END IF;
  IF (total_analyzed_claim_count IS NULL) THEN
    total_analyzed_claim_count   := 0;
  END IF;
  IF (total_edit_claim_count IS NULL) THEN
    total_edit_claim_count   := 0;
  END IF;
END USP_CLAIM_EDIT_SUMMARY_REPORT;
/
--End of Stored procedure for Claim Edit Summary Report



--Stored procedure for Flag Edit Summary Report
create or replace PROCEDURE USP_FLAG_EDIT_SUMMARY_REPORT
    (
      p_context       IN NUMBER,
      start_date      IN DATE,
      end_date        IN DATE,
      P_TOP_OF        IN NUMBER,
      p_flag_status   IN VARCHAR2,
      p_in_out_patient IN VARCHAR2,
    freya_list_eid1 IN VARCHAR2,
    freya_list_eid2 IN VARCHAR2,
      p_enterprise_id IN NUMBER,
      flag_edit_cursor OUT SYS_REFCURSOR,
      p_unique_id IN VARCHAR2
  )
    AS
  BEGIN
  dbms_application_info.set_client_info(p_unique_id);
  OPEN flag_edit_cursor FOR
select t.edit_mnemonic, t.Description, t.count from
(SELECT  edit_mnemonic, count(edit_mnemonic) count, v2.description  Description FROM claim_line_edit cle 
JOIN claim_line cl ON (cle.claim_line_iid = cl.claim_line_iid) JOIN claim c ON (cl.claim_iid = c.claim_iid)
LEFT OUTER JOIN v_freya_list_data_2 v2 on (upper(cle.edit_mnemonic) =upper(v2.first_begin_value) and ((p_in_out_patient is null and V2.freya_list_eid = freya_list_eid1) or (p_in_out_patient is not null and V2.freya_list_eid = freya_list_eid2)))
where (cle.pattern_eid is null or cle.pattern_eid ='Clinical') and c.IS_MODIFIED = 'N' AND c.claim_status = 'A' AND c.context = p_context AND c.enterprise_iid = p_enterprise_id
AND c.last_analysis_date BETWEEN start_date AND end_date
AND ((p_in_out_patient IS NOT NULL AND in_out_patient = p_in_out_patient) OR in_out_patient IS NULL)
AND ((p_flag_status <>'A' AND cle.action =p_flag_status) OR p_flag_status ='A') 
group by edit_mnemonic, v2.description
UNION     
SELECT  edit_mnemonic, count(edit_mnemonic) count, v2.description Description  FROM claim_edit ce
JOIN claim c ON (ce.claim_iid = c.claim_iid)
LEFT OUTER JOIN v_freya_list_data_2 v2 on (upper(ce.edit_mnemonic) = upper(v2.first_begin_value) and ((p_in_out_patient is null and V2.freya_list_eid = freya_list_eid1) or (p_in_out_patient is not null and V2.freya_list_eid = freya_list_eid2)))
where (ce.pattern_eid is null or ce.pattern_eid ='Clinical') and c.IS_MODIFIED = 'N' AND c.claim_status = 'A' AND c.context = p_context  AND c.enterprise_iid = p_enterprise_id 
AND c.last_analysis_date BETWEEN start_date AND end_date 
AND ((p_in_out_patient IS NOT NULL AND in_out_patient = p_in_out_patient) OR in_out_patient IS NULL)
AND ((p_flag_status <>'A' AND ce.action =p_flag_status) OR p_flag_status ='A') 
group by edit_mnemonic,v2.description
Union
SELECT  edit_mnemonic, count(edit_mnemonic) count, '[ Pattern '|| p.eid ||' ] ' || p.name  Description FROM claim_line_edit cle 
JOIN claim_line cl ON (cle.claim_line_iid = cl.claim_line_iid) JOIN claim c ON (cl.claim_iid = c.claim_iid)
LEFT OUTER JOIN (select eid,name from pattern where iid in (select  max(iid)  from pattern group by eid)) p on (cle.pattern_eid =p.eid)
where (cle.pattern_eid is not null and cle.pattern_eid <>'Clinical') and c.IS_MODIFIED = 'N' AND c.claim_status = 'A' AND c.context = p_context AND c.enterprise_iid = p_enterprise_id  
AND c.last_analysis_date BETWEEN start_date AND end_date 
AND ((p_in_out_patient IS NOT NULL AND in_out_patient = p_in_out_patient) OR in_out_patient IS NULL)
AND ((p_flag_status <>'A' AND cle.action =p_flag_status) OR p_flag_status ='A') 
group by edit_mnemonic, p.name,p.eid
UNION 
SELECT  edit_mnemonic, count(edit_mnemonic) count, '[ Pattern '|| p.eid ||' ] ' || p.name Description FROM claim_edit ce
JOIN claim c ON (ce.claim_iid = c.claim_iid)
LEFT OUTER JOIN (select eid,name from pattern where iid in ( select  max(iid)  from pattern group by eid)) p on (ce.pattern_eid =p.eid)
where (ce.pattern_eid is not null and ce.pattern_eid <>'Clinical') and c.IS_MODIFIED = 'N' AND c.claim_status = 'A' AND c.context = p_context AND c.enterprise_iid = p_enterprise_id  
AND c.last_analysis_date BETWEEN start_date AND end_date 
AND ((p_in_out_patient IS NOT NULL AND in_out_patient = p_in_out_patient) OR in_out_patient IS NULL)
AND ((p_flag_status <>'A' AND ce.action =p_flag_status) OR p_flag_status ='A') 
group by edit_mnemonic,p.name,p.eid
order by count desc
) t
where rownum < = P_TOP_OF;
END USP_FLAG_EDIT_SUMMARY_REPORT;
/

--End of Stored procedure for Flag Edit Summary Report




--Stored procedure for Flag Status Summary Report
 
create or replace PROCEDURE USP_FLAG_STATUS_SUM_REPORT
    (
      p_context       IN NUMBER,
      start_date      IN DATE,
      end_date        IN DATE,
      p_in_out_patient IN VARCHAR2,
      p_enterprise_id IN NUMBER,
      p_product_info IN VARCHAR2,
      claim_status_cursor OUT SYS_REFCURSOR,
      p_unique_id IN VARCHAR2
   )
    AS
   BEGIN
   dbms_application_info.set_client_info(p_unique_id);
   IF p_product_info = 'ICES' THEN 
   OPEN claim_status_cursor FOR
select t.Flag_status Flag_Status, sum(t.count) count, sum(t.submitted_charge) submitted_charge, max(ordering_filter) ordering_filter_max from 
((SELECT  'Deny' Flag_status, Count(distinct(cl.claim_iid)) count, SUM(charged_amount) 
submitted_charge, 1 as ordering_filter  FROM claim_line cl,claim c
     WHERE cl.claim_iid IN 
        (SELECT DISTINCT(ce.claim_iid) 
         FROM claim_edit ce
         WHERE ce.action = 'D') 
         and  c.IS_MODIFIED='N' 
          and  cl.claim_iid = c.claim_iid 
         AND c.ANALYSIS_STATUS <> 'NN' 
         AND c.claim_status = 'A' 
         AND c.context =p_context 
        AND c.enterprise_iid =p_enterprise_id
        AND c.last_analysis_date BETWEEN start_date AND end_date 
        AND (( p_in_out_patient IS NOT NULL 
        AND c.in_out_patient = p_in_out_patient ) 
       OR c.in_out_patient IS NULL )
        
Union All
Select 'Deny' Flag_status, COUNT(claim_line_iid) count, SUM(charged_amount) 
submitted_charge, 1 as ordering_filter FROM claim_line cl, claim c
    WHERE cl.claim_line_iid IN  
       (SELECT DISTINCT(cle.claim_line_iid)
        FROM claim_line_edit cle
        where  cle.action = 'D')
        and  cl.claim_iid = c.claim_iid
        and c.IS_MODIFIED='N' 
        AND c.ANALYSIS_STATUS <> 'NN'
        AND c.claim_status = 'A'
        AND c.context =p_context  
        AND c.enterprise_iid =p_enterprise_id
        AND c.last_analysis_date BETWEEN start_date AND end_date 
        AND (( p_in_out_patient IS NOT NULL 
        AND c.in_out_patient = p_in_out_patient ) 
        OR c.in_out_patient IS NULL)        
        and cl.claim_iid not in (select distinct(claim_iid) from claim_edit)
Union All

SELECT  'Review' Flag_status, Count(distinct(cl.claim_iid)) count, SUM(charged_amount) 
submitted_charge, 2 as ordering_filter  FROM claim_line cl, claim c
     WHERE cl.claim_iid IN 
        (SELECT DISTINCT(ce.claim_iid) 
         FROM claim_edit ce
         WHERE action = 'R' 
         AND claim_iid not in(select distinct(claim_iid) from claim_edit where action = 'D' ) )        
         and  c.IS_MODIFIED='N' 
         AND c.ANALYSIS_STATUS <> 'NN' 
         and  cl.claim_iid = c.claim_iid
         AND c.claim_status = 'A' 
         AND c.context =p_context  
        AND c.enterprise_iid =p_enterprise_id
        AND c.last_analysis_date BETWEEN start_date AND end_date 
        AND (( p_in_out_patient IS NOT NULL 
        AND c.in_out_patient = p_in_out_patient ) 
      OR c.in_out_patient IS NULL  )
        
Union All

Select 'Review' Flag_status, COUNT(claim_line_iid) count, SUM(charged_amount) 
submitted_charge, 2 as ordering_filter FROM claim_line cl, claim c
    WHERE cl.claim_line_iid IN  
       (SELECT DISTINCT(cle.claim_line_iid)
        FROM claim_line_edit cle WHERE action = 'R'
        AND claim_line_iid not in (select distinct(claim_line_iid) from claim_line_edit where action = 'D' ) )
        and  cl.claim_iid = c.claim_iid
        AND  c.IS_MODIFIED='N' 
        AND c.ANALYSIS_STATUS <> 'NN'
        AND c.claim_status = 'A'
        AND c.context =p_context  
        AND c.enterprise_iid =p_enterprise_id
        AND c.last_analysis_date BETWEEN start_date AND end_date 
        AND (( p_in_out_patient IS NOT NULL 
        AND c.in_out_patient = p_in_out_patient ) 
        OR c.in_out_patient IS NULL)        
        and cl.claim_iid not in (select distinct(claim_iid) from claim_edit)
Union All  

SELECT  'Profile' Flag_status, Count(distinct(cl.claim_iid)) count, SUM(charged_amount) 
submitted_charge, 3 as ordering_filter FROM claim_line cl, claim c
     WHERE cl.claim_iid IN 
        (SELECT DISTINCT(ce.claim_iid) 
         FROM claim_edit ce
         WHERE action = 'P' 
         AND claim_iid not in (select distinct(claim_iid) from claim_edit where action = 'D' 
         OR action = 'R' ))       
           and  cl.claim_iid = c.claim_iid
         and  c.IS_MODIFIED='N' 
         AND c.ANALYSIS_STATUS <> 'NN' 
         AND c.claim_status = 'A' 
         AND c.context =p_context  
        AND c.enterprise_iid =p_enterprise_id
        AND c.last_analysis_date BETWEEN start_date AND end_date 
        AND (( p_in_out_patient IS NOT NULL 
        AND c.in_out_patient = p_in_out_patient ) 
       OR c.in_out_patient IS NULL )
        
Union All

Select 'Profile' Flag_status, COUNT(claim_line_iid) count, SUM(charged_amount) 
submitted_charge, 3 as ordering_filter FROM claim_line cl, claim c
    WHERE cl.claim_line_iid IN  
       (SELECT DISTINCT(claim_line_iid)
        FROM claim_line_edit cle WHERE action = 'P'
        AND claim_line_iid not in (select distinct(claim_line_iid) from claim_line_edit where action = 'D' OR action = 'R') )
        and  cl.claim_iid = c.claim_iid
        AND  c.IS_MODIFIED='N' 
        AND c.ANALYSIS_STATUS <> 'NN'
        AND c.claim_status = 'A'
        AND c.context =p_context 
        AND c.enterprise_iid =p_enterprise_id
        AND c.last_analysis_date BETWEEN start_date AND end_date
        AND (( p_in_out_patient IS NOT NULL 
        AND c.in_out_patient = p_in_out_patient ) 
        OR c.in_out_patient IS NULL)        
        and cl.claim_iid not in (select distinct(claim_iid) from claim_edit)
Union All 
SELECT 'Clean' Flag_status, COUNT(claim_line_iid) count, SUM(charged_amount) 
submitted_charge, 4 as ordering_filter  FROM claim_line cl,claim c
      WHERE claim_line_iid not IN 
        (select  DISTINCT(claim_line_iid) 
         FROM claim_line_edit )
         and cl.claim_iid not in (SELECT DISTINCT(claim_iid) 
         FROM claim_edit  )         
         and cl.claim_iid = c.claim_iid and c.IS_MODIFIED='N'
         AND c.ANALYSIS_STATUS <> 'NN' 
         AND c.claim_status = 'A'
         AND c.context =p_context 
         AND c.enterprise_iid =p_enterprise_id 
         AND c.last_analysis_date BETWEEN start_date AND end_date 
         AND (( p_in_out_patient IS NOT NULL 
         AND c.in_out_patient = p_in_out_patient ) 
         OR c.in_out_patient IS NULL)
         )t
         )group by t.flag_status order by ordering_filter_max;
         END IF;
         IF p_product_info = 'CM' THEN
         OPEN claim_status_cursor FOR
select t.Flag_status Flag_Status, sum(t.count) count, sum(t.submitted_charge) submitted_charge, max(ordering_filter) ordering_filter_max from 
((
SELECT  'Review' Flag_status, Count(distinct(cl.claim_iid)) count, SUM(charged_amount) 
submitted_charge, 2 as ordering_filter  FROM claim_line cl, claim c
     WHERE cl.claim_iid IN 
        (SELECT DISTINCT(ce.claim_iid) 
         FROM claim_edit ce
         WHERE action = 'R' 
         AND claim_iid not in(select distinct(claim_iid) from claim_edit where action = 'D' ) )        
         and  c.IS_MODIFIED='N' 
         AND c.ANALYSIS_STATUS <> 'NN' 
         and  cl.claim_iid = c.claim_iid
         AND c.claim_status = 'A' 
         AND c.context =p_context  
        AND c.enterprise_iid =p_enterprise_id
        AND c.last_analysis_date BETWEEN start_date AND end_date 
        AND (( p_in_out_patient IS NOT NULL 
        AND c.in_out_patient = p_in_out_patient ) 
      OR c.in_out_patient IS NULL  )
        
Union All

Select 'Review' Flag_status, COUNT(claim_line_iid) count, SUM(charged_amount) 
submitted_charge, 2 as ordering_filter FROM claim_line cl, claim c
    WHERE cl.claim_line_iid IN  
       (SELECT DISTINCT(cle.claim_line_iid)
        FROM claim_line_edit cle WHERE action = 'R'
        AND claim_line_iid not in (select distinct(claim_line_iid) from claim_line_edit where action = 'D' ) )
        and  cl.claim_iid = c.claim_iid
        AND  c.IS_MODIFIED='N' 
        AND c.ANALYSIS_STATUS <> 'NN'
        AND c.claim_status = 'A'
        AND c.context =p_context  
        AND c.enterprise_iid =p_enterprise_id
        AND c.last_analysis_date BETWEEN start_date AND end_date 
        AND (( p_in_out_patient IS NOT NULL 
        AND c.in_out_patient = p_in_out_patient ) 
        OR c.in_out_patient IS NULL)        
        and cl.claim_iid not in (select distinct(claim_iid) from claim_edit)
Union All  

SELECT  'Profile' Flag_status, Count(distinct(cl.claim_iid)) count, SUM(charged_amount) 
submitted_charge, 3 as ordering_filter FROM claim_line cl, claim c
     WHERE cl.claim_iid IN 
        (SELECT DISTINCT(ce.claim_iid) 
         FROM claim_edit ce
         WHERE action = 'P' 
         AND claim_iid not in (select distinct(claim_iid) from claim_edit where action = 'D' 
         OR action = 'R' ))       
           and  cl.claim_iid = c.claim_iid
         and  c.IS_MODIFIED='N' 
         AND c.ANALYSIS_STATUS <> 'NN' 
         AND c.claim_status = 'A' 
         AND c.context =p_context  
        AND c.enterprise_iid =p_enterprise_id
        AND c.last_analysis_date BETWEEN start_date AND end_date 
        AND (( p_in_out_patient IS NOT NULL 
        AND c.in_out_patient = p_in_out_patient ) 
       OR c.in_out_patient IS NULL )
        
Union All

Select 'Profile' Flag_status, COUNT(claim_line_iid) count, SUM(charged_amount) 
submitted_charge, 3 as ordering_filter FROM claim_line cl, claim c
    WHERE cl.claim_line_iid IN  
       (SELECT DISTINCT(claim_line_iid)
        FROM claim_line_edit cle WHERE action = 'P'
        AND claim_line_iid not in (select distinct(claim_line_iid) from claim_line_edit where action = 'D' OR action = 'R') )
        and  cl.claim_iid = c.claim_iid
        AND  c.IS_MODIFIED='N' 
        AND c.ANALYSIS_STATUS <> 'NN'
        AND c.claim_status = 'A'
        AND c.context =p_context 
        AND c.enterprise_iid =p_enterprise_id
        AND c.last_analysis_date BETWEEN start_date AND end_date
        AND (( p_in_out_patient IS NOT NULL 
        AND c.in_out_patient = p_in_out_patient ) 
        OR c.in_out_patient IS NULL)        
        and cl.claim_iid not in (select distinct(claim_iid) from claim_edit)
Union All 
SELECT 'Clean' Flag_status, COUNT(claim_line_iid) count, SUM(charged_amount) 
submitted_charge, 4 as ordering_filter  FROM claim_line cl,claim c
      WHERE claim_line_iid not IN 
        (select  DISTINCT(claim_line_iid) 
         FROM claim_line_edit )
         and cl.claim_iid not in (SELECT DISTINCT(claim_iid) 
         FROM claim_edit  )         
         and cl.claim_iid = c.claim_iid and c.IS_MODIFIED='N'
         AND c.ANALYSIS_STATUS <> 'NN' 
         AND c.claim_status = 'A'
         AND c.context =p_context 
         AND c.enterprise_iid =p_enterprise_id 
         AND c.last_analysis_date BETWEEN start_date AND end_date 
         AND (( p_in_out_patient IS NOT NULL 
         AND c.in_out_patient = p_in_out_patient ) 
         OR c.in_out_patient IS NULL)
         )t
         )group by t.flag_status order by ordering_filter_max;
         END IF;
END USP_FLAG_STATUS_SUM_REPORT;
/
 
 
--End of Stored procedure for Flag Status Summary Report

--Start of Custom Report Tables Creation


 
 
--End of Stored procedure for Flag Status Summary Report

--Start of Custom Report Tables Creation



BEGIN
 IF ICP_P.DB_TOOLS.OBJECT_EXISTS('S_CUSTOM_REPORT_ID','SEQUENCE') = 0 THEN
EXECUTE IMMEDIATE 'CREATE SEQUENCE
ICP_P.S_CUSTOM_REPORT_ID
START WITH 1
INCREMENT BY 1
MINVALUE 1
MAXVALUE 9999999999999999999999999999
CACHE 1000
NOORDER
NOCYCLE';
  END IF;
END;
/

BEGIN
 IF ICP_P.DB_TOOLS.OBJECT_EXISTS('S_CUSTOM_REPORT_COLUMN_ID','SEQUENCE') = 0 THEN
EXECUTE IMMEDIATE 'CREATE SEQUENCE
ICP_P.S_CUSTOM_REPORT_COLUMN_ID
START WITH 1
INCREMENT BY 1
MINVALUE 1
MAXVALUE 9999999999999999999999999999
CACHE 1000
NOORDER
NOCYCLE';
  END IF;
END;
/

BEGIN
 IF ICP_P.DB_TOOLS.OBJECT_EXISTS('S_CUSTOM_REPORT_FILTER_ID','SEQUENCE') = 0 THEN
EXECUTE IMMEDIATE 'CREATE SEQUENCE
ICP_P.S_CUSTOM_REPORT_FILTER_ID
START WITH 1
INCREMENT BY 1
MINVALUE 1
MAXVALUE 9999999999999999999999999999
CACHE 1000
NOORDER
NOCYCLE';
  END IF;
END;
/

BEGIN
   IF ICP_P.DB_TOOLS.OBJECT_EXISTS('CUSTOM_REPORT','TABLE') = 0 THEN
      EXECUTE IMMEDIATE 'CREATE TABLE ICP_P.CUSTOM_REPORT(
    IID                             NUMBER(38,0)    NOT NULL,
    ENTERPRISE_IID                  NUMBER(38,0)    NOT NULL,
    REPORT_NAME                     VARCHAR2(50)    NOT NULL,
    CONSTRAINT CUSTOM_REPORT_PK PRIMARY KEY (IID)
)';
  END IF;
END;
/


CREATE OR REPLACE TRIGGER ICP_P.T_CUSTOM_REPORT BEFORE INSERT ON CUSTOM_REPORT FOR EACH ROW BEGIN IF :NEW.IID IS NULL THEN SELECT S_CUSTOM_REPORT_ID.NEXTVAL INTO :NEW.IID FROM Dual;  END IF; END;
/


BEGIN
   IF ICP_P.DB_TOOLS.OBJECT_EXISTS('CUSTOM_REPORT_COLUMN','TABLE') = 0 THEN
      EXECUTE IMMEDIATE 'CREATE TABLE ICP_P.CUSTOM_REPORT_COLUMN(
    IID                             NUMBER(38,0)    NOT NULL,
    CUSTOM_REPORT_IID               NUMBER(38,0)    NOT NULL,
    COLUMN_NAME                     VARCHAR2(50) ,
    CONSTRAINT CUSTOM_REPORT_COLUMN_PK PRIMARY KEY (IID)
    
) ';
  END IF;
END;
/


CREATE OR REPLACE TRIGGER ICP_P.T_CUSTOM_REPORT_COLUMN BEFORE INSERT ON CUSTOM_REPORT_COLUMN FOR EACH ROW BEGIN IF :NEW.IID IS NULL THEN SELECT S_CUSTOM_REPORT_COLUMN_ID.NEXTVAL INTO :NEW.IID FROM Dual;  END IF; END;
/


BEGIN
   IF ICP_P.DB_TOOLS.OBJECT_EXISTS('CUSTOM_REPORT_FILTER','TABLE') = 0 THEN
      EXECUTE IMMEDIATE 'CREATE TABLE ICP_P.CUSTOM_REPORT_FILTER(
    IID                             NUMBER(38,0)    NOT NULL,
    CUSTOM_REPORT_IID               NUMBER(38,0)    NOT NULL,
    FILTER_NAME                     VARCHAR2(50),
    FILTER_VALUE                    VARCHAR2(100),
    CONSTRAINT CUSTOM_REPORT_FILTER_PK PRIMARY KEY (IID)
   
) ';
  END IF;
END;
/


CREATE OR REPLACE TRIGGER ICP_P.T_CUSTOM_REPORT_FILTER BEFORE INSERT ON CUSTOM_REPORT_FILTER FOR EACH ROW BEGIN IF :NEW.IID IS NULL THEN SELECT S_CUSTOM_REPORT_FILTER_ID.NEXTVAL INTO :NEW.IID FROM Dual;  END IF; END;
/





--Start of Summary Report Tables Creation


BEGIN
 IF ICP_P.DB_TOOLS.OBJECT_EXISTS('S_SUMMARY_REPORT_ID','SEQUENCE') = 0 THEN
EXECUTE IMMEDIATE 'CREATE SEQUENCE
ICP_P.S_SUMMARY_REPORT_ID
START WITH 1
INCREMENT BY 1
MINVALUE 1
MAXVALUE 9999999999999999999999999999
CACHE 1000
NOORDER
NOCYCLE';
  END IF;
END;
/

BEGIN
 IF ICP_P.DB_TOOLS.OBJECT_EXISTS('S_SUMMARY_REPORT_FILTER_ID','SEQUENCE') = 0 THEN
EXECUTE IMMEDIATE 'CREATE SEQUENCE
ICP_P.S_SUMMARY_REPORT_FILTER_ID
START WITH 1
INCREMENT BY 1
MINVALUE 1
MAXVALUE 9999999999999999999999999999
CACHE 1000
NOORDER
NOCYCLE';
  END IF;
END;
/



BEGIN
   IF ICP_P.DB_TOOLS.OBJECT_EXISTS('SUMMARY_REPORT','TABLE') = 0 THEN
      EXECUTE IMMEDIATE 'CREATE TABLE ICP_P.SUMMARY_REPORT(
    IID                             NUMBER(38,0)    NOT NULL,
    ENTERPRISE_IID                  NUMBER(38,0)    NOT NULL,
    REPORT_NAME                     VARCHAR2(50)    NOT NULL,
    CONSTRAINT SUMMARY_REPORT_PK PRIMARY KEY (IID)
    
) ';
  END IF;
END;
/

 
CREATE OR REPLACE TRIGGER ICP_P.T_SUMMARY_REPORT BEFORE INSERT ON SUMMARY_REPORT FOR EACH ROW BEGIN IF :NEW.IID IS NULL THEN SELECT S_SUMMARY_REPORT_ID.NEXTVAL INTO :NEW.IID FROM Dual;  END IF; END;
/


BEGIN
   IF ICP_P.DB_TOOLS.OBJECT_EXISTS('SUMMARY_REPORT_FILTER','TABLE') = 0 THEN
      EXECUTE IMMEDIATE 'CREATE TABLE ICP_P.SUMMARY_REPORT_FILTER(
    IID                             NUMBER(38,0)    NOT NULL,
    SUMMARY_REPORT_IID               NUMBER(38,0)    NOT NULL,
    FILTER_NAME                     VARCHAR2(50),
    FILTER_VALUE                    VARCHAR2(100),
    CONSTRAINT SUMMARY_REPORT_FILTER_PK PRIMARY KEY (IID)
    
) ';
  END IF;
END;
/


CREATE OR REPLACE TRIGGER ICP_P.T_SUMMARY_REPORT_FILTER BEFORE INSERT ON SUMMARY_REPORT_FILTER FOR EACH ROW BEGIN IF :NEW.IID IS NULL THEN SELECT S_SUMMARY_REPORT_FILTER_ID.NEXTVAL INTO :NEW.IID FROM Dual;  END IF; END;
/


--Start of Stored procedure for Summary Report Names

declare 
report_id  NUMBER (10);
any_rows_found NUMBER (10);
BEGIN
report_id := 1;
FOR rec IN (select enterprise_iid  from ICP_P.enterprise where enterprise_iid not in (select parent_id from ICP_P.enterprise where parent_id is not null))
      LOOP
      
      select count(*) into any_rows_found from ICP_P.SUMMARY_REPORT where REPORT_NAME = 'Claim Edit Summary' and enterprise_iid = rec.enterprise_iid;
      IF (any_rows_found =0) THEN      
         INSERT into ICP_P.SUMMARY_REPORT values(NULL,rec.enterprise_iid,'Claim Edit Summary');
         report_id :=S_SUMMARY_REPORT_ID.currval;
         INSERT into ICP_P.SUMMARY_REPORT_FILTER values(NULL,report_id,'Group by','Count');
         INSERT into ICP_P.SUMMARY_REPORT_FILTER values(NULL,report_id,'Environment','Live');
         INSERT into ICP_P.SUMMARY_REPORT_FILTER values(NULL,report_id,'Time Period','Today');
         INSERT into ICP_P.SUMMARY_REPORT_FILTER values(NULL,report_id,'Type of Claim','Inpatient');
      END IF;
        
      select count(*) into any_rows_found from ICP_P.SUMMARY_REPORT where REPORT_NAME = 'Flag Edit Summary' and enterprise_iid = rec.enterprise_iid;
      IF ( any_rows_found=0) THEN
         INSERT into ICP_P.SUMMARY_REPORT values(NULL,rec.enterprise_iid,'Flag Edit Summary');
         report_id :=S_SUMMARY_REPORT_ID.currval;
         INSERT into ICP_P.SUMMARY_REPORT_FILTER values(NULL,report_id,'Flags','Top 5');
         INSERT into ICP_P.SUMMARY_REPORT_FILTER values(NULL,report_id,'Flag Status','Review');
         INSERT into ICP_P.SUMMARY_REPORT_FILTER values(NULL,report_id,'Environment','Live');
         INSERT into ICP_P.SUMMARY_REPORT_FILTER values(NULL,report_id,'Time Period','Today');
         INSERT into ICP_P.SUMMARY_REPORT_FILTER values(NULL,report_id,'Type of Claim','Inpatient');
        
      END IF;
        
      select count(*) into any_rows_found from ICP_P.SUMMARY_REPORT where REPORT_NAME = 'Flag Status Summary' and enterprise_iid = rec.enterprise_iid;
      IF ( any_rows_found=0) THEN
         INSERT into ICP_P.SUMMARY_REPORT values(NULL,rec.enterprise_iid,'Flag Status Summary');
         report_id :=S_SUMMARY_REPORT_ID.currval;
         INSERT into ICP_P.SUMMARY_REPORT_FILTER values(NULL,report_id,'Environment','Live');
         INSERT into ICP_P.SUMMARY_REPORT_FILTER values(NULL,report_id,'Time Period','Today');
         INSERT into ICP_P.SUMMARY_REPORT_FILTER values(NULL,report_id,'Type of Claim','Inpatient');
      END IF;
         
         COMMIT;
   END LOOP;
END;
/


--End of Stored procedure for Summary Report Names



    --Stored Procedure USP_SREPORT_NAME_DYNAMIC for adding summary reports with new enterprise addition
create or replace PROCEDURE ICP_P.USP_SREPORT_NAME_DYNAMIC
      (
      p_enterprise_iid       IN NUMBER
      )
  AS
    report_id        NUMBER := 1;
   
  BEGIN       
         INSERT into SUMMARY_REPORT values(NULL,p_enterprise_iid,'Claim Edit Summary');
        report_id :=S_SUMMARY_REPORT_ID.currval;
         INSERT into SUMMARY_REPORT_FILTER values(NULL,report_id,'Group by','Count');
         INSERT into SUMMARY_REPORT_FILTER values(NULL,report_id,'Environment','Live');
         INSERT into SUMMARY_REPORT_FILTER values(NULL,report_id,'Time Period','Today');
         INSERT into SUMMARY_REPORT_FILTER values(NULL,report_id,'Type of Claim','Inpatient');

         
         INSERT into SUMMARY_REPORT values(NULL,p_enterprise_iid,'Flag Edit Summary');
         report_id :=S_SUMMARY_REPORT_ID.currval;
         INSERT into SUMMARY_REPORT_FILTER values(NULL,report_id,'Flags','Top 5');
         INSERT into SUMMARY_REPORT_FILTER values(NULL,report_id,'Flag Status','Review');
         INSERT into SUMMARY_REPORT_FILTER values(NULL,report_id,'Environment','Live');
         INSERT into SUMMARY_REPORT_FILTER values(NULL,report_id,'Time Period','Today');
         INSERT into SUMMARY_REPORT_FILTER values(NULL,report_id,'Type of Claim','Inpatient');

         
         INSERT into SUMMARY_REPORT values(NULL,p_enterprise_iid,'Flag Status Summary');
         report_id :=S_SUMMARY_REPORT_ID.currval;
         INSERT into SUMMARY_REPORT_FILTER values(NULL,report_id,'Environment','Live');
         INSERT into SUMMARY_REPORT_FILTER values(NULL,report_id,'Time Period','Today');
         INSERT into SUMMARY_REPORT_FILTER values(NULL,report_id,'Type of Claim','Inpatient');


END USP_SREPORT_NAME_DYNAMIC;
/
--End of Stored Procedure USP_SREPORT_NAME_DYNAMIC for adding summary reports with new enterprise addition

--Trigger T_ENTERPRISE_FOR_REPORT for adding summary reports with new enterprise addition
CREATE OR REPLACE TRIGGER ICP_P.T_ENTERPRISE_FOR_REPORT BEFORE
  INSERT ON ENTERPRISE FOR EACH ROW DECLARE count_parent_id NUMBER := 2;
  BEGIN
    SELECT COUNT(parent_id)
    INTO count_parent_id
    FROM enterprise
    WHERE parent_id    = :NEW.PARENT_ID;
    IF count_parent_id = 0 THEN
      UPDATE SUMMARY_REPORT
      SET ENTERPRISE_IID   = :NEW.ENTERPRISE_IID
      WHERE ENTERPRISE_IID = :NEW.PARENT_ID;
      UPDATE CUSTOM_REPORT
      SET ENTERPRISE_IID   = :NEW.ENTERPRISE_IID
      WHERE ENTERPRISE_IID = :NEW.PARENT_ID;
    ELSE
      BEGIN
        USP_SREPORT_NAME_DYNAMIC( P_ENTERPRISE_IID => :NEW.ENTERPRISE_IID );
      END;
    END IF;
  END;
  /
--End of Trigger T_ENTERPRISE_FOR_REPORT for adding summary reports with new enterprise addition

COMMIT;
