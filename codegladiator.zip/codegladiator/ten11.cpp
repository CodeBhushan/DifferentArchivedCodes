#include<stdio.h>
#include<string.h>
#include<iostream>
using namespace std;

void swap(int &i, int &j){
	int temp= i;
	i=j;
	j =temp;
}

struct minHeap{
	unsigned heapSize;
		int * nodes;
};




void rearrangeMinHeap(struct minHeap* heap, int index){
	int smallestIndex = index;
	int rightIndex = 2 * index + 2;
    int leftIndex = 2 * index + 1;
    
  if (rightIndex < heap->heapSize &&      heap->nodes[rightIndex] < heap->nodes[smallestIndex]){
      smallestIndex = rightIndex;
      }
    if (leftIndex < heap->heapSize &&        heap->nodes[leftIndex] < heap->nodes[smallestIndex]){
      smallestIndex = leftIndex;
      }
 
   
 
    if (smallestIndex != index)
    {
        swap(heap->nodes[smallestIndex], heap->nodes[index]);
        rearrangeMinHeap(heap, smallestIndex);
    }
}

int extractMinimumNo(struct minHeap* heap){
	int ans = heap->nodes[0];

	heap->nodes[0]=heap->nodes[heap->heapSize-1];
	heap->heapSize=heap->heapSize-1;
	rearrangeMinHeap(heap,0);
	return ans;
	
}


int * getJoinedPipes(int input1[],int input2){
	
	

	int * ans = new int[input2-1];int k =0;	
	
	struct minHeap* heap  = new minHeap;
	
	heap->nodes= new int[input2];



	heap->nodes=input1;
	heap->heapSize= input2;
	
	int n = heap->heapSize-1;
	
	for(int i =(n-1)/2;i>=0;i--){
	rearrangeMinHeap(heap,i);	
	}
	
	while(true){
		if(heap->heapSize==1)break;
		int min= extractMinimumNo(heap);
		int min2=extractMinimumNo(heap);
		ans[k++]=min+min2;

    int i = heap->heapSize;
	heap->heapSize= heap->heapSize+1;
	while(i && (ans[k-1]< heap->nodes[(i-1)/2])){
		heap->nodes[i]=heap->nodes[(i-1)/2];
		i= (i-1)/2;
	}
	heap->nodes[i]=ans[k-1];


	}
	
	return ans;
	
}

int main() {
int arr[]={4,3,2,6};
int * ans = getJoinedPipes(arr,4);
for(int i =0;i<3;i++){
	cout<<ans[i]<<endl;
}
	
	return 0;
}

