
#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<cstring>



using namespace std;


bool isDigit (char c) {
    if ((c>='0') && (c<='9')) return true;
    return false;
}

int split(char * str, bool** grid, int row, int col, int input3){
    int ans =0;int index=0;
    int length = strlen(str);
    int startdigitindex=2;
    int enddigitindex=2;
    int lastdigitIndex=2;
    bool x=true;int x1,y1;
    int lastCharIndex=1;
    for(int i =2;i<length-2;i++){
        if(isDigit(str[i])){
            startdigitindex=i;
            while(isDigit(str[++i]));
            enddigitindex=i-1;
       
            char* substring1 = new char[enddigitindex-startdigitindex+1];
            for(int k =0;k<enddigitindex-startdigitindex+1;k++){
   
                substring1[k]=str[k+startdigitindex];
                
            }

            int number = atoi(substring1);
            if(x){
               if(number<1 || number >row)return -1;
                x1=number;
                x=!x;
                }else{
               if(number<1||number>col)return -1;
                y1=number;
                x=!x;
cout<<x1<<y1<<endl;

ans++;
if(ans>input3)return -1;
                grid[x1-1][y1-1]=true;
//arr[index].x=x1-1; arr[index].y=y1-1;index++;
            }
            
        }
        
        
    }
    
    if(ans!=input3)return -1;
    return ans;
}

bool col(int i, int j, int k, int l, int m , int n){
    
    int val = (l - j) * (m - k) -
    (k - i) * (n - l);
    
    if(val==0)return true; else return false;
}
int dist(int i, int j, int k, int l){
    return (j-l)*(j-l)+(i-k)*(i-k);
}





bool valid1(int input1, int input2, int i, int j, int lastx, int lasty, int ans_)
    {
        int x =lastx+(lastx-i)/(ans_-1) ;
        int y = lasty+(lasty-j)/(ans_-1) ;
        if(x>=0 && x<input1 && y>=0 && y<input2)return false;else return true;
    }

    bool valid(int input1,int input2, int i, int j, int k, int l)
    {
        int x =2*i-k;
        int y = 2*j-l;
        if(x>=0 && x<input1 && y>=0 && y<input2)return false;else return true;
    }

int maxTreeDestroyed(int input1, int input2, int input3, char * input4){
    if(input3<3 || input3>input1*input2)
    return -1;
    bool ** grid  = new bool*[input1];
    for  ( int i =0;i<input1;i++){
        grid[i]= new bool[input2];
        
    }
    for(int i =0;i<input1;i++)
    for(int j =0;j<input2;j++){
        grid[i][j]=false;
    }
    
    int reply= split(input4,grid,input1,input2,input3);
    
    if(reply==-1 || reply> input3) return -1;
    
    int ans=2;
    
     for(int i =0;i<input1;i++)
            for(int j =0;j<input2;j++)if(grid[i][j])
            {
                for(int k =i;k<input1;k++)
                    for(int l=j;l<input2;l++)if(grid[k][l] && !(i==k && j==l))
                    {

                        int dis = dist(i,j,k,l);int ans_=2;
                        int lastx= k; int lasty=l;
                        for(int m =k;m<input1;m++)
                            for(int n=l;n<input2;n++)if(grid[m][n] && !(k==m && l==n))
                            {


                                if(col(i,j,k,l,m,n)){
                                    int distmp= dist(lastx,lasty,m,n);
                                    if(distmp==dis){
                                        ans_++;
                                        lastx=m;lasty=n;
                                    }
                                }
                            }
                        if(ans_>ans && valid(input1,input2,i,j,k,l) && valid1(input1,input2,i,j,lastx,lasty,ans_))
                            ans=ans_;


                    }


                for(int k =i;k<input1;k++)
                    for(int l=j;l>=0;l--)if(grid[k][l] && !(i==k && j==l))
                    {
                        int dis = dist(i,j,k,l);int ans_=2;
                        int lastx= k; int lasty=l;
                        for(int m =k;m<input1;m++)
                            for(int n=l;n>=0;n--)if(grid[m][n] && !(k==m && l==n))
                            {


                                if(col(i,j,k,l,m,n)){
                                    int distmp= dist(lastx,lasty,m,n);
                                    if(distmp==dis){
                                        ans_++;
                                        lastx=m;lasty=n;
                                    }
                                }
                            }
                        if(ans_>ans && valid(input1,input2,i,j,k,l) && valid1(input1,input2,i,j,lastx,lasty,ans_))
                            ans=ans_;

                    }
            }







    //write logic
    if(ans<3)return -1;else return ans;
    
}

int main(){
  string str="((2,1),(6,6),(4,2),(2,5),(2,6),(2,7),(3,4),(6,11),(6,2),(2,3),(6,3),(6,4),(6,5),(6,7))";
            char *cstr = new char[str.length() + 1];
strcpy(cstr, str.c_str());
            
    cout<<(  maxTreeDestroyed(61,71,14,cstr));
    return 0;
}