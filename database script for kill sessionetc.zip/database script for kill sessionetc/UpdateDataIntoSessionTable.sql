create or replace PROCEDURE USP_CLAIM_EDIT_SUMMARY_REPORT(
    p_context       IN NUMBER,
    start_date      IN DATE,
    end_date        IN DATE,
    group_by_filter IN VARCHAR2,
    p_enterprise_id IN NUMBER,
    p_in_out_patient IN VARCHAR2,
    p_unique_id IN VARCHAR2,
    total_analyzed_claim_count OUT NUMBER,
    total_edit_claim_count OUT NUMBER) AS
BEGIN
dbms_application_info.set_client_info(p_unique_id);
  IF group_by_filter = 'Count' THEN
    SELECT COUNT(*)
    INTO total_analyzed_claim_count
    FROM CLAIM
    WHERE IS_MODIFIED    = 'N'
    AND ANALYSIS_STATUS <> 'NN'
    AND claim_status     = 'A'
    AND context          = p_context
    AND enterprise_iid   = p_enterprise_id
    AND last_analysis_date BETWEEN start_date AND end_date
    AND ((p_in_out_patient IS NOT NULL AND in_out_patient = p_in_out_patient)
    OR in_out_patient is null);
    SELECT COUNT(*)
    INTO total_edit_claim_count
    FROM CLAIM
    WHERE (CLAIM_IID IN
      (SELECT DISTINCT(CLAIM_IID)
      FROM CLAIM_LINE
      WHERE CLAIM_LINE_IID IN
        (SELECT DISTINCT(CLAIM_LINE_IID) FROM claim_line_edit
        )
      )
    OR CLAIM_IID IN
      (SELECT DISTINCT(claim_iid) FROM CLAIM_EDIT
      ))
    AND IS_MODIFIED      = 'N'
    AND ANALYSIS_STATUS <> 'NN'
    AND claim_status     = 'A'
    AND context          = p_context
    AND enterprise_iid   = p_enterprise_id
    AND last_analysis_date BETWEEN start_date AND end_date
     AND ((p_in_out_patient IS NOT NULL AND in_out_patient = p_in_out_patient)
    OR in_out_patient is null);
  END IF;
  IF group_by_filter = 'Submitted Charge' THEN
    SELECT SUM(charged_amount)
    INTO total_analyzed_claim_count
    FROM CLAIM_LINE
    WHERE CLAIM_IID IN
      (SELECT CLAIM_IID
      FROM CLAIM
      WHERE IS_MODIFIED    = 'N'
      AND ANALYSIS_STATUS <> 'NN'
      AND claim_status     = 'A'
      AND context          = p_context
      AND enterprise_iid   = p_enterprise_id
      AND last_analysis_date BETWEEN start_date AND end_date
       AND ((p_in_out_patient IS NOT NULL AND in_out_patient = p_in_out_patient)
    OR in_out_patient is null)
      );
          
     select sum(charged_amount) into total_edit_claim_count from claim_line where claim_iid in
     ( SELECT DISTINCT(t.claim_iid)
       FROM
        (SELECT c.claim_iid
        FROM claim c
        JOIN claim_line cl
        ON (c.claim_iid = cl.claim_iid)
        JOIN claim_line_edit cle
        ON (cl.claim_line_iid = cle.claim_line_iid)
        WHERE C.IS_MODIFIED    = 'N'
      AND C.ANALYSIS_STATUS <> 'NN'
          AND C.claim_status     = 'A'
      AND C.context          = p_context
      AND C.enterprise_iid   = p_enterprise_id
      AND C.LAST_ANALYSIS_DATE BETWEEN start_date AND end_date
         AND ((p_in_out_patient IS NOT NULL AND C.IN_OUT_PATIENT = p_in_out_patient)
    OR C.IN_OUT_PATIENT is NULL)
        UNION 
        SELECT c.claim_iid
        FROM claim c
        JOIN claim_edit ce
        ON (c.claim_iid        = ce.claim_iid)
       WHERE C.IS_MODIFIED    = 'N'
      AND C.ANALYSIS_STATUS <> 'NN'
          AND C.claim_status     = 'A'
      AND C.context          = p_context
      AND C.enterprise_iid   = p_enterprise_id
      AND C.LAST_ANALYSIS_DATE BETWEEN start_date AND end_date
         AND ((p_in_out_patient IS NOT NULL AND C.IN_OUT_PATIENT = p_in_out_patient)
    OR C.IN_OUT_PATIENT is NULL))t);
    
   
  END IF;
  IF (total_analyzed_claim_count IS NULL) THEN
    total_analyzed_claim_count   := 0;
  END IF;
  IF (total_edit_claim_count IS NULL) THEN
    total_edit_claim_count   := 0;
  END IF;
END USP_CLAIM_EDIT_SUMMARY_REPORT;

--kill session

CREATE OR REPLACE
PROCEDURE usp_kill_session
  (
    p_uniqueClientId IN VARCHAR2
    --p_sid     IN VARCHAR2,
    --p_serial# IN VARCHAR2
  )
IS
 p_sid     VARCHAR2(100);
  p_serial# VARCHAR2(100);
  cursor_name pls_integer DEFAULT dbms_sql.open_cursor;
  ignore pls_integer;
 
BEGIN
  SELECT SID INTO p_sid FROM v$session WHERE client_info = p_uniqueClientId;
  SELECT SERIAL#  INTO p_serial#  FROM v$session  WHERE client_info = p_uniqueClientId;
  SELECT COUNT(*)
  INTO ignore
  FROM V$session
  WHERE username = USER
  AND sid        = p_sid
  AND serial#    = p_serial# ;
  IF ( ignore    = 1 ) THEN
    dbms_sql.parse(cursor_name, 'alter system kill session ''' ||p_sid||','||p_serial#||'''', dbms_sql.native);
    ignore := dbms_sql.execute(cursor_name);
  ELSE
    raise_application_error( -20001, 'You do not own session ''' || p_sid || ',' || p_serial# || '''' );
  END IF;
END;
