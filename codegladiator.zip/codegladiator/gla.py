

def getHeight(input1,input2):
    ans=0;
    if input2==0:
        return 0;
    for k in range(0,input2-1) :
        hk= input1[k].split('#');
        if float(hk[0])>=4 and float(hk[0])<=7 and float(hk[1])>=0 and float(hk[1])<=11 :
            continue;
        else:
            return -1;

    for i in range(0,input2-1):
        for j in range(i+1,input2-1):
            hi= input1[i].split('#'); hj= input1[j].split('#');
            if float(hi[0])>float(hj[0]):
		            ans=ans+1;
            elif float(hi[0])<float(hj[0]):
                continue;
            else:
                if(parseFloat(hi[1],10)>parseFloat(hj[1],10)):
                    ans=ans+1;
    return ans;
