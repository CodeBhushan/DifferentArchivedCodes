import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CandidateCode
{

    public static String decodeMessage(String input1)
    {

        Map<Integer, String> map1 = new HashMap<>();
        char c;

        for (int i = 1; i < 27; i++)
        {
            c = (char) (i + 96);
            map1.put(i, c + "");
        }
if(input1.length()<2)return "invalid";//todo new
        if (Integer.valueOf(input1.charAt(input1.length() - 1)) != 48) return "invalid";

        int endIndex = input1.length() - 1;

        List<String> list = new ArrayList<>();
        int startIndex = 0;
        int j = startIndex;
        int totalNonZeroLength = 0;
        while (j < input1.length())
        {
            for (j = startIndex; j < input1.length(); j++)
            {
                if (Integer.valueOf(input1.charAt(j)) == 48 && (j + 1 == input1.length() || Integer.valueOf(input1.charAt(j + 1)) != 48))
                {
                    endIndex = j - 1;
                    break;
                }
            }
            String temp = input1.substring(startIndex, endIndex + 1);
            totalNonZeroLength += endIndex - startIndex + 1;
            list.add(temp);
            startIndex = j + 1;
            j = startIndex;
        }

       // System.out.println(totalNonZeroLength);
        if (input1.length() - totalNonZeroLength != list.size())
        {
            return "invalid";
        }
        int key = 26;
        StringBuffer ans = new StringBuffer();
        int index = -1;
        for (String s : list)
        {
            index++;
            int k = Integer.parseInt(s);
            if (!map1.containsKey(k))
            {
                return "invalid";
            } else
            {
                ans.append(map1.get(k));
                if(index==list.size()-1)break;
                if (map1.containsKey(Integer.parseInt(list.get(index + 1))))
                {
                    char c1 = map1.get(Integer.parseInt(list.get(index + 1))).charAt(0);

                    map1.put(++key, map1.get(k) + c1);

                } else
                {
                    int keytmp = ++key;
                    ;
                    String temp = "WTF";
                    for (int i = 1; i < 27; i++)
                    {
                        c = (char) (i + 96);
                        temp = map1.get(k) + "" + c;

                        map1.put(keytmp, temp);

                        if (!map1.containsKey(Integer.parseInt(list.get(index + 1))) || map1.get(Integer.parseInt(list.get(index + 1))).charAt(0) != c)
                        {
                            map1.remove(keytmp);
                        } else break;

                    }
                    map1.put(keytmp, temp);

                }


            }


        }

        return ans.toString();
    }

    public static void main(String[] args)
    {
        System.out.println(decodeMessage("2602701010"));
    }
}